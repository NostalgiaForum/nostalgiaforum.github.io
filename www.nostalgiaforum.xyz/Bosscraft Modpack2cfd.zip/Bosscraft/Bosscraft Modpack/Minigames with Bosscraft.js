ModPE.setItem(186,"spawn_egg",0,"Spawn Friendly Creeper");
ModPE.setItem(185,"spawn_egg",0,"Spawn Parasitic Creeper");
var Apple = 0;
var Applecount = 0;
var Love = 0;
var Hate = 0;
Applecount ++;
var timer = false;
var walking = false;
var count = 0;
var x = 0;
var y = 0;
var z = 0;
var looptimer = false;
var loopcount = 0;
var walking = false;

function addEndermanRenderType(renderer) 
{
    var model = renderer.getModel();
     
    var head = model.getPart("head");
    var body = model.getPart("body");
    var rarm = model.getPart("rightArm");
    var larm = model.getPart("leftArm");
    var rleg = model.getPart("rightLeg");
    var lleg = model.getPart("leftLeg");
     
    head.clear();
    head.setTextureOffset(0, 0);
    head.addBox(-4, -30, -4, 15, 15, 15);
 
    body.clear();
    body.setTextureOffset(0, 12);
    body.addBox(-4, -20, -4, 20, 20, 20);
 
    rarm.clear();
    rarm.setTextureOffset(0, 12);
    rarm.addBox(-1, -18, -2, 10, 34, 26);
 
    larm.clear();
    larm.setTextureOffset(0, 12);
    larm.addBox(-1,-18,-2, 10, 34, 26);
 
    rleg.clear();
    rleg.setTextureOffset(0, 12);
    rleg.addBox(-10, -10, 10, 46, 12, 36);
 
    lleg.clear();
    lleg.setTextureOffset(0, 12);
    lleg.addBox(-10, -10, 10, 46, 12, 36);
}

var EndermanRenderType= Renderer.createHumanoidRenderer();
addEndermanRenderType(EndermanRenderType);

function useItem(x, y, z, itemId, blockId, side, itemDamage, blockDamage)
{
if(itemId==416){
var random = Math.floor ((Math.random() * 35) + 1);
}
if (random <= 23)
{
addItemInventory (31, 1);
clientMessage(ChatColor.WHITE + "You Have Bad Luck! +0");
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
Player.addItemInventory(266,1);
}
if(itemId==446 && blockId==2){
setTile(x, y, z, 0);
Level.dropItem(x, y + 1, z, 0, 2, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
}
if(itemId==446 && blockId==3){
setTile(x, y, z, 0);
Level.dropItem(x, y + 1, z, 0, 3, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.gravel", 100, 100);
}
if(itemId==446 && blockId==4){
setTile(x, y, z, 0);
Level.dropItem(x, y + 1, z, 0, 4, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.stone", 100, 100);
}
if(itemId==446 && blockId==1){
setTile(x, y, z, 0);
Level.dropItem(x, y + 1, z, 0, 4, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.stone", 100, 100);
}
if(itemId==446 && blockId==56){
setTile(x, y, z, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.stone", 100, 100);
Level.dropItem(x, y + 1, z, 0, 264, 2, 0);
}
if(itemId==446 && blockId==16){
setTile(x, y, z, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.stone", 100, 100);
Level.dropItem(x, y + 1, z, 0, 263, 1, 0);
}
if(itemId==446 && blockId==73){
setTile(x, y, z, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.stone", 100, 100);
Level.dropItem(x, y + 1, z, 0, 331, 3, 0);
}
if(itemId==446 && blockId==33){
setTile(x, y, z, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.stone", 100, 100);
Level.dropItem(x, y + 1, z, 0, 444, 2, 0);
}
if(itemId==446 && blockId==12){
setTile(x, y, z, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.sand", 100, 100);
Level.dropItem(x, y + 1, z, 0, 12, 1, 0);
}
if(itemId==446 && blockId==7){
setTile(x, y, z, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.stone", 100, 100);
Level.dropItem(x, y + 1, z, 0, 7, 1, 0);
}
if(itemId==399 && blockId==60){
setTile(x, y + 1, z, 99);
Player.addItemInventory(399, -1);
}
if(itemId==351 && itemDamage==15 && blockId==99){
setTile(x, y, z, 84);
}
if(itemId==402){
slime = Level.spawnMob(x, y + 1, z, 32,"mob/slime.png");
Entity.setHealth(slime, 550);
Entity.setNameTag(slime, "Slime Beast [BOSS]");
Entity.setAnimalAge(slime, 20);
Entity.setRenderType(slime, 3);
Player.addItemInventory(417, -1);
}
if(itemId==484){
WTF = Level.spawnMob(x, y + 2, z, 35,"mob/enderman.png");
Entity.setHealth(WTF, 100);
Entity.setRenderType(WTF, EndermanRenderType.renderType);
Entity.setAnimalAge(WTF, 5);
}
if(itemId == 480){
Apple = Level.spawnMob(x, y + 2, z, 11,"mob/AppleCow.png");
Entity.setHealth(Apple, 10);
Player.addItemInventory(480, -1);
}
if(itemId == 402){
Love = Level.spawnMob(x, y + 2, z, 11,"mob/love.png");
Entity.setHealth(Love, 20);
Entity.setRenderType(Love, 14);
Player.addItemInventory(402, -1);
}
if(itemId == 401){
Hate = Level.spawnMob(x, y + 2, z, 32,"mob/love.png");
Entity.setHealth(Hate, 35);
Entity.setRenderType(Hate, 14);
Player.addItemInventory(401, -1);
P = Level.spawnMob(x, y, z, 33,"love.png");
Entity.setHealth(P, 1);
Entity.setRenderType(P, 2);
Entity.rideAnimal(P, Hate);
}
if(itemId==443 && blockId==15){
setTile(x, y, z, 33);
}

function addGolemToRenderer(renderer)
 {
	var var2 = 0;
	
	var model = renderer.getModel();
	
	var bipedBody = model.getPart("body").clear().setTextureOffset(56, 0);
	
	bipedBody.addBox(-6.0, -16.0, -2.0, 20, 15, 10, var2);
	
	 bipedBody.addBox(-2.0, -1.0, -2.0, 12, 5, 10, var2);
	
	
	var bipedHead =
model.getPart("head").clear().setTextureOffset(56, 0);

	 bipedBody.addBox(-1.0, -27.0, -3.0, 10, 12, 10, var2);
	 
	 bipedBody.addBox(2.6, -18.8, -4.5, 3, 5.5, 3, var2);
	 
	 
	 var bipedRightArm = model.getPart("rightArm").clear().setTextureOffset(56, 0);
	
	bipedRightArm.addBox(-7.0, -16.0, -1.0, 6, 37, 8, var2);
	
 var bipedLeftArm = model.getPart("leftArm").clear().setTextureOffset(56, 0);
 
	bipedLeftArm.addBox(9.0, -16.0, -1.0, 6, 37, 8, var2);
	
	var bipedRightLeg = model.getPart("rightLeg").clear().setTextureOffset(56, 0);
	
	bipedRightLeg.addBox(8.0, -8.0, -1.0, 6.5, 20, 9, var2);
	
	var bipedLeftLeg = model.getPart("leftLeg").clear().setTextureOffset(56, 0);
	
	bipedLeftLeg.addBox(-6, -8.0, -1.0, 6.5, 20, 9, var2);
	
}

var golemRenderer = Renderer.createHumanoidRenderer();

addGolemToRenderer(golemRenderer);


var block1 = 86;
var block2 = 49;

function useItem(x,y,z,itemId,blockId)
{
if(itemId==280&&blockId== block1&& getTile(x,y-1,z) == block2&& getTile(x,y-2,z)== block2&& getTile(x+1,y-1,z) == block2&& getTile(x-1,y-1,z) == block2 )
{

var obsidian = Level.spawnMob(x, y-1, z, 35,"mob/obsidian.png" );

Entity.setHealth(obsidian,135);
Entoty.setAnimalAge(obsidian, 15);

	Entity.setRenderType(obsidian, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x+1,y-1,z,0);
	 setTile(x-1,y-1,z,0);
}

function modTick(){
if(Applecount==13000){
var Apple= new zmb(  getPlayerX()+10, getPlayerY()-5 , getPlayerZ()+8," mob/AppleCow.png", 11, true, false);
  Apple.push(Apple); 
  Applecount=1;
  }
}
}

function attackHook(attacker, victim)
{
Level.playSoundEnt(Love, "mob.creeper" , 100, 100);
Level.playSoundEnt(Hate, "mob.creeper" , 100, 100);
}
}

function deathHook(attacker,victim)
{
if(Entity.getEntityTypeId(Apple)==11)
{
if(Apple > 0)//AppleDrops
{
preventDefault();
Apple --;
ModPE.saveData (Level.getWorldDir() + "Apple", Apple);
Level.dropItem (Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 260, 3, 0);
Level.dropItem (Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 481, 2, 0);}
}
}