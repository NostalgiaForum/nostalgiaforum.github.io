/*
If anyone share u need to put froum link
TBPM Script (C) GNC copyright
TBPM********************Script
Aircraft 
Copyright (C) <2014>  <TBPM>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
*/



var i=0,mode, je,JE,jelv,zd=0,_zd=0,x1,z1,x2,z2;
var jet=["♡♡♡♡♡♡♡♡♡♡","♥♡♡♡♡♡♡♡♡♡","♥♥♡♡♡♡♡♡♡♡","♥♥♥♡♡♡♡♡♡♡","♥♥♥♥♡♡♡♡♡♡","♥♥♥♥♥♡♡♡♡♡","♥♥♥♥♥♥♡♡♡♡","♥♥♥♥♥♥♥♡♡♡","♥♥♥♥♥♥♥♥♡♡","♥♥♥♥♥♥♥♥♥♡","♥♥♥♥♥♥♥♥♥♥"]
function newLevel()
{
  mode=Level.getGameMode();
  if(mode==0)
  {je=ModPE.readData(Level.getWorldDir()+".je");
  if (je==""||je=="undefined"||je=="NaN")
  {je=10;}
  jelv=ModPE.readData(Level.getWorldDir()+".jelv");
  if (jelv==""||jelv=="undefined"||jelv=="NaN")
  {jelv=0;}
  var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
  ctx.runOnUiThread(new java.lang.Runnable({
  run:function(viewarg){ 
  try
  {
			var layout = new android.widget.LinearLayout(ctx);
			layout.setOrientation(0);
			JE = new android.widget.TextView(ctx);
			JE.setTextSize(35);
			layout.addView(JE);
			jeWindow = new android.widget.PopupWindow(layout, 350, Math.ceil(100 * ctx.getResources().getDisplayMetrics().density));
			jeWindow.setTouchable(false);
			jeWindow.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, 345, 45);
  }
  catch(err)
  {
			clientMessage("错误!\n"+err);
  }
}}))
  x1=getPlayerX();
  z1=getPlayerZ();
}}
function leaveGame()
{
  if(mode==0)
  {var ctx=com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
  ctx.runOnUiThread(new java.lang.Runnable({
  run:function(){
			if(jeWindow != null){
				jeWindow.dismiss();
				jeWindow = null;
			}
		}
}));
  ModPE.saveData(Level.getWorldDir()+".je",je);
  ModPE.saveData(Level.getWorldDir()+".jelv",jelv);
}}
function modTick()
{
  if(mode==0)
  {je=parseFloat(je);
  jelv=parseFloat(jelv);
  i++;
  if(je<0){je=0;}
  if(je>10){je=10;}
  if(Entity.getHealth(getPlayerEnt())==1){je=10;Player.setHealth(0);}
  var ctx=com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
  ctx.runOnUiThread(new java.lang.Runnable({
  run:function(){
  JE.setText(jet[je]);
  if(zd==0){JE.setTextColor(android.graphics.Color.argb( 16580608, 16580608, 16580608, 16580608));}
  if(zd==1){JE.setTextColor(android.graphics.Color.argb(12647,2468,718,0));}
  }}))
  if(i==1200)
  {
    i=0;
  }
  if(je==10&&i%80==79){if(Entity.getHealth(getPlayerEnt())<20&&Entity.getHealth(getPlayerEnt())>1){Player.setHealth(Entity.getHealth(getPlayerEnt())+1);}}
  if(je==0&&i%80==79){Player.setHealth(Entity.getHealth(getPlayerEnt())-1);}
  if(jelv>=8){jelv=jelv-8;je--;}
  if(zd==1&&i%300==1)
  {
    jelv=jelv+8;
    if(_zd==1){zd=0;_zd=0;}
    if(_zd==0){_zd=1;}
  }
  x2=getPlayerX();
  z2=getPlayerZ();
  jelv=jelv+Math.sqrt(Math.pow((x1-x2),2)+Math.pow((z1-z2),2))*0.01;
  x1=getPlayerX();
  z1=getPlayerZ();
}}
function useItem(x,y,z,it,bl,si,da,ba)
{
  if(mode==0)
  {var _je,_it;
  if(bl==92){_je=je+1;_it=1}
  if(it==357||it==360||it==365||it==349||it==363||it==319||it==375||it==392)
  {_je=je+1;_it=0;}
  if(it==260||it==297||it==350||it==391||it==367)
  {_je=je+2;_it=0;}
  if(it==396||it==382||it==366||it==393)
  {_je=je+3;_it=0;}
  if(it==364||it==320)
  {_je=je+4;_it=0;}
  if(it==365&&Math.floor((Math.random()*9)+1)==1){zd=1;_zd=0;}
  if(it==367&&Math.floor((Math.random()*5)+1)!=1){zd=1;_zd=0;}
  if(it==375){zd=1;_zd=0;}
  if(it==335){zd=0;_zd=0;}
  if(_je>=10){je=10;}
  if(_je<10){je=_je;}
  if(_it==0){addItemInventory(it,-1,da);}
}}
function destroyBlock(){if(mode==0){jelv=jelv+0.025;}}
function attackHook(){if(mode==0){jelv=jelv+0.3;}}
function deathHook(){if(mode==0){jelv=jelv+0.3;}}