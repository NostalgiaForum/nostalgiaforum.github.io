//Made by EnderLord397. Do not distribute!

ModPE.setItem(397,"skull_steve",0,"Head", 65);
ModPE.setItem(396,"iron_horse_armor",3,"Robo-Mech", 65);
var diamond = 0;
var snow = 0;

function addSnowToRenderer(renderer)
{
var model = renderer.getModel();
var head = model.getPart("head").clear();
head.addBox(-2, -20, 0, 20, 20, 20);
var body = model.getPart("body").clear();
body.addBox(0, -10, 0, 10, 10, 10);
body.addBox(0, -2, 0, 15, 15, 15);
var rarm = model.getPart("rightArm").clear();
rarm.addBox(0, -8, 0, 50, 2, 2);
var larm = model.getPart("leftArm").clear();
larm.addBox(0, -8, 0, 50, 2, 2);
var rleg = model.getPart("rightLeg").clear();
rleg.addBox(0, 0, 0, 0, 0, 0);
var lleg = model.getPart("leftLeg").clear();
lleg.addBox(0, 0, 0, 0, 0, 0);
}

var SnowRenderer = Renderer.createHumanoidRenderer();
addSnowToRenderer(SnowRenderer);

function addGolemToRenderer(renderer)
 {
	var var2 = 0;
	
	var model = renderer.getModel();
	
	var bipedBody = model.getPart("body").clear().setTextureOffset(100, 0);
	
	bipedBody.addBox(-6.0, -16.0, -2.0, 20, 15, 10, var2);
	
	 bipedBody.addBox(-2.0, -1.0, -2.0, 12, 5, 10, var2);
	
	
	var bipedHead =
model.getPart("head").clear().setTextureOffset(60, 0);

	 bipedBody.addBox(-1.0, -27.0, -3.0, 10, 12, 10, var2);
	 
	 bipedBody.addBox(2.6, -18.8, -4.5, 3, 5.5, 3, var2);
	 
	 
	 var bipedRightArm = model.getPart("rightArm").clear().setTextureOffset(65, 0);
	
	bipedRightArm.addBox(-7.0, -16.0, -1.0, 6, 37, 8, var2);

     bipedRightArm.addBox(19.0, -16.0, -1.0, 6, 37, 8, var2);
	
 var bipedLeftArm = model.getPart("leftArm").clear().setTextureOffset(65, 0);
 
	bipedLeftArm.addBox(0, -.0, -.0, 0, 0, 0, var2);
	
	var bipedRightLeg = model.getPart("rightLeg").clear().setTextureOffset(1000000, 0);
	
	bipedRightLeg.addBox(8.0, -8.0, -1.0, 7.5, 20, 9, var2);
	
	var bipedLeftLeg = model.getPart("leftLeg").clear().setTextureOffset(1000000, 0);
	
	bipedLeftLeg.addBox(-6, -8.0, -1.0, 7.5, 20, 9, var2);
	
}

var golemRenderer = Renderer.createHumanoidRenderer();

addGolemToRenderer(golemRenderer);

var block1 = 86;
var block2 = 49;
var block3 = 87;
var block4 = 4;

function useItem(x,y,z,itemId,blockId, side, itemDamage, blockDamage)
{
if(blockId == block1&& getTile(x, y -1, z) == 80&& getTile(x, y -2, z) == 80){
snow = Level.spawnMob(x, y -1, z, 11,"mob/snow.png");
Entity.setHealth(snow, 100);
setTile(x, y, z, 0);
setTile(x, y -1, z, 0);
setTile(x, y -2, z, 0);
Entity.setRenderType(snow, golemRenderer.renderType);
}
if(blockId == block1&& getTile(x,y-1,z) == block2&& getTile(x,y-2,z)== block2&& getTile(x+1,y-1,z) == block2&& getTile(x-1,y-1,z) == block2 )
{

var spider = Level.spawnMob(x, y-1, z, 35,"mob/Golem.png");
Entity.setMobSkin(spider,"mob/Golem.png");

Entity.setHealth(spider,850);
Entity.setAnimalAge(spider, 20);

	Entity.setRenderType(spider, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x+1,y-1,z,0);
	 setTile(x-1,y-1,z,0);
}
else if(blockId== block1&& getTile(x,y-1,z) == block2&& getTile(x,y-2,z)== block2&& getTile(x,y-1,z+1) == block2&& getTile(x,y-1,z-1) == block2 )
{

var spider = Level.spawnMob(x, y-1, z, 35,"mob/Golem.png");
Entity.setMobSkin(spider,"mob/Golem.png");

Entity.setHealth(spider,850);
Entity.setAnimalAge(spider, 20);

	Entity.setRenderType(spider, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x,y-1,z+1,0);
	 setTile(x,y-1,z-1,0);
	
}
if(blockId== block1&& getTile(x,y-1,z) == 23&& getTile(x,y-2,z)== 23&& getTile(x+1,y-1,z) == 23&& getTile(x-1,y-1,z) == 23)
{

var bloody = Level.spawnMob(x, y-1, z, 35,"mob/bloody.png");
Entity.setMobSkin(bloody,"mob/bloody.png");

Entity.setHealth(bloody,750);
Entity.setAnimalAge(bloody, 20);

	Entity.setRenderType(bloody, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x+1,y-1,z,0);
	 setTile(x-1,y-1,z,0);
}
else if(blockId== block1&& getTile(x,y-1,z) == 23&& getTile(x,y-2,z)== 23&& getTile(x,y-1,z+1) == 23&& getTile(x,y-1,z-1) == 23)
{

var bloody = Level.spawnMob(x, y-1, z, 35,"mob/bloody.png");
Entity.setMobSkin(bloody,"mob/bloody.png");

Entity.setHealth(bloody,850);
Entity.setAnimalAge(bloody, 20);

	Entity.setRenderType(bloody, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x,y-1,z+1,0);
	 setTile(x,y-1,z-1,0);
}	
if(blockId== block1&& getTile(x,y-1,z) == block3&& getTile(x,y-2,z)== block3&& getTile(x+1,y-1,z) == block3&& getTile(x-1,y-1,z) == block3 )
{

var nether = Level.spawnMob(x, y-1, z, 35,"mob/Nether.png" );

Entity.setHealth(nether,500);
Entity.setAnimalAge(nether, 10);

	Entity.setRenderType(nether, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x+1,y-1,z,0);
	 setTile(x-1,y-1,z,0);
}
else if(blockId== block1&& getTile(x,y-1,z) == block3&& getTile(x,y-2,z)== block3&& getTile(x,y-1,z+1) == block3&& getTile(x,y-1,z-1) == block3 )
{

var nether = Level.spawnMob(x, y-1, z, 35,"mob/Nether.png" );

Entity.setHealth(nether,500);
Entity.setAnimalAge(nether, 10);

	Entity.setRenderType(nether, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x,y-1,z+1,0);
	 setTile(x,y-1,z-1,0);
	
}
if(blockId== block1&& getTile(x,y-1,z) == block4&& getTile(x,y-2,z)== block4&& getTile(x+1,y-1,z) == block4&& getTile(x-1,y-1,z) == block4 )
{

var cobble = Level.spawnMob(x, y-1, z, 35,"mob/cobble.png");
Entity.setMobSkin(spider,"mob/cobble.png");

Entity.setHealth(cobble,300);
Entity.setAnimalAge(cobble, 8);

	Entity.setRenderType(cobble, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x+1,y-1,z,0);
	 setTile(x-1,y-1,z,0);
}
else if(blockId== block1&& getTile(x,y-1,z) == block4&& getTile(x,y-2,z)== block4&& getTile(x,y-1,z+1) == block4&& getTile(x,y-1,z-1) == block4 )
{

var cobble = Level.spawnMob(x, y-1, z, 35,"mob/cobble.png");
Entity.setMobSkin(cobble,"mob/cobble.png");

Entity.setHealth(cobble,300);
Entity.setAnimalAge(cobble, 8);

	Entity.setRenderType(cobble, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x,y-1,z+1,0);
	 setTile(x,y-1,z-1,0);
	
}
if(blockId== block1&& getTile(x,y-1,z) == 57&& getTile(x,y-2,z)== 57&& getTile(x+1,y-1,z) == 57&& getTile(x-1,y-1,z) == 57)
{

var diamond = Level.spawnMob(x, y-1, z, 35,"mob/diamond.png");
Entity.setMobSkin(spider,"mob/diamond.png");

Entity.setHealth(diamond,750);
Entity.setAnimalAge(diamond, 20);

	Entity.setRenderType(diamond, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x+1,y-1,z,0);
	 setTile(x-1,y-1,z,0);
}
else if(blockId== block1&& getTile(x,y-1,z) == 57&& getTile(x,y-2,z)== 57&& getTile(x,y-1,z+1) == 57&& getTile(x,y-1,z-1) == 57)
{

var diamond = Level.spawnMob(x, y-1, z, 35,"mob/diamond.png");
Entity.setMobSkin(diamond,"mob/diamond.png");

Entity.setHealth(diamond,750);
Entity.setAnimalAge(diamond, 20);

	Entity.setRenderType(diamond, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x,y-1,z+1,0);
	 setTile(x,y-1,z-1,0);
	
}
if(itemId==396){
{

var mech = Level.spawnMob(x, y + 2, z, 11,"mob/mech.png");
Entity.setMobSkin(mech,"mob/mech.png");

Entity.setHealth(mech,100);
Entity.setAnimalAge(mech, 15);
Player.addItemInventory(396, -1);

	Entity.setRenderType(mech, golemRenderer.renderType);
	
	 setTile(x, y, z, 0);
	 setTile(x,y-1,z,0);
	 setTile(x, y -2, z, 0);
	 setTile(x+1,y-1,z,0);
	 setTile(x-1,y-1,z,0);
}
}

function attackHook(attacker, victim)
{
Level.playSoundEnt(diamond, "mob.creeperdeath", 100, 100);
}
if(Entity.getEntityTypeId(snow)==11){
Level.playSoundEnt(snow, "step.snow", 100, 100);
}
}

function modTick()
{
var x = Entity.getX(snow);
var y = Entity.getY(snow);
var z = Entity.getZ(snow);
if(Entity.getEntityTypeId(snow)==11){
setTile(x, y, z, 78);
}
}

{var golem = 35;
function attackHook(attacker,victim)
{
if( Entity.getEntityTypeId(victim)==golem&&Math.floor((Math.random() * 7) + 2)==1 )
   setVelY(attacker,2.0);
}
}
function deathHook(murderer, victim)
{
if( Entity.getEntityTypeId(golem)==golem)
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 397, 1, 0);

}