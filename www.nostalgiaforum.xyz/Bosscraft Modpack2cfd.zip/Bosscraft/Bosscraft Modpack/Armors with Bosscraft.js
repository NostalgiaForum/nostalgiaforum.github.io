ModPE.setItem(422,"spawn_egg",0,"Spawn Haunted Armor [D]");
ModPE.setItem(421,"spawn_egg",0,"Spawn Haunted Armor [G]");
ModPE.setItem(420,"spawn_egg",0,"Spawn Haunted Armor [I]");
ModPE.setItem(415,"spawn_egg",0,"Spawn Haunted Armor [L]");
ModPE.setItem(417,"spawn_egg",0,"Spawn Haunted Armor [B]");
ModPE.setItem(392,"spawn_egg",1,"Spawn Haunted Enderman");
ModPE.setItem(504,"spawn_egg",11,"Spawn Ender Archer");
var d = 0
var g = 0
var i = 0
var l = 0
var b = 0
var enderman = 0;
var apple = 0;
x = Player.getX();
y = Player.getY();
z = Player.getZ();

function addEndermanRenderType(renderer) 
{
    var model = renderer.getModel();
     
    var head = model.getPart("head");
    var body = model.getPart("body");
    var rarm = model.getPart("rightArm");
    var larm = model.getPart("leftArm");
    var rleg = model.getPart("rightLeg");
    var lleg = model.getPart("leftLeg");
     
    head.clear();
    head.setTextureOffset(0, 0);
    head.addBox(-4, -24, -4, 8, 8, 8);
 
    body.clear();
    body.setTextureOffset(0, 12);
    body.addBox(-4, -16, -2, 8, 12, 4);
 
    rarm.clear();
    rarm.setTextureOffset(0, 12);
    rarm.addBox(-1, -18, -2, 2, 30, 2);
 
    larm.clear();
    larm.setTextureOffset(0, 12);
    larm.addBox(-1,-18,-2, 2, 30, 2);
 
    rleg.clear();
    rleg.setTextureOffset(0, 12);
    rleg.addBox(-1, -18, 0, 2, 30, 2);
 
    lleg.clear();
    lleg.setTextureOffset(0, 12);
    lleg.addBox(-1, -18, 0, 2, 30, 2);
}

var EndermanRenderType= Renderer.createHumanoidRenderer();
addEndermanRenderType(EndermanRenderType);

function useItem(x, y, z, itemId, blockId, side, itemDamage, blockDamage)
{
if(Level.getTime() == 14000){
clientMessage("§4 <Herobrine> IT'S NIGHT NOW TIME TO DIE");
}
if(itemId==189){
Player.setArmorSlot(0, 189, 0);
Player.setHealth(Entity.getHealth(Player.getEntity()) +15);
Entity.setMobSkin(Player.getEntity(), "armor/Obsidian_Armor.png");
Player.addItemInventory(189, -1);
}
if(itemId==190){
Player.setArmorSlot(1, 190, 0);
Player.setHealth(Entity.getHealth(Player.getEntity()) +30);
Entity.setMobSkin(Player.getEntity(), "armor/Obsidian_Armor.png");
Player.addItemInventory(190, -1);
}
if(itemId==191){
Player.setArmorSlot(2, 191, 0);
Player.setHealth(Entity.getHealth(Player.getEntity()) +20);
Entity.setMobSkin(Player.getEntity(), "armor/Obsidian_Armor.png");
Player.addItemInventory(191, -1);
} 
if(itemId==192){
Player.setArmorSlot(3, 192, 0);
Player.setHealth(Entity.getHealth(Player.getEntity()) +15);
Entity.setMobSkin(Player.getEntity(), "armor/Obsidian_Armor.png");
Player.addItemInventory(192, -1);
}
if(itemId==422){
d = Level.spawnMob(x, y + 1, z, 32,"mob/d.png");
Entity.setHealth(d, 40);
Entity.setCarriedItem(276, 1, 0);
Entity.setRenderType(d, 3);
Entity.setAnimalAge(d, 7);
}
if(itemId==421){
g = Level.spawnMob(x, y + 1, z, 32,"mob/g.png");
Entity.setHealth(g, 25);
Entity.setAnimalAge(g, 5);
Entity.setRenderType(g, 3);
}
if(itemId==420){
i = Level.spawnMob(x, y + 1, z, 32,"mob/i.png");
Entity.setHealth(i, 35);
Entity.setRenderType(i, 3);
Entity.setAnimalAge(i, 7);
}
if(itemId==415){
l = Level.spawnMob(x, y + 1, z, 32,"mob/l.png");
Entity.setHealth(l, 15);
Entity.setRenderType(l, 3);
Entity.setAnimalAge(l, 4);
}
if(itemId==395 && blockId==173){
Entity.setMobSkin(Player.getEntity(), "enderman.png");
Entity.setRenderType(Player.getEntity(), EndermanRenderType.renderType);
}
if(itemId==504){
archer = Level.spawnMob(x, y + 2, z, 34,"mob/enderman.png");
Entity.setHealth(archer, 60);
Entity.setCarriedItem(archer, 261, 1, 0);
Entity.setRenderType(archer, EndermanRenderType.renderType);
}
if(itemId==417){
b = Level.spawnMob(x, y + 1, z, 32,"armor/chain_1.png");
Entity.setHealth(b, 30);
Entity.setRenderType(b, 3);
Entity.setAnimalAge(b, 10);
}
if(itemId==392){
enderman = Level.spawnMob(x, y + 2, z, 35,"/enderman.png");
Entity.setRenderType(enderman, EndermanRenderType.renderType);
Entity.setHealth(enderman, 60);
Entity.setAnimalAge(enderman, 12);
Entity.setCarriedItem(enderman, 276, 1, 0);
}
if(itemId==407){
Player.addItemInventory(407, -1);
Player.addItemInventory(407, 1, 10);
clientMessage("100%/100%");
}
if(Entity.getRenderType(Player.getEntity()) == EndermanRenderType.renderType)
{
Level.playSound(Player.getX(), Player.getY(), Player.getZ(), "mob.spider", 100, 100);
}
if(itemId==503){
setTile(x -1, y + 1, z, 51);
                setTile(x, y + 1, z, 51);
                setTile(x + 1, y + 1, z, 51);
                setTile(x, y + 1, z -1, 51);
                setTile(x, y + 1, z + 1, 51);
                setTile(x + 1, y + 1, z + 1, 51);
                setTile(x + 1, y + 1, z -1, 51);
                setTile(x -1, y + 1, z + 1, 51);
                setTile(x -1, y + 1, z -1, 51);
}
}

function attackHook(attacker, victim)
{
if(Entity.getRenderType(Player.getEntity()) == EndermanRenderType.renderType)
{
var Teleport = Math.floor((Math.random()*4)+1);
		switch(Teleport)
		{
			case 1:
				setPosition(Player.getEntity(), Entity.getX(victim),Entity.getY(victim)+2, Entity.getZ(victim)+5);
			break;
		
			case 2:
				setPosition(Player.getEntity(), Entity.getX(victim),Entity.getY(victim)+2, Entity.getZ(victim)-5);
			break;
		
			case 3:
				setPosition(Player.getEntity(), Entity.getX(victim)+5,Entity.getY(victim)+2, Entity.getZ(victim));
			break;
}
if(Player.getCarriedItem() == 395){
		if(Player.getCarriedItemData() < 9) Entity.setCarriedItem(attacker, 395, Player.getCarriedItemCount(), Player.getCarriedItemData() + 1);
}
}
}

var startGame = 0;
function startDestroyBlock(x, y, z, side){
if(Player.getCarriedItem() == 180)
{
Block.setDestroyTime(1, 0);
Block.setDestroyTime(4, 0);
Block.setDestroyTime(98, 0);
Block.setDestroyTime(87, 0);
Block.setDestroyTime(24, 0);
Block.setDestroyTime(48, 0);
}
}

function modTick(ticks, itemDamage){
if(Player.getCarriedItem() == 407){
setVelY(Player.getEntity(), 0.2);
Entity.setHealth(Player.getEntity(), 20);
}
if(Player.getCarriedItem()==189){
Entity.setMobSkin(Player.getEntity(), "mob/char.png");
Entity.setHealth(Player.getEntity(), 20);
}
if(Player.getCarriedItem()==190){
Entity.setMobSkin(Player.getEntity(), "mob/char.png");
Entity.setHealth(Player.getEntity(), 20);
}
if(Player.getCarriedItem()==191){
Entity.setMobSkin(Player.getEntity(), "mob/char.png");
Entity.setHealth(Player.getEntity(), 20);
}
if(Player.getCarriedItem()==192){
Entity.setMobSkin(Player.getEntity(), "mob/char.png");
Entity.setHealth(Player.getEntity(), 20);
}
if(Player.getCarriedItem() == 407 && itemDamage==10){
setVelY(Player.getEntity(), 0.5);
}
var startGame = 0;
var x = Player.getX();
var y = Player.getY();
var z = Player.getZ();
	if(startGame==0)
	{
	    startGame = 1;
	}

	if(startGame==1)
	{
		var spawn = Math.floor((Math.random()*7500)+1);
        switch(spawn)
		{
			case 1:
				e = Level.spawnMob(getPlayerX(), getPlayerY() + 1,getPlayerZ() + 10, 35, "mob/enderman.png");
				Entity.setHealth(e, 60);
				Entity.setRenderType(e, EndermanRenderType.renderType);
			break;
               case 2:
				var apple = Level.spawnMob(getPlayerX(), getPlayerY() + 1,getPlayerZ() + 10, 11, "mob/AppleCow.png");
				Entity.setHealth(apple, 10);
			break;
               case 3:
                     var herobrine = Level.spawnMob(getPlayerX(), getPlayerY() + 1, getPlayerZ() + 10, 35,"mob/Herobrine.png");
                    Entity.setRenderType(herobrine, 3);
                    Entity.setHealth(herobrine, 50);
                    Level.setTime(14000);
                    clientMessage("§4<Herobrine> Kill Him!!!");
               break;
               case 4:
                var x = Player.getX();
                var y = Player.getY();
                var z = Player.getZ();
                setTile(x -1, y + 30, z, 48);
                setTile(x, y + 30, z, 4);
                setTile(x + 1, y + 30, z, 4);
                setTile(x, y + 30, z -1, 4);
                setTile(x, y + 30, z + 1, 4);
                setTile(x + 1, y + 30, z + 1, 4);
                setTile(x + 1, y + 30, z -1, 4);
                setTile(x -1, y + 30, z + 1, 4);
                setTile(x -1, y + 30, z -1, 4);
                setTile(x -2, y + 30, z, 48);
                setTile(x, y + 30, z -2, 4);
                setTile(x + 2, y + 30, z, 4);
                setTile(x, y + 30, z -2, 4);
                setTile(x, y + 30, z + 2, 4);
                setTile(x + 2, y + 30, z + 2, 4);
                setTile(x + 2, y + 30, z -2, 4);
                setTile(x -2, y + 30, z + 2, 4);
                setTile(x -2, y + 30, z -2, 4);
                setTile(x, y + 30, z -3, 4);
                setTile(x, y + 30, z +3, 4);
                setTile(x -3, y + 30, z, 4);
                setTile(x +3, y + 30, z, 4);
                setTile(x +3, y + 30, z -3, 4);
                setTile(x +3, y + 30, z +3, 4);
                setTile(x -3, y + 30, z -3, 4);
                setTile(x -3, y + 30, z -3, 4);
                setTile(x -1, y + 34, z, 48);
                setTile(x, y + 34, z, 4);
                setTile(x + 1, y + 34, z, 4);
                setTile(x, y + 34, z -1, 4);
                setTile(x, y + 34, z + 1, 4);
                setTile(x + 1, y + 34, z + 1, 4);
                setTile(x + 1, y + 34, z -1, 4);
                setTile(x -1, y + 34, z + 1, 4);
                setTile(x -1, y + 34, z -1, 4);
                setTile(x -2, y + 34, z, 48);
                setTile(x, y + 34, z -2, 4);
                setTile(x + 2, y + 34, z, 4);
                setTile(x, y + 34, z -2, 4);
                setTile(x, y + 34, z + 2, 4);
                setTile(x + 2, y + 34, z + 2, 4);
                setTile(x + 2, y + 34, z -2, 4);
                setTile(x -2, y + 34, z + 2, 4);
                setTile(x -2, y + 34, z -2, 4);
                setTile(x, y + 34, z -3, 4);
                setTile(x, y + 34, z +3, 4);
                setTile(x -3, y + 34, z, 4);
                setTile(x +3, y + 34, z, 4);
                setTile(x +3, y + 34, z -3, 4);
                setTile(x +3, y + 34, z +3, 4);
                setTile(x -3, y + 34, z -3, 4);
                setTile(x -3, y + 34, z -3, 4);
                Level.spawnMob(x, y + 32, z, 35,"mob/spider.png");
                Level.spawnMob(x, y + 32, z, 32,"mob/zombie.png");
                Level.spawnMob(x, y + 32, z, 36,"mob/pigzombie.png");
                Level.spawnMob(x, y + 32, z, 35,"mob/spider.png");
                Level.spawnMob(x, y + 32, z, 32,"mob/zombie.png");
                Level.spawnMob(x, y + 32, z, 36,"mob/pigzombie.png");
                Entity.setPosition(Player.getEntity(), x, y + 36, z);
                Level.setTime(14000);
                    clientMessage("§4<Herobrine> You Like My Dungeon?");
               break;
               case 5:
                setTile(x -1, y + 1, z, 51);
                setTile(x, y + 1, z, 51);
                setTile(x + 1, y + 1, z, 51);
                setTile(x, y + 1, z -1, 51);
                setTile(x, y + 1, z + 1, 51);
                setTile(x + 1, y + 1, z + 1, 51);
                setTile(x + 1, y + 1, z -1, 51);
                setTile(x -1, y + 1, z + 1, 51);
                setTile(x -1, y + 1, z -1, 51);
                Entity.setFireTicks(Player.getEntity(), 15);
                clientMessage("§4<Herobrine> You Shall Burn!!!!");
               break;    
}
}
}


function deathHook(murder,victim)
{
if(murder==apple)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 260, 3, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 481, 2, 0);
}
if(victim==enderman)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 472, 3, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 471, 2, 0);}
}