Block.defineBlock(93, "Herobrine Totem", ["netherrack", 0], 1, false, 0);
Block.setDestroyTime(93, 5.0);
Block.setColor(93,[0xFF5555]);
Block.setShape(93, 0, 0, 0, 1, 1, 1);
var Herobrine = 0;

function useItem(x, y, z, itemId, blockId, side, works, itemDamage, blockDamage)
{
if(itemId==259 && blockId==87 && getTile(x, y -1, z)==93 && getTile(x, y -2, z)==41 && getTile(x, y -3, z)==41)
{
setTile(x, y -1, z, 97);
Herobrine = Level.spawnMob(x, y + 3, z, 35,"mob/Herobrine.png");
Entity.setHealth(Herobrine, 500);
Entity.setRenderType(Herobrine, 3);
Entity.setAnimalAge(Herobrine, 20);
Level.setTime(14000);
clientMessage("You Don't Know What You Just Did......");
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 100);}
}
