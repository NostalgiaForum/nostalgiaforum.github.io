ModPE.setItem(436,"skull_wither",0,"Lich Summoner");
var Lich = 0;

function useItem(x, y, z, itemId, blockId, side)
{
if(itemId==436 && blockId==160){
Lich = Level.spawnMob(x, y + 1, z, 34,"mob/Lich.png");
Entity.setHealth(Lich, 1250);
Entity.setCarriedItem(Lich, 435, 1, 0);
Entity.setNameTag(Lich, "Lich [BOSS]");
Entity.setAnimalAge(Lich, 7);
Entity.setRenderType(Lich, 3);
Minion = Level.spawnMob(x, y +1, z, 34,"mob/skeleton.png");
Entity.setHealth(Minion, 50);
Entity.setCarriedItem(Minion, 276, 1, 0);
Player.addItemInventory(436, -1);
setTile(x, y, z, 0);
}
}

function deathHook(attacker,victim)
{
if(Entity.getEntityTypeId(Lich)==34){
if(Lich > 0)//LichDrops
{
preventDefault();
Lich --;
ModPE.saveData (Level.getWorldDir() + "Lich", Lich);
Level.dropItem (Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 435, 1, 0);
Level.dropItem (Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 264, 40, 0);}
}
}