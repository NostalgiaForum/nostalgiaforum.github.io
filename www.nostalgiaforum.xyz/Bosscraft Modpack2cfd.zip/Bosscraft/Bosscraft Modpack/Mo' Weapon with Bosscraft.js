ModPE.setItem(466,"blaze_powder",0,"Fiery Fist (Tier 1)", 1);
ModPE.setItem(465,"gold_horse_armor",0,"Flaming Sword", 1);
ModPE.langEdit("item.flamingSword.name", "Flaming Sword");
ModPE.setItem(464,"fishing_rod_cast",0,"Diamond Giant Sword", 1);
ModPE.setItem(463,"blaze_powder",0,"Fiery Fist (Tier 2)", 1);
ModPE.setItem(462,"iron_horse_armor",0,"Iron Glove", 1);
ModPE.setItem(461,"name_tag",0,"Death Hook", 1);
ModPE.setItem(453,"gold_nugget",0,"Godzilla Sword", 1);
ModPE.setItem(452,"door_iron",0,"Godzilla's Claw", 1);
ModPE.setItem(437,"sword",0,"Ender Blade", 1);
ModPE.setItem(435,"blaze_rod",0,"Healing Scepter", 1);
ModPE.setItem(428,"sword",0,"Exploding Sword", 1);
ModPE.setItem(429,"bow_pulling",0,"The Ultimate Bow", 1);
ModPE.setItem(419,"potato_poisonous",3,"Bloody Sword", 1);
ModPE.setItem(187,"fish_raw",0,"Viper Blade", 1);
ModPE.setItem(414,"blaze_rod",0,"Snowball Gunner", 1);
ModPE.setItem(413,"blaze_rod",0,"TNT Launcher", 1);
ModPE.setItem(398,"hoe",0,"Scythe");
ModPE.setItem(183,"fireworks",0,"Ender Staff", 1);
Item.setMaxDamage(183, 500);
var i = 44;
var arrow;
var gui=true;
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var GUI;
var GUIs;
var guis=true;
var dtx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var digg=0;
var velX;
var velY;
var velZ;
var flame;
var dig;
var BladeUses = 4000;
var ClawsUses = 10000;
var GodzillaUses = 10000;
var FieryFistTier2Uses = 2500;
var FlamingSwordUses = 450;
var FieryFistUses = 2500;
var DiamondBigSwordUses = 1500;
var IronGloveUses = 1000;
var DeathHookUses = 2000;
var HealingUses = 400;

function modTick()
{
if(getCarriedItem()==429 && gui==true){
ctx.runOnUiThread(new java.lang.Runnable(){
  
run: function(){
  
try{

GUI = new android.widget.PopupWindow();
var layout = new android.widget.LinearLayout(ctx);
layout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
GUI.setContentView(layout);
var btn = new android.widget.Button(ctx);
var button = new android.widget.Button(ctx);
layout.addView(btn);
button.setText("Shoot");
GUI.setWidth(100);
GUI.setHeight(70);
GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLUE));
btn.setOnClickListener(new android.view.View.OnClickListener({ 
onClick: function(viewarg){ 
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,20*xx);
setVelY(arrow,20*zz);
setVelZ(arrow,20*yy);
Level.playSoundEnt(arrow, "random.bow", 100, 100);
Entity.setFireTicks(arrow, 100);
}
}));
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.RIGHT, 0, 150);
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.LEFT, 0, 100);
} catch (e){
print ("Error: "+e)
}
}});
gui=false;
}
if(getCarriedItem()!=429&&gui==false){
ctx.runOnUiThread(new java.lang.Runnable({ 
run: function(){ 
if(GUI != null){ 
GUI.dismiss();
GUI = null;
}
}})); 
gui=true;
}
}

function leaveGame(){
ctx.runOnUiThread(new java.lang.Runnable({ 
run: function(){ 
if(GUI != null){ 
GUI.dismiss();
GUI = null;
} 
}})); 
}


function useItem(x, y, z, itemId, blockId, side, itemDamage, blockDamage)
{

}
function initMod(){
}
function attackHook(attacker, victim) {
    function hurt(health) {
        if(Entity.getHealth(victim) > health) Entity.setHealth(victim, Entity.getHealth(victim) - health);
        else {
            Entity.setHealth(victim, 1);
            Level.explode(victim, 1.0);
        }
    }
    var x = Entity.getX(victim);
    var y = Entity.getY(victim);
    var z = Entity.getZ(victim);
    if(attacker == Player.getEntity()) switch(Player.getCarriedItem()){
       case 466:
            FieryFistUses--;
             hurt(53);
             Entity.setFireTick(victim, 15);
         break;
       case 187:
       hurt(5000);
       setVelY(2.5);
       Entity.setFireTicks(victim, 50);
       Level.explode(x, y, z, 2);
       Player.setHealth(Entity.getHealth(Player.getEntity()) +1);
         break;
       case 446:
            FieryFistUses--;
            hurt(6);
        break;
       case 465:
            FlamingSwordUses--;
            hurt(10);
            Entity.setFireTicks(victim, 6);
        break;
       case 464:
            DiamondBigSwordUses--;
            Entity.getVelX(victim);
            Entity.getVelY(victim);
            Entity.getVelZ(victim);
            hurt(15);
        break;
        case 183:
            DiamondBigSwordUses--;
            Entity.setVelY(victim, 3);
            hurt(7);
            Entity.setFireTicks(victim, 50);
        break;
       case 463:
            FieryFistTier2Uses--;
            hurt(85);
            Entity.setFireTicks(victim, 50);
        break;
       case 462:
            IronGloveUses--;
            hurt(25);
            Entity.setFireTicks(victim, 1000);
            Level.spawnMob(x, y + 1, z, 3);
            Level.setTile(x, y + 1, z, 51);
        break;
       case 461:
            DeathHookUses--;
            hurt(17);
            Entity.setFireTicks(victim, 1000);
            Level.setTime(14000);
        break;
       case 453:
            DeathHookUses--;
            hurt(1500);
            Entity.setFireTicks(victim, 10);
        break;
       case 452:
            ClawsUses--;
            hurt(150);
            Entity.setFireTicks(victim, 15);
         break;
        case 437:
             BladeUses--;
            hurt(30);
            Entity.setFireTicks(victim, 100000);
            Player.setHealth(10);
          break;
         case 398:
             BladeUses--;
            hurt(15);
            Player.setHealth(20);
            Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 472, 1, 0);
            Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ, "random.hurt" , 100, 100);
          break;
         case 419:
            FieryFistUses--;
            hurt(20);
        break;
         case 435:
             HealingUses--;
            hurt(3);
            Player.setHealth(Entity.getHealth(Player.getEntity())+2);
          break;
         case 428:
            FieryFistUses--;
            hurt(4);
            Level.explode(x, y, z, 3.0);
        break;
}

function destroyBlock() {
    if(Player.getCarriedItem() == 452) ClawsUses-= 10;
    if(Player.getCarriedItem() == 462) IronFistUses-= 50;
    if(Player.getCarriedItem() == 466) FieryFistUses-= 15;
    if(Player.getCarriedItem() == 465) FlamingSwordUses-=5;
    if(Player.getCarriedItem() == 464) DiamondBigSwordUses-= 10;
    if(Player.getCarriedItem() == 463) FieryFistTier2Uses-= 30;
    if(Player.getCarriedItem() == 461) DeathHookUses-= 20;
    if(Player.getCarriedItem() == 453) GodzillaUses-=100;
    if(Player.getCarriedItem() == 435) Healing-=1;
    if(Player.getCarriedItem() == 437) Ender-=1;
    if(Player.getCarriedItem() == 428) FieryFistUses-=500;
}

function modTick()
{

}
function procCmd(command)
{
var cmd = command.split(" ");
if(cmd[0] == "weapon")
{
addItemInventory(466,1);
addItemInventory(465,1);}
}
}