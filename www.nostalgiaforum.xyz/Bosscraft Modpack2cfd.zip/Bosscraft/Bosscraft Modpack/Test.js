
Item.setMaxDamage(453, 1000);

function attackHook(attacker, victim) {
	if(Player.getCarriedItem() == 453) { //If the player is holding My Stick Tool
		if(Player.getCarriedItemData() < 999) Entity.setCarriedItem(attacker, 453, Player.getCarriedItemCount(), Player.getCarriedItemData() + 1); //Increments the damage of My Stick Tool if the current damage is below 999 (one below the max damage)
		else { //Otherwise
			Level.playSoundEnt(attacker, "random.break", 100, 100); //Play the break sound
			Player.clearInventorySlot(Player.getSelectedSlotId());
}
if(Player.getCarriedItem() == 183){ 
		if(Player.getCarriedItemData() < 499) Entity.setCarriedItem(attacker, 193, Player.getCarriedItemCount(), Player.getCarriedItemData() + 2); //Increments the damage of My Stick Tool if the current damage is below 99 (one below the max damage)
		else { //Otherwise
			Level.playSoundEnt(attacker, "random.break", 100, 100); //Play the break sound
			Player.clearInventorySlot(Player.getSelectedSlotId());}
}
}
}

function destroyBlock(x, y, z, side)
{
if(Level.getTile(x, y, z)==174){
var luck = Math.floor(Math.random()*(4));
if (luck == 3) {
Level.destroyBlock(x, y, z, false);
Level.dropItem(x, y + 1, z, 0, 264, 1, 0);
} else if (luck == 2) {
Level.destroyBlock(x, y, z, false);
Level.dropItem(x, y + 1, z, 0, 265, 1, 0);
} else if (luck == 1) {
Level.explode(x, y, z, 5);}
}
}