var DRK_ID = 137
var TORCH_ID = 75
var MOB_ID = 100
var troll_ID = 76
var xray_ID = 33
var Xray_ID = 23
var victim = 0;
Block.defineBlock(DRK_ID, "Troll Block", ["obsidian", 0], 0, false, 0);
    Block.setDestroyTime(DRK_ID, 0.2);
    Block.setShape(DRK_ID, 0, 0, 0, 1, 1, 1);
    Block.setExplosionResistance(DRK_ID, 18, 000, 000);

Block.defineBlock(177, "Head", [["wool", 12], ["wool", 15]], 1, true, 7);
Block.setShape(177, 2/6, 0, 2/6, 4/5, 1/2, 4/5);
Block.setDestroyTime(177, 0.1);

Block.defineBlock(84, "Golden Apple Seeds", ["gold_block", 0], 1, false, 6);
Block.setDestroyTime(84, 0);
Block.setShape(84, 0, 0, 0, 1, 1/20, 1);

Block.defineBlock(99, "Golden Apple Seeds", [["flower_dandelion",6], 
["flower_dandelion",6],
["flower_dandelion",6], 
["flower_dandelion",6],   
["flower_dandelion",6], 
["flower_dandelion",6]],0,0,1);
Block.setDestroyTime(99, 0);
Block.setRenderLayer(99, 1);
Block.setColor(99,[ 0xFFFF55]);
Block.setShape(99, 0, 0, 0, 1, 1/20, 1);

Block.defineBlock(94, "Soul Sand", ["soul_sand", 0], 2, false, 0);
Block.setDestroyTime(94, .1);
Block.setShape(94, 0, 0, 0, 1, 1, 1);

Block.defineBlock(176, "Explosive Ore", ["coal_ore", 21], 0, false, 0);
Block.setDestroyTime(176, 3);
Block.setColor(176,[0x00AA00]);
Block.setShape(176, 0, 0, 0, 1, 1, 1);

Block.defineBlock(249, "Trampoline Pad", ["wool", 15], 2, false, 0);
Block.setDestroyTime(249, 0.5);
Block.setShape(249, 0, 0, 0, 1, 1, 1);

Block.defineBlock(118, "Death Planks", ["planks", 0], 17, false, 0);
Block.setDestroyTime(118, 2.5);
Block.setColor(118,[4456448]);
Block.setExplosionResistance(118, 100);
Block.setShape(118, 0, 0, 0, 1, 1, 1);

Block.defineBlock(144, "Landmine", ["stone", 0], 1, true, 7);
Block.setDestroyTime(144, 2.5);
Block.setShape(144, 0, 0, 0, 1, 1/16, 1);

Block.defineBlock(119, "Death Slabs", ["planks", 0], 17, false, 0);
Block.setDestroyTime(119, 2.5);
Block.setColor(119,[4456448]);
Block.setRenderLayer(119, 0);
Block.setExplosionResistance(119, 100);
Block.setShape(119, 0, 0, 0, 1, 1/2, 1);

Block.defineBlock(120, "Death Tree Sapling", [["sapling", 0], ["sapling", 0], ["sapling", 0], ["sapling", 0], ["sapling", 0], ["sapling", 0]], 6, true, 1);
Block.setColor(120,[4456448]);
Block.setRenderLayer(120, 2);
Block.setDestroyTime(120, .1/2);
Block.setShape(120, 0, 0, 0, 1, 1, 1);

Block.defineBlock(143, "Death Stairs", ["planks", 0], 17, false, 10);
Block.setDestroyTime(143, 2.5);
Block.setColor(143,[4456448]);
Block.setShape(143, 0, 0, 0, 1, 1, 1);

Block.defineBlock(97,"Herobrine Totem",["netherrack",0], 0, false, 0);
Block.setDestroyTime(97, 5.0);
Block.setColor(97,[4456448]);
Block.setLightLevel(97, 15);
Block.setRenderLayer(97,1);

Block.defineBlock(110, "Obsidian Pillar", ["obsidian", 49], 49, false, 0);
Block.setDestroyTime(110, 5);
Block.setShape(110, 0, 0, 0, 1, 2, 1);

Block.defineBlock(TORCH_ID, "Godzilla Spawn Block", ["enchanting_table_top", 0], 1, false, 0);
Block.setDestroyTime(TORCH_ID, 100.0);
Block.setShape(TORCH_ID, 0, 0, 0, 13, 13, 13);

Block.defineBlock(MOB_ID, "Block of Diamond", [["diamond_block", 11], ["diamond_block", 11], ["diamond_block", 11], ["diamond_block", 11]], 11, false, 0);
Block.setDestroyTime(MOB_ID, 1.0);
Block.setShape(MOB_ID, 0, 0, 0, 1, 1, 1);

Block.defineBlock(troll_ID, "Block of Emerald", ["emerald_block", 11], 11, false, 0);
Block.setDestroyTime(troll_ID, 1.0);
Block.setShape(troll_ID, 0, 0, 0, 1, 1, 1);

Block.defineBlock(xray_ID, "Bloody Ore", ["redstone_ore", 0], 1, false, 0);
Block.setDestroyTime(xray_ID, 3);
Block.setShape(xray_ID, 0, 0, 0, 1, 1, 1);

Block.defineBlock(106, "Aqua Block", ["diamond_block", 0], 1, false, 0);
Block.setDestroyTime(106, 3.4);
Block.setColor(106,[4456428]);
Block.setShape(106, 0, 0, 0, 1, 1, 1);

Block.defineBlock(Xray_ID, "Bloody Block", ["diamond_block", 0], 1, false, 0);
Block.setDestroyTime(Xray_ID, 3.4);
Block.setColor(Xray_ID,[4456448]);
Block.setShape(Xray_ID, 0, 0, 0, 1, 1, 1);

Block.defineBlock(121, "Ender Spirit Spawn Block", ["end_stone", 0], 1, false, 0);
Block.setDestroyTime(121, 7);
Block.setShape(121, 0, 0, 0, 1, 1, 1);

Block.defineBlock(122, "Ender Ore", ["dragon_egg", 0], 1, false, 0);
Block.setDestroyTime(122, 7);
Block.setShape(122, 0, 0, 0, 1, 1, 1);

Block.defineBlock(160, "Lich Spawn Block", ["mob_spawner", 0], 1, false, 0);
Block.setDestroyTime(160, 5);
Block.setShape(160, 0, 0, 0, 1, 1, 1);
Block.setColor(160,[4456448]);

Block.defineBlock(186, "Trapped Diamond Block", ["diamond_block", 0], 0, false, 0);
Block.setDestroyTime(186, 3);
Block.setShape(186, 0, 0, 0, 1, 1, 1);

Block.defineBlock(185, "Overpower Block", ["gold_block", 0], 0, false, 0);
Block.setDestroyTime(185, 3);
Block.setShape(185, 0, 0, 0, 1, 1, 1);

Block.defineBlock(88, "Basic Ender Alter", [["enchanting_table_side", 0], ["enchanting_table_top", 0], ["enchanting_table_bottom", 0]], true, 5, 0);
Block.setDestroyTime(88, 8);
Block.setColor(88,[0x0000AA]);
Block.setShape(88, 0, 0, 0, 1, 7/8, 1);

Block.defineBlock(52, "Basic Ender Alter", [["enchanting_table_side", 0], ["enchanting_table_top", 0], ["enchanting_table_bottom", 0]], true, 5, 0);
Block.setDestroyTime(52, 8);
Block.setColor(52,[0x00AA00]);
Block.setShape(52, 0, 0, 0, 1, 7/8, 1);

Block.defineBlock(55, "Basic Ender Alter", [["enchanting_table_side", 0], ["enchanting_table_top", 0], ["enchanting_table_bottom", 0]], true, 5 ,0);
Block.setDestroyTime(55, 8);
Block.setColor(55,[4456449]);
Block.setShape(55, 0, 0, 0, 1, 7/8, 1);

Block.defineBlock(70, "Basic Ender Alter", [["enchanting_table_side", 0], ["enchanting_table_top", 0], ["enchanting_table_bottom", 0]], true, 5, 0);
Block.setDestroyTime(70, 8);
Block.setColor(70,[4456546]);
Block.setShape(70, 0, 0, 0, 1, 7/8, 1);

Block.defineBlock(28, "Advanced Ender Alter",[["enchanting_table_side", 0], ["enchanting_table_top", 0], ["enchanting_table_side", 0], ["enchanting_table_side", 0]], true, 5, 0);
Block.setDestroyTime(28, 8);
Block.setColor(28,[4456678]);
Block.setRenderLayer(28, 0);
Block.setShape(28, 0, 0, 0, 1, 7/8, 1);

Block.defineBlock(159, "Uncrafting Table",[["crafting_table", 58], ["crafting_table", 0], ["crafting_table", 58], ["crafting_table", 58], ["crafting_table", 58]], 17, false, 0);
Block.setDestroyTime(159, 2.5);
Block.setColor(159,[0x555555]);
Block.setShape(159, 0, 0, 0, 1, 1, 1);

Block.defineBlock(174, "Mysterious Ore", [["gold_ore", 0], ["diamond_ore", 0], ["redstone_ore", 0], ["emerald_ore", 0], ["iron_ore", 0], ["coal_ore", 0]], 0, false, 0);
Block.setDestroyTime(174, 1);
Block.setShape(174, 0, 0, 0, 1, 1, 1);
Block.setRenderLayer(174, 0);

Block.defineBlock(248, "Trampoline", ["wool", 0], 35, true, 7);
Block.setDestroyTime(248, 0.5);
Block.setShape(248, 0, 0, 0, 1, 7/8, 1);

Block.defineBlock(175, "Satanic Grass", [["grass", 2], ["grass", 0], ["grass", 2], ["grass", 2], ["grass", 2]], 3, false, 0);
Block.setDestroyTime(175, 0.5);
Block.setColor(175,[4456546]);
Block.setShape(175, 0, 0, 0, 1, 1, 1);
Block.setLightLevel(175, 5);
Block.setRenderLayer(175, 0);


function renderBlockHook(blockId, x, y, z)
{
if(Block.getRenderType(blockId) == 28);
}

function renderWonderBlock(x, y, z){
BlockRenderer.renderCross(57, x, y + 1, z);
BlockRenderer.renderTorch(50, x, y + 1, z);
}

function useItem(x, y, z, itemId, blockId, side, itemDamage, blockDamage)
{
Item.addCraftRecipe(248,5,0,[35,5,0,265,4,0]);
Item.addCraftRecipe(249,5,0,[35,5,15,265,4,0]);
if(itemId==289 && blockId==16){
setTile(x, y, z, 176);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.stone", 100, 100);
}
if(itemId==450 && blockId==137){
getTile(x,y,z);
setTile(x,y,z,100)
Block.setLightLevel(100,15);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 30);
}
if(itemId==450 && blockId==100){
getTile(x,y,z);
setTile(x,y,z,76)
Block.setLightLevel(76,15);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 30);
}
if(itemId==450 && blockId==76){
getTile(x,y,z);
setTile(x,y,z,137)
Block.setLightLevel(137,15);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 30);
}
if(itemId==472 && blockId==88){
setTile(x, y, z, 52);
clientMessage("Now Give Me A Light Soul");
Player.addItemInventory(472, -1);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==471 && blockId==52){
setTile(x, y, z, 55);
clientMessage("Now Give Me A Death Diamond");
Player.addItemInventory(471, -1);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==264 && blockId==55){
setTile(x, y, z, 70);
clientMessage("Now Give Me A Death Diamond Block");
Player.addItemInventory(264, -1);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==57 && blockId==70){
setTile(x, y, z, 28);
clientMessage("You Have Made The Advanced Alter!");
Player.addItemInventory(57, -1);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 100);
}
if(itemId==289 && blockId==28){
Player.addItemInventory(289, -1);
Level.dropItem(x, y + 1, z, 0, 488, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==288 && blockId==28){
Player.addItemInventory(288, -1);
Level.dropItem(x, y + 1, z, 0, 492, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==352 && blockId==28){
Player.addItemInventory(352, -1);
Level.dropItem(x, y + 1, z, 0, 491, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==351 && itemDamage==15 && blockId==28){
Player.addItemInventory(351, -1, 15);
Level.dropItem(x, y + 1, z, 0, 491, 2, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==262 && blockId==28){
Player.addItemInventory(262, -1);
Level.dropItem(x, y + 1, z, 0, 491, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==287 && blockId==28){
Player.addItemInventory(287, -1);
Level.dropItem(x, y + 1, z, 0, 490, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==266 && blockId==28){
Player.addItemInventory(266, -1);
Level.dropItem(x, y + 1, z, 0, 489, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
}
if(itemId==450 && blockId==174){
setTile(x, y, z, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.click", 100, 100);
Level.dropItem(x, y, z, 0, 174, 1, 0);
}
if(Level.getTile(x, y, z) == 175){
clientMessage("I Wouldn't do that if I were you!");
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
}
if(itemId==397){
Level.setTile(x, y + 1, z, 177);
Player.addItemInventory(397, -1);
}
if(itemId==472 && blockId==159){
Player.addItemInventory(472, -1);
Level.dropItem(x, y + 1, z, 0, 264, 1, 0);
Level.dropItem(x, y + 1, z, 0, 265, 1, 0);
Level.dropItem(x, y + 1, z, 0, 266, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 100);
}
if(itemId==471 && blockId==159){
Player.addItemInventory(471, -1);
Level.dropItem(x, y + 1, z, 0, 472, 1, 0);
Level.dropItem(x, y + 1, z, 0, 264, 1, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100000, 10000);
}
if(itemId==57 && blockId==159){
Player.addItemInventory(57, -1);
Level.dropItem(x, y + 1, z, 0, 264, 9, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 100);
}
if(itemId==41 && blockId==159){
Player.addItemInventory(41, -1);
Level.dropItem(x, y + 1, z, 0, 266, 9, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 100);
}
if(itemId==42 && blockId==159){
Player.addItemInventory(42, -1);
Level.dropItem(x, y + 1, z, 0, 265, 9, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 100);
}
if(itemId==398 && blockId==2){
setTile(x, y, z, 175);

Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
Player.addItemInventory(398, -1);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.break", 100, 100);
Level.dropItem(x, y + 1, z, 0, 472, 1, 0);
Level.setTime(14000);
}
if(itemId==23 && blockId==159){
Player.addItemInventory(23, -1);
Level.dropItem(x, y + 1, z, 0, 444, 9, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 109);
}
if(itemId==472 && blockId==175){
Level.spawnMob(x, y + 1, z, 32,"mob/iz.png");
Level.dropItem(x, y + 1, z, 0, 289, 1, 0);
Player.addItemInventory(472, -1);
}
if(itemId==276 && blockId==175){
Level.dropItem(x, y + 1, z, 0, 175, 1, 0);
Player.setHealth(Entity.getHealth(Player.getEntity())-10);
setTile(x, y, z, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 100);
}
}

function destroyBlock(x, y, z, side)
{
if(Level.getTile(x, y, z) == 186){
setTile(x, y, z, 0);
Overlord = Level.spawnMob(x, y + 3, z, 35,"mobs/Overlord.png");
Entity.setHealth(Overlord, 1250);
Entity.setRenderType(Overlord, 3);
Entity.setAnimalAge(Overlord, 20);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100000, 100);
Level.setTime(14000);
Level.spawnMob(x -5, y -9, z, 36);
Level.spawnMob(x -5, y -9, z, 36);
Level.spawnMob(x -5, y -9, z, 36);
Level.spawnMob(x +5, y -9, z, 36);
Level.spawnMob(x +5, y -9, z, 36);
Level.spawnMob(x +5, y -9, z, 36);
}
if(Level.getTile(x, y, z) == 159){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 100);
}
if(Level.getTile(x, y, z) == 18){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
}
if(Level.getTile(x, y, z) == 17){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 100);
}
if(Level.getTile(x, y, z) == 175){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
Level.setTime(14000);
Level.spawnMob(getPlayerX(), getPlayerY(), getPlayerZ(), 32,"mob/zombie.png");
clientMessage("§4<Bosscraft> don't destroy the satanic grass!");
}
if(Level.getTile(x, y, z) == 3){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.gravel", 100, 100);
}
if(Level.getTile(x, y, z) == 118){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 100);
}
if(Level.getTile(x, y, z) == 119){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.wood", 100, 100);
}
if(Level.getTile(x, y, z) == 12){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.sand", 100000, 1000000);
}
if(Level.getTile(x, y, z) == 84){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
Level.dropItem(x, y + 1, z, 0, 399, 2, 0);
Level.dropItem(x, y + 1, z, 0, 481, 3, 0);
}
if(Level.getTile(x, y, z) == 99){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
}
if(Level.getTile(x, y, z) == 102){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.glass", 100, 100);
}
if(Level.getTile(x, y, z) == 20){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.glass", 100, 100);
}
if(Level.getTile(x, y, z) == 60){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.gravel", 100, 100);
}
if(Level.getTile(x, y, z) == 177){
Level.dropItem(x, y, z, 0, 397, 1, 0);
}
if(Level.getTile(x, y, z) == 97){
Level.destroyBlock(x, y, z, false);
Level.dropItem(x, y, z, 0, 87, 1, 0);
}
if(Level.getTile(x, y, z) == MOB_ID){
Level.explode(x, y, z, 10);
clientMessage("<server> You Have Died");
}
if(Level.getTile(x, y, z) == 176){
Level.explode(x, y, z, 3.0);
Level.dropItem(x, y + 2, z, 0, 289, 5, 0);
}
if(Level.getTile(x, y, z) == 249){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.cloth", 100, 100);
}
if(Level.getTile(x, y, z) == 248){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.cloth", 100, 100);
}
}

function modTick(){
  x = getPlayerX(); 
  y = getPlayerY(); 
  z = getPlayerZ();
if(getTile(x, y -2, z) == 94)
{
Entity.setSneaking(Player.getEntity(), true);
}
if(getTile(x, y -2, z) == 0)
{
Entity.setSneaking(Player.getEntity(), false);
}
if(getTile(x, y -2, z) == 186)
{
setTile(x, y -2, z, 0);
Overlord = Level.spawnMob(x, y + 3, z, 35,"mobs/Overlord.png");
Entity.setHealth(Overlord, 1250);
Entity.setRenderType(Overlord, 3);
Entity.setAnimalAge(Overlord, 20);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100000, 100);
Level.setTime(14000);
}
if(getTile(x, y -2, z) == 248)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.cloth", 100, 100);
setVelY(Player.getEntity(), 1.25);
Player.setHealth(20);
}
if(getTile(x, y -2, z) == 249)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.cloth", 100, 100);
Player.setHealth(20);
}
if(getTile(x, y -2, z) == 186)
{
setTile(x, y -2, z, 0);
Overlord = Level.spawnMob(x, y + 3, z, 35,"mobs/Overlord.png");
Entity.setHealth(Overlord, 1250);
Entity.setRenderType(Overlord, 3);
Entity.setAnimalAge(Overlord, 20);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100000, 100);
Level.setTime(14000);
Level.spawnMob(x -5, y -9, z, 36);
Level.spawnMob(x -5, y -9, z, 36);
Level.spawnMob(x -5, y -9, z, 36);
Level.spawnMob(x +5, y -9, z, 36);
Level.spawnMob(x +5, y -9, z, 36);
Level.spawnMob(x +5, y -9, z, 36);
}
if(getTile(x, y -2, z) == 94)
{
Entity.setSneaking(Player.getEntity(), true);
}
if(getTile(x, y -2, z) == 0)
{
Entity.setSneaking(Player.getEntity(), false);
}
if(getTile(x, y -2, z) == 144)
{
Level.explode(x, y, z, 10);}
}

