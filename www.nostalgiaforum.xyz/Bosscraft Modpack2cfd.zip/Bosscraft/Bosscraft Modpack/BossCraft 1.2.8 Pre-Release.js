ModPE.setItem(503,"flint_and_steel",0,"Flint and Steel [U]", 1);
ModPE.setItem(505,"apple_golden",0,"??? [WIP]", 1);
ModPE.setItem(506,"blaze_rod",0,"Instant Miner", 1);
ModPE.langEdit("desc.instantMiner", "Mines Everything Instantly");
ModPE.setItem(507,"stick",0,"Overpower Stick", 1);
ModPE.setItem(508,"blaze_rod",0,"Instant Farmer", 1);
ModPE.setItem(509,"ender_eye",0,"EnderLord Summoner");
ModPE.setItem(510,"ruby",0,"Herobrine Summoner");
ModPE.setItem(511,"spider_eye",0,"Demonic Spider Summoner");
ModPE.setItem(502,"nether_wart",0,"Evil Notch Summoner");
ModPE.setFoodItem(501,"cookie",17,20,"Overpower Cookie");
ModPE.setItem(500,"fireball",0,"Fire Demon Summoner");
ModPE.setItem(498,"blaze_rod",0,"Skeleton Warrior Summoner");
ModPE.setItem(496,"egg",0,"Derpy Squid Summoner");
ModPE.setFoodItem(495,"gold_ingot",18,6,"Butter");
ModPE.setFoodItem(494,"nether_wart",19,2,"Cranberry");
ModPE.setItem(493,"redstone_dust",0,"Minotaur Summoner");
ModPE.setItem(492,"spawn_egg",0,"Spawn Zombie", 65);
ModPE.setItem(491,"spawn_egg",0,"Spawn Skeleton", 65);
ModPE.setItem(490,"spawn_egg",0,"Spawn Spider", 65);
ModPE.setItem(489,"spawn_egg",0,"Spawn Zombie Pigman", 65);
ModPE.setItem(488,"spawn_egg",0,"Spawn Creeper", 65);
ModPE.setItem(487,"spawn_egg",0,"Spawn Steve", 65);
ModPE.setItem(486,"gold_nugget",0,"Gold Nugget");
ModPE.setFoodItem(485,"rotten_flesh",20,3,"Rotten Flesh");
ModPE.setItem(484,"spawn_egg",1,"Spawn Dungeon Beast");
ModPE.setItem(483,"nether_star",0,"Jockey Boss Summoner");
ModPE.setItem(482,"iron_ingot",0,"Headless Horror Summoner");
ModPE.setFoodItem(481,"apple_golden",22,7,"Golden Apple");
ModPE.setItem(480,"spawn_egg",0,"Spawn Apple Cow", 65);
ModPE.setFoodItem(479,"egg",23,1,"Editble Egg");
ModPE.setItem(478,"glowstone_dust",0,"Shiny Dust", 1);
ModPE.setItem(477,"charcoal",0,"Grim Reaper Summoner");
ModPE.setItem(497,"ruby",0,"Lava Creeper Summoner");
ModPE.setItem(499,"diamond",0,"Water Creeper Summoner");
ModPE.setItem(476,"blaze_rod",0,"Magic Pencil", 1);
ModPE.setItem(475,"spawn_egg",0,"Spawn Infected Zombie", 65);
ModPE.setItem(474,"spawn_egg",0,"Spawn Mummy", 65);
ModPE.setFoodItem(473,"egg",0,-10,"Death Egg");
ModPE.setFoodItem(472,"ender_pearl",40,-1,"Dark Soul", 64);
ModPE.setFoodItem(471,"ender_eye",41,1,"Light Soul", 64);
ModPE.setFoodItem(470,"cookie",42,1,"Cookie");
ModPE.setItem(469,"fireball",0,"Fireball");
ModPE.setItem(468,"blaze_rod",0,"Golden Rod");
ModPE.setItem(460,"potion_bottle_empty",0,"Glass Bottle");
ModPE.setFoodItem(424,"experience_bottle",14,20,"Regeneration Potion", 1);
ModPE.setFoodItem(394,"ruby",13,1,"Soul Gem");
ModPE.setFoodItem(423,"experience_bottle",14,-17,"Half Health Potion", 1);
ModPE.setItem(451,"spawn_egg",0,"Spawn Exploding Chicken", 65);
ModPE.setItem(450,"iron_ingot",0,"Wrench", 1);
ModPE.setItem(449,"spawn_egg",0,"Spawn Troll", 65);
ModPE.setItem(446,"lead",0,"Bloody Pickaxe", 1);
ModPE.setItem(444,"brewing_stand",0,"Bloody Gem"); 
ModPE.setItem(443,"stick",0,"Soul Staff", 1);
ModPE.setItem(442,"book_enchanted",0,"Bosscraft Guide", 1);
ModPE.setItem(441,"map_empty",0,"Ender Spirit Summoner");
ModPE.setItem(440,"fireworks_charge",0,"Ender Soul Fragment");
ModPE.setItem(439,"blaze_rod",0,"Ender Wand", 1);
ModPE.setItem(438,"spider_eye_fermented",0,"Ender Orb");
ModPE.setItem(434,"quiver",0,"Magic Eraser", 1);
ModPE.setItem(431,"magma_cream",0,"Pharaoh Summoner");
ModPE.setItem(430,"blaze_rod",0,"Removing Staff");
ModPE.setItem(427,"blaze_rod",0,"Instant Miner [U]");
ModPE.setItem(426,"blaze_rod",0,"Instant Farmer [U]");
ModPE.setItem(425,"fishing_rod_uncast",0,"Bloody Axe");
ModPE.setItem(411,"empty_armor_slot_helmet",0,"Godzilla Helmet");
ModPE.setItem(410,"empty_armor_slot_chestplate",0,"Godzilla Chestplate");
ModPE.setItem(409,"empty_armor_slot_leggings",0,"Godzilla Leggings");
ModPE.setItem(408,"empty_armor_slot_boots",0,"Godzilla Boots");
ModPE.setItem(407,"quiver",0,"Launcher");
ModPE.setItem(399,"seeds_pumpkin",0,"Golden Apple Seeds", 64);
ModPE.setItem(402,"slimeball",0,"Slime Beast Summoner");
ModPE.setItem(401,"coal",0,"Nightmare Summoner");
ModPE.setItem(189,"skull_creeper",1,"Obsidian Helmet");
ModPE.setItem(190,"skull_skeleton",1,"Obsidian Chestplate");
ModPE.setItem(191,"skull_wither",1,"Obsidian Leggings");
ModPE.setItem(192,"skull_zombie",1,"Obsidian Boots");
     var Zombie = 0;
     Applecount ++;
     var instructor = 0;
     var p = 0;
     var SpawnY = 0;
     var SpawnZ = 0;
     var spawnTick = 0;
     var walking = false;
     var hell = 0;
     var arrow;
var gui=true;
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var GUI;
     var golem = 0;
     var Friend = 0;
     var Applecount = 0;
     var Ender = 0;
     var Overlord = 0;
     var EnderLord = 0;
     var Clone = 0;
     var EvilNotch = 1;
     var DemonicSpider = 0;
     var Herobrine = 0;
     var FireDemon = 0;
     var SkeletonWarrior = 0;
     var DerpySquid = 0;
     var Minotaur = 0;
     var PigZombie = 0;
     var Pumpkin = 0;
     var Cow = 0;
     var Grim = 0;
     var lc = 0;
     var wc = 0;
     var Apple = 0;
     var souls = 0
     var hs = 0;
     var Troll = 0;
     var Godzilla = 0;
     var Glass = 0;
     var strength = 0;
     var victim = 0;
     var tX, tY, tZ;

function addEndermanRenderType(renderer) 
{
    var model = renderer.getModel();
     
    var head = model.getPart("head");
    var body = model.getPart("body");
    var rarm = model.getPart("rightArm");
    var larm = model.getPart("leftArm");
    var rleg = model.getPart("rightLeg");
    var lleg = model.getPart("leftLeg");
     
    head.clear();
    head.setTextureOffset(0, 12);
    head.addBox(-4, -24, -4, 8, 8, 8);
 
    body.clear();
    body.setTextureOffset(0, 12);
    body.addBox(-4, -16, -2, 8, 12, 4);
 
    rarm.clear();
    rarm.setTextureOffset(0, 12);
    rarm.addBox(-1, -18, -2, 2, 30, 2);
    rarm.addBox(-1, 8, -16, 2, 2, 30);
    rarm.addBox(-3, 6, -19, 6, 6, 6);
 
    larm.clear();
    larm.setTextureOffset(0, 12);
    larm.addBox(-1,-18,-2, 2, 30, 2);
    larm.addBox(-1, 8, -16, 2, 2, 30);
    larm.addBox(-3, 6, -19, 6, 6, 6);
 
    rleg.clear();
    rleg.setTextureOffset(0, 12);
    rleg.addBox(-1, -18, 0, 2, 30, 2);
 
    lleg.clear();
    lleg.setTextureOffset(0, 12);
    lleg.addBox(-1, -18, 0, 2, 30, 2);
}

var EndermanRenderType= Renderer.createHumanoidRenderer();
addEndermanRenderType(EndermanRenderType);

function addDemonToRenderer(renderer)
{
var model = renderer.getModel();
var head = model.getPart("head").clear();
head.addBox(-20, -80, -10, 30, 30, 30);
head.addBox(-30, -90, -10, 10, 30, 10);
head.addBox(10, -90, -10, 10, 30, 10);
var body = model.getPart("body").clear();
body.addBox(-25, -50, -10, 35, 35, 35);
body.addBox(-15, -35.5, -5, 10, 30, 45.5);
body.addBox(-0, -35.5, -5, 10, 30, 45.5);
body.addBox(-15, -35.5, -5, 10, 50, 10);
body.addBox(-0, -35.5, -5, 10, 50, 10);
var rarm = model.getPart("rightArm").clear();
rarm.addBox(15, -50, -10, 20, 40, 20);
var larm = model.getPart("leftArm").clear();
larm.addBox(-40, -50, -10, 20, 40, 20);
var rleg = model.getPart("rightLeg").clear();
rleg.addBox(5, -25, -10, 20, 35.5, 20);
var lleg = model.getPart("leftLeg").clear();
lleg.addBox(-30, -25, -10, 20, 35.5, 20);
}

var DemonRenderer = Renderer.createHumanoidRenderer();
addDemonToRenderer(DemonRenderer);

function useItem(x, y, z, itemId, blockId, side, itemDamage, blockDamage)
{
if(itemId==183 && blockId==49){
Entity.setRenderType(Player.getEntity(), EndermanRenderType.renderType);
Player.setHealth(Entity.getHealth(Player.getEntity()),+50);
}
if(itemId==505){
setTile(x,y+11,z,186);
setTile(x+1,y+11,z,57);
setTile(x-1,y+11,z,57);
setTile(x,y+11,z+1,57);
setTile(x,y+11,z-1,57);
setTile(x+1,y+11,z+1,57);
setTile(x+1,y+11,z-1,57);
setTile(x-1,y+11,z+1,57);
setTile(x-1,y+11,z-1,57);
setTile(x+1,y+11,z+1,57);
setTile(x-1,y+11,z+1,57);
setTile(x-1,y+1,z+1,41);
setTile(x-1,y+2,z+1,41);
setTile(x-1,y+3,z+1,41);
setTile(x-1,y+4,z+1,41);
setTile(x-1,y+5,z+1,41);
setTile(x-1,y+6,z+1,41);
setTile(x-1,y+7,z+1,41);
setTile(x-1,y+8,z+1,41);
setTile(x-1,y+9,z+1,41);
setTile(x+1,y+10,z+1,41);
setTile(x+1,y+1,z+1,41);
setTile(x+1,y+2,z+1,41);
setTile(x+1,y+3,z+1,41);
setTile(x+1,y+4,z+1,41);
setTile(x+1,y+5,z+1,41);
setTile(x+1,y+6,z+1,41);
setTile(x+1,y+7,z+1,41);
setTile(x+1,y+8,z+1,41);
setTile(x+1,y+9,z+1,41);
setTile(x+1,y+10,z+1,41);
setTile(x-1,y+1,z-1,41);
setTile(x-1,y+2,z-1,41);
setTile(x-1,y+3,z-1,41);
setTile(x-1,y+4,z-1,41);
setTile(x-1,y+5,z-1,41);
setTile(x-1,y+6,z-1,41);
setTile(x-1,y+7,z-1,41);
setTile(x-1,y+8,z-1,41);
setTile(x-1,y+9,z-1,41);
setTile(x-1,y+10,z-1,41);
setTile(x+1,y+1,z-1,41);
setTile(x+1,y+2,z-1,41);
setTile(x+1,y+3,z-1,41);
setTile(x+1,y+4,z-1,41);
setTile(x+1,y+5,z-1,41);
setTile(x+1,y+6,z-1,41);
setTile(x+1,y+7,z-1,41);
setTile(x+1,y+8,z-1,41);
setTile(x+1,y+9,z-1,41);
setTile(x+1,y+10,z-1,41);
setTile(x+1,y+1,z+1,41);
setTile(x+1,y+2,z+1,41);
setTile(x+1,y+3,z+1,41);
setTile(x+1,y+4,z+1,41);
setTile(x+1,y+5,z+1,41);
setTile(x+1,y+6,z+1,41);
setTile(x+1,y+7,z+1,41);
setTile(x+1,y+8,z+1,41);
setTile(x+1,y+9,z+1,41);
setTile(x+1,y+10,z+1,41);
setTile(x-1,y+10,z+1,41);
setTile(x,y+1,z,41);
setTile(x,y+2,z,41);
setTile(x,y+3,z,41);
setTile(x,y+4,z,41);
setTile(x,y+5,z,41);
setTile(x,y+6,z,41);
setTile(x,y+7,z,41);
setTile(x,y+8,z,41);
setTile(x,y+9,z,41);
setTile(x,y+10,z,41);
setTile(x+1,y+1,z,41);
setTile(x+1,y+2,z,41);
setTile(x+1,y+3,z,41);
setTile(x+1,y+4,z,41);
setTile(x+1,y+5,z,41);
setTile(x+1,y+6,z,41);
setTile(x+1,y+7,z,41);
setTile(x+1,y+8,z,41);
setTile(x+1,y+9,z,41);
setTile(x+1,y+10,z,41);
setTile(x-1,y+1,z,41);
setTile(x-1,y+2,z,41);
setTile(x-1,y+3,z,41);
setTile(x-1,y+4,z,41);
setTile(x-1,y+5,z,41);
setTile(x-1,y+6,z,41);
setTile(x-1,y+7,z,41);
setTile(x-1,y+8,z,41);
setTile(x-1,y+9,z,41);
setTile(x-1,y+10,z,41);
setTile(x,y+1,z-1,41);
setTile(x,y+2,z-1,41);
setTile(x,y+3,z-1,41);
setTile(x,y+4,z-1,41);
setTile(x,y+5,z-1,41);
setTile(x,y+6,z-1,41);
setTile(x,y+7,z-1,41);
setTile(x,y+8,z-1,41);
setTile(x,y+9,z-1,41);
setTile(x,y+10,z-1,41);
setTile(x,y+1,z+1,41);
setTile(x,y+2,z+1,41);
setTile(x,y+3,z+1,41);
setTile(x,y+4,z+1,41);
setTile(x,y+5,z+1,41);
setTile(x,y+6,z+1,41);
setTile(x,y+7,z+1,41);
setTile(x,y+8,z+1,41);
setTile(x,y+9,z+1,41);
setTile(x,y+10,z+1,41);
Player.addItemInventory(505, -1, 0);
}
if(itemId==395 && getTile(x, y, z)==87 && getTile(x, y +1, z)==87){
Entity.setRenderType(Player.getEntity(), DemonRenderer.renderType);
Entity.setMobSkin(Player.getEntity(), "mob/FireDemon.png");
setTile(x, y, z, 0);
setTile(x, y +1, z, 0);
}
if(itemId==411){
Player.setArmorSlot(0, 411, 0);
Player.addItemInventory(411, -1);
Player.setHealth(Entity.getHealth(Player.getEntity()) +150);
Entity.setMobSkin(Player.getEntity(), "armor/Godzilla_armor.png");
}
if(itemId==410){
Player.setArmorSlot(1, 410, 0);
Player.addItemInventory(410, -10);
Player.setHealth(Entity.getHealth(Player.getEntity()) +350);
Entity.setMobSkin(Player.getEntity(), "armor/Godzilla_armor.png");
}
if(itemId==409){
Player.setArmorSlot(2, 409, 0);
Player.addItemInventory(409, -1);
Player.setHealth(Entity.getHealth(Player.getEntity()) +135);
Entity.setMobSkin(Player.getEntity(), "armor/Godzilla_armor.png");
}
if(itemId==408){
Player.setArmorSlot(3, 408, 0);
Player.addItemInventory(408, -1);
Player.setHealth(Entity.getHealth(Player.getEntity()) +120);
Entity.setMobSkin(Player.getEntity(), "armor/Godzilla_armor.png");
}
if(itemId == 509){
EnderLord = Level.spawnMob(x, y + 1, z, 35,"mob/EnderSkeleton.png");
clientMessage(ChatColor.BLUE + "EnderLord: PREPARE TO DIE YOU EMORTAL FOOL!");
Entity.setHealth(EnderLord, 355);
Entity.setCarriedItem(EnderLord,276,1,0);
Entity.setRenderType(EnderLord, EndermanRenderType.renderType);
Entity.setAnimalAge(EnderLord, 10);
Entity.setNameTag(EnderLord, "EnderLord [BOSS]");
Player.addItemInventory(509, -1);
}else if(itemId == 510){
Herobrine = Level.spawnMob(x, y + 1, z, 32,"mob/Herobrine.png");
clientMessage(ChatColor.RED + "Herobrine: ESUOH RUOY NRUB I!");
Entity.setHealth(Herobrine, 500);
Entity.setCarriedItem(Herobrine,276,1,0);
Entity.setRenderType(Herobrine, 3);
Entity.setAnimalAge(Herobrine, 10);
Entity.setNameTag(Herobrine, "Herobrine [BOSS]");
Player.addItemInventory(510, -1);
}else if(itemId == 511){
DemonicSpider = Level.spawnMob(x, y + 1, z, 35,"mob/obsidian.png");
clientMessage("Demonic Spider: YOUR BUGGING ME!");
Entity.setHealth(DemonicSpider, 250);
Entity.setNameTag(DemonicSpider, "Demonic Spider [MINI BOSS]");
Entity.setAnimalAge(DemonicSpider, 5);
Player.addItemInventory(511, -1);
}else if(itemId == 502){
EvilNotch = Level.spawnMob(x, y + 1, z, 34,"mob/EvilNotch.png");
clientMessage(ChatColor.RED + "Evil Notch: YOU ARE SUCH A NOOB!")
Entity.setHealth(EvilNotch, 730);
Entity.setCarriedItem(EvilNotch,276,1,0);
Entity.setRenderType(EvilNotch, 3);
Entity.setNameTag(EvilNotch, "Evil Notch [BOSS]");
Player.addItemInventory(502, -1);
}else if(itemId == 500){
FireDemon = Level.spawnMob(x, y + 1, z, 35,"mob/FireDemon.png");
clientMessage(ChatColor.RED + "Fire Demon: FEELING A LITTLE HOT IN HERE");
Entity.setHealth(FireDemon, 440);
Entity.setCarriedItem(FireDemon,500,1,0);
Entity.setRenderType(FireDemon, DemonRenderer.renderType);
Entity.setNameTag(FireDemon, "Fire Demon [BOSS]");
Entity.setAnimalAge(FireDemon, 8);
Player.addItemInventory(500, -1);
}else if(itemId == 498){
SkeletonWarrior = Level.spawnMob(x, y + 1, z, 32,"mob/SkeletonWarrior.png");
clientMessage(ChatColor.WHITE + "Skeleton Warrior: RISE THE UNDEAD!!");
Entity.setHealth(SkeletonWarrior, 230);
Entity.setCarriedItem(SkeletonWarrior,267,1,0);
Entity.setRenderType(SkeletonWarrior, 12);
Entity.setNameTag(SkeletonWarrior, "Skeleton Warrior [MINI BOSS]");
Entity.setAnimalAge(SkeletonWarrior, 12);
Player.addItemInventory(498, -1);
}else if(itemId == 496){
DerpySquid = Level.spawnMob(x, y + 1, z, 32,"mob/Squid.png");
clientMessage(ChatColor.YELLOW + "Derpy Squid: DESTROY ALL BUTTER!!");
Entity.setHealth(DerpySquid, 650);
Entity.setCarriedItem(DerpySquid,276,1,0);
Entity.setRenderType(DerpySquid, 3);
Entity.setNameTag(DerpySquid, "Derpy Squid [BOSS]");
Entity.setAnimalAge(DerpySquid, 5);
Player.addItemInventory(496, -1);
}else if(itemId == 493){
Minotaur = Level.spawnMob(x, y + 1, z, 34,"mob/Minotaur.png");
clientMessage(ChatColor.BLACK + "Minotaur: I FOUND YOU!!!");
Entity.setHealth(Minotaur, 370);
Entity.setCarriedItem(Minotaur,286,1,0);
Entity.setRenderType(Minotaur, 3);
Entity.setNameTag(Minotaur, "Minotaur [BOSS]");
Player.addItemInventory(493, -1);
}else if(itemId == 492){
Zombie = Level.spawnMob(x, y + 1, z, 32,"mob/zombie.png");
Entity.setHealth(Zombie, 20);
Entity.setAnimalAge(Zombie, 4);
Player.addItemInventory(492, -1);
}else if(itemId == 491){
Skeleton = Level.spawnMob(x, y + 1, z, 34,"mob/skeleton.png");
Entity.setHealth(Skeleton, 16);
Player.addItemInventory(491, -1);
}else if(itemId == 490){
Spider = Level.spawnMob(x, y + 1, z, 35,"mob/spider.png");
Entity.setHealth(Spider, 16);
Player.addItemInventory(490, -1);
}else if(itemId == 489){
PigZombie = Level.spawnMob(x, y + 1, z, 36,"mob/pigzombie.png");
Entity.setHealth(PigZombie, 40);
Entity.setRenderType(PigZombie, 11);
Entity.setAnimalAge(PigZombie, 1);
Player.addItemInventory(489, -1);
}else if(itemId == 488){
Creeper = Level.spawnMob(x, y + 1, z, 33,"mob/creeper.png");
Entity.setHealth(Creeper, 16);
Player.addItemInventory(488, -1);
}else if(itemId == 487){
Steve = Level.spawnMob(x, y + 1, z, 11,"mob/steve.png");
clientMessage("Steve: Hey I'm Steve How Are You");
Entity.setHealth(Steve, 20);
Entity.setCarriedItem(Steve,270,1,0);
Entity.setRenderType(Steve, 3);
Entity.setAnimalAge(Steve, -24000);
Entity.setNameTag(Steve, "Steve");
Player.addItemInventory(487, -1);
}else if(itemId == 483){
SkeletonWarrior = Level.spawnMob(x, y + 1, z, 32,"mob/SkeletonWarrior.png");
Entity.setNameTag(SkeletonWarrior, "Jockey Boss [BOSS]");
Entity.setAnimalAge(SkeletonWarrior, 12);
Entity.setHealth(SkeletonWarrior, 230);
Entity.setRenderType(SkeletonWarrior, 12);
DemonicSpider = Level.spawnMob(x, y + 1, z, 35,"mob/obsidian.png");
Entity.setHealth(DemonicSpider, 250);
Entity.setCarriedItem(SkeletonWarrior,267,1,0);
clientMessage(ChatColor.WHITE + "Skeleton Warrior: Prepare to die NOOBZ");
clientMessage(ChatColor.BLUE + "Demonic Spider: YOU ARE GOING TO DIE, IDIOT");
Entity.setAnimalAge(DemonicSpider, 5);
rideAnimal(SkeletonWarrior, DemonicSpider);
Player.addItemInventory(483, -1);
}else if(itemId == 482){
Pumpkin = Level.spawnMob(x, y + 1, z, 34,"mob/Pumpkin.png");
clientMessage(ChatColor.RED + "Headless Horror: Give me your SOUL!");
Entity.setHealth(Pumpkin, 330);
Entity.setCarriedItem(Pumpkin,292,1,0);
Entity.setRenderType(Pumpkin, 3);
Entity.setNameTag(Pumpkin, "Headless Horror [BOSS]");
Cow = Level.spawnMob(x, y + 1, z, 35,"mob/DemonCow.png");
Entity.setHealth(Cow, 150);
Entity.setRenderType(Cow, 7);
rideAnimal(Pumpkin, Cow);
Player.addItemInventory(482, -1);
}else if(itemId == 477){
Grim = Level.spawnMob(x, y + 1, z, 34,"mob/Grim.png");
clientMessage(ChatColor.BLACK + "Grim Reaper: Gimme your SOULS");
Entity.setHealth(Grim, 270);
Entity.setCarriedItem(Grim,293,1,0);
Entity.setRenderType(Grim, 3);
Entity.setNameTag(Grim, "Grim Reaper [BOSS]");
Player.addItemInventory(480, -1);
}else if(itemId == 497){
lc = Level.spawnMob(x, y + 1, z, 33,"mob/lc.png");
clientMessage(ChatColor.RED + "Lava Creeper: Sssundenly It Got Warm In Here");
Entity.setHealth(lc, 340);
Entity.setNameTag(lc, "Lava Creeper [BOSS]");
Player.addItemInventory(497, -1);
}else if(itemId == 499){
wc = Level.spawnMob(x, y + 1, z, 33,"mob/wc.png");
clientMessage(ChatColor.BLUE + "Water Creeper: Sssundenly It Got Wet In Here");
Entity.setHealth(wc, 440);
Entity.setNameTag(wc, "Water Creeper [BOSS]");
Player.addItemInventory(499, -1);
}else if(itemId == 475){
iz = Level.spawnMob(x, y + 1, z, 32,"mob/iz.png");
Entity.setHealth(iz, 50);
Player.addItemInventory(475, -1);
}else if(itemId == 474){
my = Level.spawnMob(x, y + 1, z, 32,"mob/mummy.png");
Entity.setHealth(my, 80);
Player.addItemInventory(474, -1);
}else if(itemId==472 && blockId==20){
Glass = Level.spawnMob(x, y, z, 32,"mob/EnderSkeleton.png");
Entity.setHealth(Glass, 80);
Entity.setRenderType(Glass, 20);
Player.addItemInventory(472, -1);
setTile(x, y, z, 0);
}else if(itemId==472 && blockId==89){
Glow = Level.spawnMob(x, y + 1, z, 32,"mob/Herobrine.png");
Entity.setHealth(Glow, 100);
Entity.setRenderType(Glow, 89);
Player.addItemInventory(472, -1);
setTile(x, y, z, 0);
}else if(itemId == 451){
Exploding = Level.spawnMob(x, y + 1, z, 33,"mob/chicken.png");
Entity.setHealth(Exploding, 20);
Entity.setRenderType(Exploding, 6);
Player.addItemInventory(451, -1);
}else if(itemId == 449){
Troll = Level.spawnMob(x, y + 1, z, 35,"mob/Troll.png");
Entity.setHealth(Troll, 20);
Entity.setRenderType(Troll, 3);
Entity.setNameTag(Troll, "Troll");
Player.addItemInventory(449, -1);
}else if(itemId==441 && blockId==121){
Ender = Level.spawnMob(x, y + 1, z, 35,"mob/ender.png");
Entity.setHealth(Ender, 950);
Entity.setRenderType(Ender, 3);
Entity.setNameTag(Ender, "Ender Spirit [BOSS]");
Entity.setAnimalAge(Ender, 15);
Player.addItemInventory(441, -1);
setTile(x, y, z, 0);
Player.setHealth(8);
EnderLord = Level.spawnMob(x, y + 1, z, 34,"mob/EnderSkeleton.png");
Entity.setHealth(EnderLord, 350);
Entity.setRenderType(EnderLord, 3);
Entity.setNameTag(EnderLord, "EnderLord [Minion]");
}
var x = Player.getX();
var y = Player.getY();
var z = Player.getZ();
if(Entity.getRenderType(Player.getEntity()) == EndermanRenderType.renderType){
if(Entity.getEntityTypeId(Zombie)==32){
if(Player.getCarriedItem()==183){
Entity.remove(Zombie);
Zombie = Level.spawnMob(x, y, z, 11,"mob/zombie.png");
Entity.setHealth(Zombie, 30);
Entity.setRenderType(Zombie, 11);
Entity.setNameTag(Zombie, "Zombie");
}
}
}
}

function destroyBlock(x, y, z, side)
{
var r = Math.random();
if(Level.getTile(x, y, z) == 1) {
        if(r > 0.87) Level.dropItem(x + 0.5, y, z + 0.5, 0, 4, 1, Math.random() > 0.5 ? 0 : (Math.random() > 0.5 ? 1 : (Math.random() > 0.5 ? 2 : 3)));
        if(r < 0.23) Level.dropItem(x + 0.5, y, z + 0.5, 0, 4, 1, 0);
        if(r > 0.4 && r < 0.5) Level.dropItem(x + 0.5, y, z + 0.5, 0, 263, 1, 0);
        if(r > 0.5 && r < 0.6) Level.dropItem(x + 0.5, y, z + 0.5, 0, 15, 1, 0);
}
if(Level.getTile(x, y, z) == 18) {
        if(r > 0.87) Level.dropItem(x + 0.5, y, z + 0.5, 0, 260, 1, Math.random() > 0.5 ? 0 : (Math.random() > 0.5 ? 1 : (Math.random() > 0.5 ? 2 : 3)));
        if(r < 0.23) Level.dropItem(x + 0.5, y, z + 0.5, 0, 481, 1, 0);
        if(r > 0.4 && r < 0.5) Level.dropItem(x + 0.5, y, z + 0.5, 0, 6, 1, 0);
}
}

function attackHook(attacker, victim)
{
if(Entity.getEntityTypeId(FireDemon)==35){
Entity.setFireTicks(Player.getEntity(), 5);
}
var x = Entity.getX(EnderLord);
var y = Entity.getY(EnderLord);
var z = Entity.getZ(EnderLord);
if(Entity.getEntityTypeId(EnderLord)==35){
var random = Math.floor(Math.random(1));
if (random == 1) {
Entity.setPosition(EnderLord, Player.getX(), Player.getY() -1.5, Player.getZ() -3);
}
var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(Entity.getRenderType(Player.getEntity()) == EndermanRenderType.renderType){
if(Entity.getEntityTypeId(victim)==32){
Entity.remove(victim);
Zombie = Level.spawnMob(x, y, z, 11,"mob/zombie.png");
Entity.setHealth(Zombie, 30);
Entity.setRenderType(Zombie, 11);
Entity.setNameTag(Zombie, "Zombie");
}
if(Entity.getEntityTypeId(Zombie)==11){
Level.playSoundEnt(Zombie, "mob.zombiehurt", 100, 100);
}
}
}
}

function modTick()
{
if(Player.getCarriedItem()==183){
Player.setHealth(20);
}
if(Player.getCarriedItem()==411){
Entity.setMobSkin(getPlayerEnt(), "mob/char.png");
}
if(Player.getCarriedItem()==410){
Entity.setMobSkin(getPlayerEnt(), "mob/char.png");
}
if(Player.getCarriedItem()==409){
Entity.setMobSkin(getPlayerEnt(), "mob/char.png");
}
if(Player.getCarriedItem()==408){
Entity.setMobSkin(getPlayerEnt(), "mob/char.png");
}
if(Entity.getEntityTypeId(FireDemon)==35){
setTile(Entity.getX(FireDemon), Entity.getY(FireDemon)-2, Entity.getZ() -1, 87);
setTile(Entity.getX(FireDemon), Entity.getY(FireDemon)-1, Entity.getZ() -1, 51);
Level.playSoundEnt(FireDemon, "fire.fire", 50, 100);
Entity.setFireTicks(FireDemon, -1);
}
if(getCarriedItem()==183 && gui==true){
ctx.runOnUiThread(new java.lang.Runnable(){
  
run: function(){
  
try{

GUI = new android.widget.PopupWindow();
var layout = new android.widget.LinearLayout(ctx);
layout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
GUI.setContentView(layout);
var btn = new android.widget.Button(ctx);
var button = new android.widget.Button(ctx);
layout.addView(btn);
button.setText("Shoot");
GUI.setWidth(100);
GUI.setHeight(70);
GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.GRAY));
btn.setOnClickListener(new android.view.View.OnClickListener({ 
onClick: function(viewarg){ 
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,81);
setVelX(arrow,2.5*xx);
setVelY(arrow,2.5*zz);
setVelZ(arrow,2.5*yy);
Level.playSoundEnt(arrow, "random.bow", 100, 100);
rideAnimal(Player.getEntity(), arrow);
}
}));
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.RIGHT, 0, 150);
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.LEFT, 0, 100);
} catch (e){
print ("Error: "+e)
}
}});
gui=false;
}
if(getCarriedItem()!=183&&gui==false){
ctx.runOnUiThread(new java.lang.Runnable({ 
run: function(){ 
if(GUI != null){ 
GUI.dismiss();
GUI = null;
}
}})); 
gui=true;
}
}

function leaveGame(){
ctx.runOnUiThread(new java.lang.Runnable({ 
run: function(){ 
if(GUI != null){ 
GUI.dismiss();
GUI = null;
} 
}})); 
}

function newLevel(hasLevel)
{
var x = Player.getX();
var y = Player.getY();
var z = Player.getZ();
clientMessage("§2Bosscraft §1v1.2.8");
clientMessage("This is only a Pre-Release");
clientMessage("So A little buggy");
clientMessage("§4Mod §3Made §6By §5EnderLord397");
instructor = Level.spawnMob(x, y + 1, z -1, 11,"mob/steve.png");
Entity.setHealth(instructor, 20);
Entity.setNameTag(instructor, "Instructor Guide");
Entity.setRenderType(instructor, 3);
}

function procCmd(command)
{
var cmd = command.split(" ");
{
if(cmd[0] == "bosses")
{
addItemInventory(509,1);
addItemInventory(510,1);
addItemInventory(511,1);
addItemInventory(500,1);
addItemInventory(502,1);
addItemInventory(498,1);
addItemInventory(496,1);
addItemInventory(493,1);
addItemInventory(483,1);
addItemInventory(482,1);
addItemInventory(499,1);
addItemInventory(497,1);
addItemInventory(477,1);
addItemInventory(467,1);
addItemInventory(417,1);
addItemInventory(418,1);
addItemInventory(456,1);
addItemInventory(436,1);
addItemInventory(160,1);
addItemInventory(431,1);
addItemInventory(441,1);
addItemInventory(121,1);
clientMessage("§4You Have Been Given All Of The Summoners From Bosscraft");
}
if(cmd[0] == "items")
{
addItemInventory(503,1);
addItemInventory(504,1);
addItemInventory(505,1);
addItemInventory(506,1);
addItemInventory(427,1);
addItemInventory(507,1);
addItemInventory(508,1);
addItemInventory(426,1);
addItemInventory(276,1);
addItemInventory(478,1);
addItemInventory(482,1);
addItemInventory(499,1);
addItemInventory(497,1);
addItemInventory(495,64);
addItemInventory(494,64);
addItemInventory(481,64);
addItemInventory(479,64);
addItemInventory(473,64);
addItemInventory(472,64);
addItemInventory(471,64);
addItemInventory(470,64);
addItemInventory(501,64);
addItemInventory(485,64);
addItemInventory(484,64);
clientMessage("§4You Have Been Given All The Items From Bosscraft");
}
if(cmd[0] == "spawneggs")
{
addItemInventory(492,1);
addItemInventory(491,1);
addItemInventory(490,1);
addItemInventory(489,1);
addItemInventory(488,1);
addItemInventory(487,1);
addItemInventory(480,1);
addItemInventory(449,1);
addItemInventory(451,1);
addItemInventory(475,1);
addItemInventory(474,1);
addItemInventory(447,1);
addItemInventory(402,1);
addItemInventory(401,1);
clientMessage("§4You Have Been Given All Of The Spawn Eggs From Bosscraft");
}
if(cmd[0] == "weapons")
{
addItemInventory(466,1);
addItemInventory(465,1);
addItemInventory(464,1);
addItemInventory(463,1);
addItemInventory(462,1);
addItemInventory(461,1);
addItemInventory(453,1);
addItemInventory(452,1);
addItemInventory(437,1);
addItemInventory(435,1);
addItemInventory(428,1);
addItemInventory(429,1);
addItemInventory(419,1);
addItemInventory(415,1);
addItemInventory(414,1);
addItemInventory(413,1);
clientMessage("§4You Have Been Given All Of The Weapons From Bosscraft");
}
}
}

function deathHook(attacker,victim)
{
if(Entity.getEntityTypeId(Ender)==35)
{
Level.dropItem (Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 440, 85, 0);
}
if(Entity.getEntityTypeId(EnderLord)==35)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 183, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 264, 7, 0);
}
if(Entity.getEntityTypeId(Zombie)==11)
{
Level.playSoundEnt(Zombie, "mob.zombiedeath", 100, 100);}
}