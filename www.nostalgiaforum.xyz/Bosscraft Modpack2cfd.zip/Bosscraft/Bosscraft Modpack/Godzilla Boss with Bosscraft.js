ModPE.setItem(184,"name_tag",0,"Legendary Viper Summoner");
ModPE.setItem(455,"emerald",0,"Godzilla Scale");
ModPE.setItem(454,"bone",0,"Godzilla Bone");
ModPE.setFoodItem(448,"beef_raw",13,5,"Raw Godzilla Meat");
ModPE.setFoodItem(433,"beef_cooked",12,15,"Cook Godzilla Meat");
ModPE.setItem(447,"record_11",0,"Spawn Godzilla");
ModPE.setItem(432,"blaze_rod",0,"Super Staff");
ModPE.setItem(181,"cauldron",0,"Spawn Kiryu");
ModPE.setItem(188,"spawn_egg",1,"Spawn Young Viper");
ModPE.setItem(329,"saddle",0,"Viper Saddle");
ModPE.setItem(193,"sword",3,"Overpower Blade");
ModPE.setItem(194,"spawn_egg",0,"Spawn Deadly Gamer");
var dir = "/storage/sdcard0/Bosscraft/Bosscraft Modpack/";
var Gamer = 0;
var gamer = 0;
var mecha = 0;
var Godzilla = 0
var zombie = 0;
var looptimer = false;
var ride = false;
var riding = false;
var rideAnimal;
var loopcount = 0;
var count=-1;
var countdown=-1;
var alea;
var ball=-1;
var recurrent=19;
var recurrent2=80;
var earth = 0;
var height=4;
var fire=-1;
var Godzilla;
var Young = 0;
var rhino = 0;
var young = 0;
var x = Player.getX(Player.getEntity());
var y = Player.getY(Player.getEntity());
var z = Player.getZ(Player.getEntity());

function addGodzillaRenderType(renderer)
 {
	var var2 = 0;
	
	var model = renderer.getModel();
	
     var bipedBody = model.getPart("body").clear().setTextureOffset(0, 12);
	
	bipedBody.addBox(-12, -400.0, -30.0, 100, 350, 100, var2);
	
	bipedBody.addBox(-12, -400.0, -30.0, 100, 350, 100, var2);

     bipedBody.addBox(-12, -350, -55, 100, 50, 50, 0);

     bipedBody.addBox(-14, -400, -30, 10, 10, 50);

     bipedBody.addBox(-10, -400, -30, 10, 10, 50);

     bipedBody.addBox(4, -100, -40, 50, 50, 450.50, var2);

     bipedBody.addBox(4, -150, -10, 12.9, 130, 55.5);

     bipedBody.addBox(4, -100, -40, 70, 70, 40);

     bipedBody.addBox(80.0, -250.0, -100.0, 70, 50, 150, 0);

     bipedBody.addBox(-70.0, -250.0, -100.0, 70, 50, 150, 0);

     bipedBody.addBox(80, -240, -130, 50, 20, 100);

     bipedBody.addBox(80, -250, -130, 50, 20, 100);

     bipedBody.addBox(-70, -240, -130, 50, 20, 100);

     bipedBody.addBox(-70, -250, -130, 50, 20, 100);

     bipedBody.addBox(20, -310, -10, 12.9, 40, 130);

     bipedBody.addBox(20, -340, -10, 12.9, 40, 180);

     bipedBody.addBox(20, -240, -10, 12.9, 40, 130);

     bipedBody.addBox(20, -270, -10, 12.9, 40, 200);

     bipedBody.addBox(20, -170, -10, 12.9, 55.5, 130);

     bipedBody.addBox(20, -200, -10, 12.9, 40, 180);
	
	
	var bipedHead =
model.getPart("head").clear().setTextureOffset(0, 0);

	 bipedBody.addBox(-30.0, -300.0, -30.0, 80, 210, 100, var2);
	 
	 bipedBody.addBox(20.0, -300.0, -30.0, 80, 210, 110, var2);
	 
	 
	 var bipedRightArm = model.getPart("rightArm").clear().setTextureOffset(0, 12);
	
	bipedRightArm.addBox(0.0, -0.0, -0.0, 0, 0, 0, 0);
	
 var bipedLeftArm = model.getPart("leftArm").clear().setTextureOffset(0, 12);
 
	bipedLeftArm.addBox(-0.0, -0.0, -0.0, 0, 0, 0, 0);
	
	var bipedRightLeg = model.getPart("rightLeg").clear().setTextureOffset(0, 12);
	
	bipedRightLeg.addBox(70, -130.0, -15.0, 50.5, 150, 50, var2);

     bipedRightLeg.addBox(70, -12, -45, 50, 25, 85, 0);
	
	var bipedLeftLeg = model.getPart("leftLeg").clear().setTextureOffset(0, 12);
	
	bipedLeftLeg.addBox(-40, -130.0, -15.0, 50.5, 150, 50, var2);

     bipedLeftLeg.addBox(-40, -12, -45, 50, 25, 85, 0);
	
}

var godzillaRenderer= Renderer.createHumanoidRenderer();
addGodzillaRenderType(godzillaRenderer);

function addRhinoToRenderer(renderer)
{
model = renderer.getModel();
var head = model.getPart("head").clear();
head.addBox(-10, -65, -10, 50, 50, 50);
head.addBox(-10, -60, 7, 25, 15, 40);
var body = model.getPart("body").clear();
body.addBox(-10, -70, -50, 70, 70, 85);
var rarm = model.getPart("rightArm").clear();
rarm.addBox(-10, -20, -10, 20, 20, 20);
var larm = model.getPart("leftArm").clear();
larm.addBox(0, -20, -3, 20, 20, 20);
rleg = model.getPart("rightLeg").clear();
rleg.addBox(-10, -20, -6, 20, 20, 20);
lleg = model.getPart("leftLeg").clear();
lleg.addBox(0, -20, -6, 20, 20, 20);
}

var RhinoRenderer= Renderer.createHumanoidRenderer();
addRhinoToRenderer(RhinoRenderer);

function addSkullToRenderer(renderer)
{
var model = renderer.getModel();
var bipedHead =
model.getPart("head").clear().setTextureOffset(0, 0);

	 bipedHead.addBox(-30.0, -300.0, -30.0, 80, 210, 100, 0);
	 
	 bipedHead.addBox(20.0, -300.0, -30.0, 80, 210, 110, 0);
var body = model.getPart("body").clear();
body.addBox(0, 0, 0, 0, 0, 0);
var rarm = model.getPart("rightArm").clear();
var larm = model.getPart("leftArm").clear();
var rleg = model.getPart("rightLeg").clear();
var lleg = model.getPart("leftLeg").clear();
rarm.addBox(0, 0, 0, 0, 0, 0);
larm.addBox(0, 0, 0, 0, 0, 0);
rleg.addBox(0, 0, 0, 0, 0, 0);
lleg.addBox(0, 0, 0, 0, 0, 0);
}

var SkullRenderer = Renderer.createHumanoidRenderer();
addSkullToRenderer(SkullRenderer);

function addEarthWormToRenderer(renderer)
{
var model2 = renderer.getModel();
var head = model2.getPart("head").clear();
head.setTextureOffset(0, 12);
head.addBox(-150, -200, -200, 150, 150, 150);
head.addBox(-150, -250, -220, 50, 100, 200);
head.addBox(-50, -250, -220, 50, 100, 200);
var body = model2.getPart("body").clear();
body.addBox(-150, -100, -150, 150, 120, 750);
body.addBox(-100, -150, -150, 50, 150, 130);
body.addBox(-100, -150, 30, 50, 150, 130);
body.addBox(-100, -150, 180, 50, 150, 130);
body.addBox(-100, -150, 300, 50, 150, 130);
var rarm = model2.getPart("rightArm").clear();
rarm.addBox(0, 0, 0, 0, 0, 0);
var larm = model2.getPart("leftArm").clear();
larm.addBox(0, 0, 0, 0, 0, 0);
var lleg = model2.getPart("leftLeg").clear();
lleg.addBox(0, 0, 0, 0, 0, 0);
var rleg = model2.getPart("rightLeg").clear();
rleg.addBox(0, 0, 0, 0, 0, 0);
}

var EarthWormRenderType= Renderer.createHumanoidRenderer();
addEarthWormToRenderer(EarthWormRenderType);

function addViperToRenderer(renderer)
{
var model2 = renderer.getModel();
var head = model2.getPart("head").clear();
head.addBox(-15, -2, -20, 15, 15, 15);
head.addBox(-15, -7, -22, 5, 10, 20);
head.addBox(-5, -7, -22, 5, 10, 20);
var body = model2.getPart("body").clear();
body.addBox(-15, 8, -15, 15, 12, 75);
body.addBox(-10, 3, -15, 5, 15, 13);
body.addBox(-10, 3, 3, 5, 15, 13);
body.addBox(-10, 3, 18, 5, 15, 13);
body.addBox(-10, 3, 30, 5, 15, 13);
var rarm = model2.getPart("rightArm").clear();
rarm.addBox(0, 0, 0, 0, 0, 0);
var larm = model2.getPart("leftArm").clear();
larm.addBox(0, 0, 0, 0, 0, 0);
var lleg = model2.getPart("leftLeg").clear();
lleg.addBox(0, 0, 0, 0, 0, 0);
var rleg = model2.getPart("rightLeg").clear();
rleg.addBox(0, 0, 0, 0, 0, 0);
}

var ViperRenderType= Renderer.createHumanoidRenderer();
addViperToRenderer(ViperRenderType);

function addGamerToRenderer(renderer)
{
var model = renderer.getModel();
var head = model.getPart("head").clear();
head.addBox(-2, -50, 0, 20, 20, 20);
var body = model.getPart("body").clear();
body.addBox(0, -35, 0, 15, 35, 15);
var rarm = model.getPart("rightArm").clear();
rarm.addBox(-10, -30, 0, 15, 35, 15);
rarm.addBox(-8, -5, -45, 10, 10, 55);
rarm.addBox(-8, -5, -3, 10, 15, 10);
rarm.addBox(-8, -5, -50, 10, 15, 55);
rarm.addBox(-8, -5, 2, 10, 10, 20);
var larm = model.getPart("leftArm").clear();
larm.addBox(10, -30, 0, 15, 35, 15);
var rleg = model.getPart("rightLeg").clear();
rleg.addBox(-4, -20, 1, 15, 35, 15);
var lleg = model.getPart("leftLeg").clear();
lleg.addBox(1, -20, 1, 15, 35, 15);
}

var GamerRender = Renderer.createHumanoidRenderer();
addGamerToRenderer(GamerRender);

function addBallToRenderer(renderer)
{
var model2 = renderer.getModel();
model2.getPart("body").clear();
model2.getPart("rightArm").clear()
model2.getPart("leftArm").clear()
model2.getPart("leftLeg").clear()
model2.getPart("rightLeg").clear()
}

var ballRenderer= Renderer.createHumanoidRenderer();
addBallToRenderer(ballRenderer);


function useItem(x, y, z, itemId, blockId, side)
{
if(itemId==395 && blockId==75){
Entity.setMobSkin(Player.getEntity(), "godzilla.png");
Entity.setRenderType(Player.getEntity(), godzillaRenderer.renderType);
setTile(x, y, z, 0);
Player.setHealth(Entity.getHealth(Player.getEntity()) +100);
}
if(Entity.getRenderType(Player.getEntity()) == godzillaRenderer.renderType){
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
Level.spawnMob(x, y + 75, z, 65,"mob/wither.png");
}
if(itemId==395 && Level.getTile(x, y, z) == 42 && Level.getTile(x, y + 1, z) == 42){
Entity.setRenderType(Player.getEntity(), godzillaRenderer.renderType);
Entity.setMobSkin(Player.getEntity(), "mecha_godzilla.png");
setTile(x, y, z, 0);
setTile(x, y + 1, z, 0);
Player.setHealth(Entity.getHealth(Player.getEntity())+1000);
}
if(itemId==456 && blockId==75){
for(var i = 0; i <= 64; i++);
Godzilla = Level.spawnMob(x, y + 3, z, 35,"image/mob/godzilla.png");
clientMessage("§1The Beast of the World is awake");
clientMessage("Godzilla: §4ROOOOOAAAAARRRR");
Entity.setHealth(Godzilla, 10000);
Entity.setRenderType(Godzilla, godzillaRenderer.renderType);
Entity.setAnimalAge(Godzilla, 30);
Player.addItemInventory(456, -1);
Player.setHealth(10)
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt" , 100, 100);
clientMessage("§4YOU SHOULDN'T REALLY SPAWN HIM IN");
setTile(x, y, z, 0);
Entity.setFireTicks(Godzilla, -13);
}
if(itemId == 447){
for(var i = 0; i <= 64; i++);
Godzilla = Level.spawnMob(x, y + 1, z, 35,"mob/godzilla.png");
clientMessage("§1The Beast of the World is Awake");
clientMessage("Godzilla: §4ROAAAAAAAR");
clientMessage("§1You shouldn't really spawn him in");
Entity.setHealth(Godzilla, 10000);
Entity.setRenderType(Godzilla, godzillaRenderer.renderType);
Entity.setAnimalAge(Godzilla, 50);
Entity.setRot(Godzilla, 100, 1000);
Player.addItemInventory(447, -1);
Entity.setFireTicks(Godzilla, -1E3);
}
if(itemId==184){
earth = Level.spawnMob(x, y + 2, z, 35,"mob/earth.png");
Entity.setRenderType(earth, EarthWormRenderType.renderType);
Entity.setHealth(earth, 20000);
Entity.setAnimalAge(earth, 100);
}
if(itemId == 181){
for(var i = 0; i <= 64; i++);
mecha = Level.spawnMob(x, y + 1, z, 35,"mob/mecha_godzilla.png");
clientMessage("Kiryu: §4ROAAAAAAAR");
Entity.setHealth(mecha, 7500);
Entity.setRenderType(mecha, godzillaRenderer.renderType);
Entity.setAnimalAge(mecha, 50);
Entity.setRot(mecha, 100, 1000);
Player.addItemInventory(181, -1);
Entity.setFireTicks(mecha, -1E3);
}
if(itemId==188){
rhino = Level.spawnMob(x, y + 2, z, 35,"mob/earth.png");
Entity.setHealth(rhino, 500);
Entity.setRenderType(rhino, ViperRenderType.renderType);
}
if(Entity.getEntityTypeId(young)==11 && getCarriedItem()==264){
Entity.setPosition(young, x, y + 1, z);
}
if(itemId==194){
Gamer = Level.spawnMob(x, y + 2, z, 35,"mob/char.png");
Entity.setRenderType(Gamer, GamerRender.renderType);
Entity.setHealth(Gamer, 100);
Entity.setAnimalAge(Gamer, 10);
}
}

function compareMobs(mob1, mob2){
    if(mob1 == null || mob2 == null) return false;
    
    if(Entity.getX(mob1) == Entity.getX(mob2) &&
        Entity.getY(mob1) == Entity.getY(mob2) &&
        Entity.getZ(mob1) == Entity.getZ(mob2) &&
        Entity.getEntityTypeId(mob1) == Entity.getEntityTypeId(mob2))
        return true;
        
    return false;
}

function attackHook(attacker, entity){
if(Player.getCarriedItem()==193){
Entity.setHealth(entity, 0);
}
var x = Entity.getX(Gamer);
var y = Entity.getY(Gamer);
var z = Entity.getZ(Gamer);
if(Entity.getEntityTypeId(Gamer)==11){
Entity.remove(Gamer);
gamer = Level.spawnMob(x, y, z, 35,"mob/char.png");
Entity.setHealth(gamer, 100);
Entity.setRenderType(gamer, GamerRender.renderType);
Entity.setAnimalAge(gamer, 10);
}
    if(getCarriedItem()==329 && Entity.getEntityTypeId(young)==11){
rideAnimal(Player.getEntity(), young);
ModPE.showTipMessage("Tap Jump To Get Out Of Your Viper");
}
var x = Entity.getX(Godzilla);
var y = Entity.getY(Godzilla);
var z = Entity.getZ(Godzilla);
var random = Math.floor((Math.random())*(5));
if(Entity.getEntityTypeId(Godzilla)==35){
if (random == 3) {
tnt = Level.spawnMob(x, y + 36, z, 65);
setVelZ(tnt, 0.3);
Level.playSound(dir + "sound/Godzilla/godzilla_roar.wav", 5);
}
if ( random == 2) {
Entity.setVelZ(Player.getEntity(), 6);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 10);
}
if (random == 4) {
Entity.setVelZ(Player.getEntity(), 6);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 100);
}
var x = Player.getX();
var y = Entity.getY();
var z = Player.getZ();
if (random == 1) {
setTile(x, y + 7, z, 12);
setTile(x -1, y + 7, z, 12);
setTile(x +1, y + 7, z, 12);
setTile(x, y + 7, z -1, 12);
setTile(x, y + 7, z +1, 12);
setTile(x -1, y + 7, z + 1, 12);
setTile(x -1, y + 7, z -1, 12);
setTile(x +1, y + 7, z +1, 12);
setTile(x +1, y + 7, z -1, 12);
setTile(x, y + 8, z, 13);
setTile(x -1, y + 8, z, 13);
setTile(x +1, y + 8, z, 13);
setTile(x, y + 8, z -1, 13);
setTile(x, y + 8, z +1, 13);
setTile(x -1, y + 8, z + 1, 13);
setTile(x -1, y + 8, z -1, 13);
setTile(x +1, y + 8, z +1, 13);
setTile(x +1, y + 8, z -1, 13);
}
if(Entity.getEntityTypeId(young)==11){
Level.playSoundEnt(young, "mob.spiderhurt", 100, 100);
}
if(Entity.getEntityTypeId(mecha)==11){
Level.playSoundEnt(mecha, "random.break", 1000, 500);
}
if(Entity.getEntityTypeId(Young)==35 && getCarriedItem()==363){
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.eat", 100, 100);
Player.addItemInventory(363, -1);
Entity.remove(Young);
h = Level.spawnMob(Entity.getX(Young), Entity.getY(Young), Entity.getZ(Young), 11,"mob/earth.png");
Entity.setHealth(h, 1000);
Entity.setRenderType(h, ViperRenderType.renderType);
Entity.setNameTag(h, "Tamed Young Viper");
}
if(Entity.getEntityTypeId(rhino)==35 && getCarriedItem()==363){
Player.addItemInventory(363, -1);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.eat", 100, 100);
Entity.remove(rhino);
young = Level.spawnMob(Entity.getX(rhino), Entity.getY(rhino), Entity.getZ(rhino), 11,"mob/earth.png");
Entity.setHealth(young, 1000);
Entity.setRenderType(young, ViperRenderType.renderType);
Entity.setNameTag(young, "Tamed Young Viper");
}
if(Entity.getEntityTypeId(young)==11 && getCarriedItem()==363){
Entity.setHealth(young, 1000);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.eat", 500, 400);
}
}
}

function modTick()
{
var x = Entity.getX(Godzilla);
var y = Entity.getY(Godzilla);
var z = Entity.getZ(Godzilla);
if(Entity.getEntityTypeId(Godzilla)==35 && getTile(x, y -1, z)==2){
setTile(x, y -1, z, 3);
setTile(x -1, y -1, z, 3);
setTile(x +1, y -1, z, 3);
setTile(x, y -1, z -1, 3);
setTile(x, y -1, z +1, 3);
setTile(x -1, y -1, z + 1, 3);
setTile(x -1, y -1, z -1, 3);
setTile(x +1, y -1, z +1, 3);
setTile(x +1, y -1, z -1, 3);
setTile(x, y -1, z, 3);
setTile(x -7, y -1, z, 3);
setTile(x +7, y -1, z, 3);
setTile(x, y -1, z -7, 3);
setTile(x, y -1, z +7, 3);
setTile(x -7, y -1, z + 7, 3);
setTile(x -7, y -1, z -7, 3);
setTile(x +7, y -1, z +7, 3);
setTile(x +7, y -1, z -7, 3);
}
if(Entity.getEntityTypeId(young)==11 && Entity.getX(zombie)){
Entity.setHealth(zombie, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "mob.zombiedeath", 100, 100);
}
var x = Entity.getX(earth);
var y = Entity.getY(earth);
var z = Entity.getZ(earth);
if(Entity.getEntityTypeId(earth)==35 && getTile(x, y -2, z)==2){
setTile(x, y -2, z, 0);
setTile(x -1, y -2, z, 0);
setTile(x +1, y -2, z, 0);
setTile(x, y -2, z -1, 0);
setTile(x, y -2, z +1, 0);
setTile(x -1, y -2, z +1, 0);
setTile(x -1, y -2, z -1, 0);
setTile(x +1, y -2, z +1, 0);
setTile(x +1, y -2, z -1, 0);
setTile(x, y -2, z, 0);
setTile(x -1, y -2, z, 0);
setTile(x +1, y -2, z, 0);
setTile(x, y -2, z -1, 0);
setTile(x, y -2, z +1, 0);
setTile(x -1, y -2, z +1, 0);
setTile(x -1, y -2, z -2, 0);
setTile(x +1, y -2, z +1, 0);
setTile(x +1, y -2, z -2, 0);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "step.grass", 100, 100);
Entity.setHealth(Entity.getHealth(earth)+50);
}
}

function deathHook(attacker,victim)
{
if(victim==Godzilla)
{
Level.dropItem (Entity.getX(Godzilla), Entity.getY(Godzilla), Entity.getZ(Godzilla), 6, 454, 125, 0);
Level.dropItem (Entity.getX(Godzilla), Entity.getY(Godzilla), Entity.getZ(Godzilla), 6, 455, 125, 0);
Level.dropItem (Entity.getX(Godzilla), Entity.getY(Godzilla), Entity.getZ(Godzilla), 6, 448, 125, 0);
Level.dropItem (Entity.getX(Godzilla), Entity.getY(Godzilla), Entity.getZ(Godzilla), 6, 454, 125, 0);
Level.dropItem (Entity.getX(Godzilla), Entity.getY(Godzilla), Entity.getZ(Godzilla), 6, 455, 125, 0);
Level.dropItem (Entity.getX(Godzilla), Entity.getY(Godzilla), Entity.getZ(Godzilla), 6, 448, 125, 0);
Level.explode(x, y, z, 8);
ModPE.showTipMessage("§1[BC] §4You Have Slain Godzilla");
}
var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(Entity.getEntityTypeId(earth)==35)
{
Level.dropItem(x, y, z, 1, 363, 210, 0);
Level.dropItem(x, y, z, 1, 454, 210, 0);
Level.dropItem(x, y, z, 1, 264, 210, 0);
Level.dropItem(x, y, z, 1, 472, 210, 0);
Level.dropItem(x, y, z, 1, 187, 1, 0);
Young = Level.spawnMob(x, y, z, 35,"mob/earth.png");
Entity.setHealth(Young, 500);
Entity.setRenderType(Young, ViperRenderType.renderType);
}
if(Entity.getEntityTypeId(Gamer)==35){
Level.explode(x, y, z, 2);
clientMessage("Deadly Gamer: Avenge Me!");
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 3, 419, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 3, 264, 36, 0);}
}