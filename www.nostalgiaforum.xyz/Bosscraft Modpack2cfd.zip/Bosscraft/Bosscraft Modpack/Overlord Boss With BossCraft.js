ModPE.setItem(467,"magma_cream",0,"The Overlord Summoner");
var Overlord = 0

function useItem(x, y, z, itemId, blockId, side)
{
if(itemId==467 && blockId==49){
Overlord = Level.spawnMob(x, y + 1, z, 35,"mob/Overlord.png");
clientMessage("§4Overlord: How Dare You Disturb Me");
clientMessage("§4Overlord: You Will Pay For All Of This");
clientMessage("§4Overlord: MUHAHAHAHA YOU CAN'T DEFEAT ME");
Entity.setHealth(Overlord, 1350);
Entity.setRenderType(Overlord, 3);
Entity.setAnimalAge(Overlord, 18);
Entity.setNameTag(Overlord, "Overlord [BOSS]");
Player.addItemInventory(467, -1);
setTile(x, y, z, 246);
}
}

function deathHook(attacker,victim)
{
if(Overlord > 0)//OverlordDrops
{
if(Entity.getEntityTypeId(Overlord)==35)
{
preventDefault();
Overlord --;
ModPE.saveData (Level.getWorldDir() + "Overlord", Overlord);
Level.dropItem (Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 57, 15, 0);
Level.dropItem (Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 466, 1, 0);
Level.dropItem (Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 75, 1, 0);}
}
}
