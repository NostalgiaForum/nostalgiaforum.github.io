ModPE.setItem(395,"spawn_egg",1,"Morph Egg");
Item.setMaxDamage(395, 200);
var strength = false;
var FieryFistUses = 5000;

function addGolemToRenderer(renderer)
 {
	var var2 = 0;
	
	var model = renderer.getModel();
	
	var bipedBody = model.getPart("body").clear().setTextureOffset(100, 0);
	
	bipedBody.addBox(-6.0, -16.0, -2.0, 20, 15, 10, var2);
	
	 bipedBody.addBox(-2.0, -1.0, -2.0, 12, 5, 10, var2);
	
	
	var bipedHead =
model.getPart("head").clear().setTextureOffset(60, 0);

	 bipedBody.addBox(-1.0, -27.0, -3.0, 10, 12, 10, var2);
	 
	 bipedBody.addBox(2.6, -18.8, -4.5, 3, 5.5, 3, var2);
	 
	 
	 var bipedRightArm = model.getPart("rightArm").clear().setTextureOffset(65, 0);
	
	bipedRightArm.addBox(-7.0, -16.0, -1.0, 6, 37, 8, var2);
	
 var bipedLeftArm = model.getPart("leftArm").clear().setTextureOffset(65, 0);
 
	bipedLeftArm.addBox(9.0, -16.0, -1.0, 6, 37, 8, var2);
	
	var bipedRightLeg = model.getPart("rightLeg").clear().setTextureOffset(1000000, 0);
	
	bipedRightLeg.addBox(8.0, -8.0, -1.0, 7.5, 20, 9, var2);
	
	var bipedLeftLeg = model.getPart("leftLeg").clear().setTextureOffset(1000000, 0);
	
	bipedLeftLeg.addBox(-6, -8.0, -1.0, 7.5, 20, 9, var2);
	
}

var golemRenderer = Renderer.createHumanoidRenderer();

addGolemToRenderer(golemRenderer);

function useItem(x, y, z, itemId, blockId, side, itemDamage, blockDamage)
{
if(itemId==395 && blockId==57){
Entity.setRenderType(Player.getEntity(), golemRenderer.renderType);
Entity.setMobSkin(Player.getEntity(), "diamond.png");
Player.setHealth(Entity.getHealth(Player.getEntity())+40);
setTile(x, y, z, 0);
}
if(itemId==395 && blockId==46){
Entity.setRenderType(Player.getEntity(), 14);
Entity.setMobSkin(Player.getEntity(), "mob/creeper.png");
setTile(x, y, z, 0);
}
if(itemId==395 && blockId==49){
Entity.setRenderType(Player.getEntity(), golemRenderer.renderType);
Entity.setMobSkin(Player.getEntity(), "Golem.png");
Player.setHealth(Entity.getHealth(Player.getEntity())+50);
Entity.setAnimalAge(Player.getEntity(), 25);
setTile(x, y, z, 0);
}
if(itemId==395 && getTile(x, y, z)==87){
Entity.setRenderType(Player.getEntity(), golemRenderer.renderType);
Entity.setMobSkin(Player.getEntity(), "Nether.png");
Player.setHealth(Entity.getHealth(Player.getEntity())+30);
setTile(x, y, z, 0);
}
if(itemId==395 && blockId==1){
Entity.setRenderType(Player.getEntity(), 12);
Entity.setMobSkin(Player.getEntity(), "SkeletonWarrior.png");
setTile(x, y, z, 0);
}
if(itemId==395 && blockId==35){
Entity.setMobSkin(Player.getEntity(), "sheep_0.png");
Entity.setRenderType(Player.getEntity(), 9);
}
if(itemId==395 && blockId==4){
Entity.setRenderType(Player.getEntity(), golemRenderer.renderType);
Entity.setMobSkin(Player.getEntity(), "cobble.png");
setTile(x, y, z, 0);
Player.setHealth(Entity.getHealth(Player.getEntity())+20);
}
if(Level.getTime() == 0){
if(Entity.getRenderType(Player.getEntity()) == 11){
Entity.setFireTicks(Player.getEntity(), 100000);
}
if(itemId==397 && blockId==2){
Entity.setRenderType(Player.getEntity(), 3);
Entity.setMobSkin(Player.getEntity(), "char.png");
}
if(itemId==503 && blockId==46){
if(Entity.getRenderType(Player.getEntity()) == 14){
Level.explode(x, y, z, 35);
}
if(Entity.getRenderType(Player.getEntity()) == golemRenderer.renderType){
Entity.setHealth(Entity.getHealth(Entity.getEntity)-10);
}
}
}
}

function attackHook(victim, attacker)
{
var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(Entity.getRenderType(Player.getEntity()) == golemRenderer.renderType)
{
Entity.setHealth(-1);
}
}

function destroyBlock(x, y, z, side) {
if(Entity.getRenderType(Player.getEntity()) == golemRenderer.renderType){
if(getTile(x, y, z) == 2){
setTile(x, y -1, z, 0);
setTile(x, y -2, z, 0);
setTile(x, y -3, z, 0);
setTile(x, y -4, z, 0);
}
if(Entity.getRenderType(Player.getEntity()) == golemRenderer.renderType){
if(getTile(x, y, z) == 1){
setTile(x, y -1, z, 0);
setTile(x, y -2, z, 0);
setTile(x, y -3, z, 0);
setTile(x, y -4, z, 0);
}
if(Entity.getRenderType(Player.getEntity()) == golemRenderer.renderType){
if(getTile(x, y, z) == 3){
setTile(x, y -1, z, 0);
setTile(x, y -2, z, 0);
setTile(x, y -3, z, 0);
setTile(x, y -4, z, 0);}
}
}
}
}