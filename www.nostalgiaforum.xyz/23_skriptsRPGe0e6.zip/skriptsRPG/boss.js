//v.1.0
//by Fred (Илья Ш.)

ModPE.setItem(600,"blaze_rod",0,"Zog Spawner");
ModPE.setItem(601,"ruby",0,"Kristal");

function useItem(x,y,z,i,b,s)
{
if(i==280 && b==41)
{
Level.destroyBlock (x,y,z);
Level.dropItem (x, y, z, 1, 600, 1, 0);
Entity.setCarriedItem(getPlayerEnt(),0);
clientMessage("Получи ключ");
}
      
if (i==600 && b==41)
{
var stve = Level.spawnMob(x, y + 1, z, 32, "mob/Zog.png");
Entity.setRenderType(stve, 3);
Entity.setHealth(stve,1000);
steve = 1;
clientMessage("<Zog> Я появился ! Ха, ты мне больше не нужен, Бугагагаааааааа !!!");
Level.destroyBlock (x,y,z);
Entity.setCarriedItem(getPlayerEnt(),0);
}
}
function attackHook(attacker,victim)
{
if(Entity.getEntityTypeId(victim)==32&&steve==1)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
damage = Entity.getHealth(victim) -10;
}
}
function deathHook(attacker, victim)
{
if(Entity.getEntityTypeId(victim)==32&&steve==1)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 601, 2, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 264, 10, 0);
}
}