ModPE.setFoodItem(501, "hopper", 0, 10, "Herobrine Spawner");
var countdown = 501;
var steve = 0;

function useItem(x,y,z,itemId,blockId)
{
if(itemId==264)
{
var stve = Level.spawnMob(x, y + 1, z, 32, "mob/Enderbrine.png");
Entity.setRenderType(stve, 3);
Entity.setHealth(stve,100);
steve = 1;
clientMessage("Я съем твои мозги !");
}
clientMessage("Я превращу тебя в прах ! ");
}
}
function attackHook(attacker,victim)
{
if(Entity.getEntityTypeId(victim)==32&&steve==1)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
}
}

function attackHook(attacker,victim)
{
if(Entity.getEntityTypeId(victim)==32&&steve==1)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
}
}

function deathHook(attacker, victim)
{
if(Entity.getEntityTypeId(victim)==32&&steve==1)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 500, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 500, 1, 15);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 500, 19, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 500, 55, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 500, 1, 0);
steve = 0;
clientMessage("Мы еще встретимся !");
}
}