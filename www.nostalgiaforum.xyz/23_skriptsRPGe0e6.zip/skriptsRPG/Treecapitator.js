var enabled = true;
var itemId;
var blockId;
var damage;
var logdata;

function newLevel()
{
 clientMessage("Приятной игры!\n Делал:Дмитрий (ZiP)");
} 

function destroyBlock(x, y, z, side)
{ 
 if (enabled == true)
 { 
  itemId=Player.getCarriedItem();
  blockId=getTile (x, y, z);
  if(itemId == 271 || itemId == 275 || itemId == 279 || itemId == 286 || itemId == 258)
  {
   if(blockId == 17)
   { 
    logdata=Level.getData(x, y, z); 
    Level.destroyBlock(x,y,z); 
    Level.dropItem(x,y,z,1,17,1,logdata); 
    for (var a = 1; a < 128; a++)
    {
     if(getTile (x, y + a, z) == 17)
     {
      logdata=Level.getData(x, y+a, z);
      Level.destroyBlock(x,y+a,z);
      Level.dropItem(x,y+a,z,1,17,1,logdata);
      Level.destroyBlock(x+1,y+a,z);
      Level.destroyBlock(x-1,y+a,z);
      Level.destroyBlock(x,y+a,z+1);
      Level.destroyBlock(x,y+a,z-1);
      Level.destroyBlock(x+2,y+a,z);
      Level.destroyBlock(x-2,y+a,z);
      Level.destroyBlock(x,y+a,z+2);
      Level.destroyBlock(x,y+a,z-2);
      Level.destroyBlock(x+1,y+a,z+1);
      Level.destroyBlock(x+1,y+a,z+2);
      Level.destroyBlock(x+2,y+a,z+1);
      Level.destroyBlock(x+2,y+a,z+2);
      Level.destroyBlock(x-1,y+a,z-1);
      Level.destroyBlock(x-1,y+a,z-2);
      Level.destroyBlock(x-2,y+a,z-1);
      Level.destroyBlock(x-2,y+a,z-2);
      Level.destroyBlock(x+1,y+a,z-1);
      Level.destroyBlock(x+1,y+a,z-2);
      Level.destroyBlock(x+2,y+a,z-1);
      Level.destroyBlock(x+2,y+a,z-2);
      Level.destroyBlock(x-1,y+a,z+1);
      Level.destroyBlock(x-1,y+a,z+2);
      Level.destroyBlock(x-2,y+a,z+1);
      Level.destroyBlock(x-2,y+a,z+2);
      Level.destroyBlock(x+3,y+a,z);
      Level.destroyBlock(x-3,y+a,z);
      Level.destroyBlock(x,y+a,z+3);
      Level.destroyBlock(x,y+a,z-3);
      Level.destroyBlock(x+1,y+a,z+3);
      Level.destroyBlock(x+3,y+a,z+1);
      Level.destroyBlock(x+3,y+a,z+3);
      Level.destroyBlock(x-1,y+a,z-3);
      Level.destroyBlock(x-3,y+a,z-1);
      Level.destroyBlock(x-3,y+a,z-3);
      Level.destroyBlock(x+1,y+a,z-3);
      Level.destroyBlock(x+3,y+a,z-1);
      Level.destroyBlock(x+3,y+a,z-3);
      Level.destroyBlock(x-1,y+a,z+3);
      Level.destroyBlock(x-3,y+a,z+1);
      Level.destroyBlock(x-3,y+a,z+3);
     }
     else if(getTile(x,y+a,z) == 18)
     {
      Level.destroyBlock(x,y+a,z);
      Level.dropItem (x, y+a, z, 1, 260, 1, 0);
      Level.destroyBlock(x+1,y+a,z);
      Level.dropItem (x+1, y+a, z, 1, 6, 1, logdata);
      Level.destroyBlock(x-1,y+a,z);
      Level.dropItem (x-1, y+a, z, 1, 6, 1, logdata);
      Level.destroyBlock(x,y+a,z+1);
      Level.destroyBlock(x,y+a,z-1);
     }
    } 
    preventDefault();
   }
  }
 }
}