
var Ypos=0;
var i=1;
var Ydiff=0;

function attackHook(attacker, victim)
{
    //Your Code Here
}
function modTick()
{
  if(getCarriedItem()==501)
  {
      if(i==1)
      {
        Ypos=getPlayerY();
        
        i = i + 1;
      }
      else if(i==3)
      {
        i=1;
        
        Ydiff=getPlayerY()-Ypos;
        setVelY(getPlayerEnt(),Ydiff);        
        Ydiff=0;
        
      }
  if(i!=1)
  {
  i = i + 1;
  }
}
}
