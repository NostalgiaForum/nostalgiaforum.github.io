//Bottled mobs mod
//by godraadan
var initialized=false;
var dropBottle=Math.floor(Math.random() * 15);
function selectLevelHook() {
if(initialized==false) {
ModPE.setItem(460, "potion_bottle_splash", 0, "Mob bottle");
ModPE.setItem(461, "experience_bottle", 0, "Cow in a bottle");
ModPE.setItem(462, "experience_bottle", 0, "Pig in a bottle");
ModPE.setItem(463, "experience_bottle", 0, "Sheep in a bottle");
ModPE.setItem(464, "experience_bottle", 0, "Chicken in a bottle");
initialized=true;
} 
}

function attackHook(attacker, victim) {
var victimEntity=Entity.getEntityTypeId(victim);
if(getCarriedItem()==400&&victimEntity==11&&dropBottle==1){
preventDefault();
Entity.setHealth(victim, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 460, 1);
preventDefault();
Entity.setHealth(victim, 0);
}
else if(getCarriedItem()==400&&victimEntity==10&&dropBottle==1){
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 460, 1);
preventDefault();
Entity.setHealth(victim, 0);
} 
else if(getCarriedItem()==400&&victimEntity==12&&dropBottle==1){
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 460, 1);
preventDefault(victim, 0);
}
else if(getCarriedItem()==400&&victimEntity==13&&dropBottle==1){
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 460, 1);
preventDeafault(victim, 0);
}
else if(getCarriedItem()==460&&victimEntity==11){
setPositionRelative(victim, 300, 300, 300);
Entity.setCarriedItem(attacker, 461, 1);
}
else if(getCarriedItem()==460&&victimEntity==10){
setPositionRelative(victim, 300, 300, 300);
Entity.setCarriedItem(attacker, 464, 1);
}
else if(getCarriedItem()==460&&victimEntity==12){
setPositionRelative(victim, 300, 300, 300);
Entity.setCarriedItem(attacker, 462, 1);
}
else if(getCarriedItem()==460&&victimEntity==13) {
setPositionRelative(victim, 300, 300, 300);
Entity.setCarriedItem(attacker, 463, 1);
} 
} 

function useItem(x, y, z, itemId, blockId, side) {
if(getCarriedItem()==461){
Level.spawnCow(x, y+1, z);
Entity.setCarriedItem(Player.getEntity(), 460, 1);
}
else if(getCarriedItem()==464) {
Level.spawnChicken(x, y+1, z);
Entity.setCarriedItem(Player.getEntity(), 460, 1);
}
else if(getCarriedItem()==462) {
Level.spawnMob(x, y+1, z, 12);
Entity.setCarriedItem(Player.getEntity(), 460, 1);
}
else if(getCarriedItem()==463) {
Level.spawnMob(x, y+1, z, 13);
Entity.setCarriedItem(Player.getEntity(), 460, 1);
} 
} 