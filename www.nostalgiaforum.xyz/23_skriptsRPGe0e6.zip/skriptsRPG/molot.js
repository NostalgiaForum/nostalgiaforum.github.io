ModPE.setItem(501,4,5,"молот")


function attackHook(attacker, victim)
{
  if(getCarriedItem()==501)
  {
var hit = Entity.getHealth(victim) -18;
Entity.setHealth(victim, hit);
Entity.setFireTicks(victim,12)
}
}

function useItem(x,y,z,itemId,blockId,side)
{
     if(itemId==280&&blockId==42)
       {
        setTile(x, y, z, 0);
        addItemInventory(501,1) 
        addItemInventory(280,-1) 
}      
if(itemId==501&&blockId==3)
{
explode(x,y,z,2.0)
}
if(itemId==501&&blockId==2)
{
explode(x,y,z,2.0)
}
if(itemId==501&&blockId==1)
{
explode(x,y,z,3.0)
} 
if(itemId==501&&blockId==17)
{
        setTile(x, y, z, 0);       
	    Level.dropItem(x,y,z,1,5, 4);
       }
if(itemId==501&&blockId==12)
{
explode(x,y,z,2.0)
} 
if(itemId==501&&blockId==24)
{
explode(x,y,z,2.0)
}
if(itemId==501&&blockId==57)
{       
       Player.setArmorSlot(0 ,310, 1)
       Player.setArmorSlot(2 ,312, 1)
       Player.setArmorSlot(1 ,311, 1)
       Player.setArmorSlot(3 ,313, 1)
       Player.setHealth(32767);
                 clientMessage("Вы властелин молота!")
}
}
