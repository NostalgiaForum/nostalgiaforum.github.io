Item.addShapedRecipe(264,320,0, ["a"], ["a",3,0]);
Item.addShapedRecipe(388,320,0, ["a"], ["a",4,0]);
Item.addShapedRecipe(265,320,0, ["a"], ["a",37,0]);
Item.addShapedRecipe(266,320,0, ["a"], ["a",12,0]);

function procCmd(cmd)
{
if(cmd=="bloki")
{
addItemInventory (3, 16)
addItemInventory (4,16)
addItemInventory (37,16)
addItemInventory (12,16)
addItemInventory (280,192)
}
}
