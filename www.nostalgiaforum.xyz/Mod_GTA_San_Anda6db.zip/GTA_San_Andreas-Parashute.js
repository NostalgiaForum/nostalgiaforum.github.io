var zoom=false;
var i=0;
var m=0;
var x=Player.getX()
var y=Player.getY()
var z=Player.getZ()
var carVelG = 1;
var carVelI = 0.5;
var carVelD = 3;

ModPE.setItem(501,"repeater",0,"Parachute");

Block.defineBlock(180,"Parashute",["wool",0],1,5);
Block.setShape(180,0,0,0,1,1/16,1);

function modTick() 
{
if(Player.getArmorSlot(1)==501)
{
for(var xn = -2;xn < 2;xn++)
{
setVelY(getPlayerEnt(), -0.05)
setTile(Player.getX(),Player.getY()+2,Player.getZ(),180)
setTile(Player.getX()+1,Player.getY()+2,Player.getZ(),180)
setTile(Player.getX()-1,Player.getY()+2,Player.getZ(),180)
setTile(Player.getX(),Player.getY()+2,Player.getZ()+1,180)
setTile(Player.getX(),Player.getY()+2,Player.getZ()-1,180)
setTile(Player.getX()+1,Player.getY()+2,Player.getZ()+1,180)
setTile(Player.getX()-1,Player.getY()+2,Player.getZ()-1,180)
setTile(Player.getX()-1,Player.getY()+2,Player.getZ()+1,180)
setTile(Player.getX()+1,Player.getY()+2,Player.getZ()-1,180)
setTile(Player.getX(),Player.getY()+3,Player.getZ(),0)
setTile(Player.getX()+1,Player.getY()+3,Player.getZ(),0)
setTile(Player.getX()-1,Player.getY()+3,Player.getZ(),0)
setTile(Player.getX(),Player.getY()+3,Player.getZ()+1,0)
setTile(Player.getX(),Player.getY()+3,Player.getZ()-1,0)
setTile(Player.getX()+1,Player.getY()+3,Player.getZ()+1,0)
setTile(Player.getX()-1,Player.getY()+3,Player.getZ()-1,0)
setTile(Player.getX()-1,Player.getY()+3,Player.getZ()+1,0)
setTile(Player.getX()+1,Player.getY()+3,Player.getZ()-1,0)
setTile(Player.getX()+xn,Player.getY()+2,Player.getZ()-2,0)
setTile(Player.getX()+xn,Player.getY()+2,Player.getZ()+2,0)
setTile(Player.getX()+2,Player.getY()+2,Player.getZ()+xn,0)
setTile(Player.getX()-2,Player.getY()+2,Player.getZ()+xn,0)
}
}
if(i==777)
{
if(Player.getArmorSlot(1)==504)
{
setVelY(getPlayerEnt(),0.4)
explode(x,y,z,2)
	var yaw = Entity.getYaw(Player.getEntity());
{
setVelX(getPlayerEnt(), -carVelI * Math.sin(yaw / 180 * Math.PI));
setVelZ(getPlayerEnt(), carVelI * Math.cos(yaw / 180 * Math.PI));
}
i=0
}
if(Player.getCarriedItem()==504&&Player.getArmorSlot(1) == 0)
{
Player.setArmorSlot(1, 504);
addItemInventory (504, -1)
}
if(Player.getCarriedItem()==501&&Player.getArmorSlot(1) == 0)
{    Player.setArmorSlot(1, 501);
addItemInventory (501, -1)
}
if(zoom==false)
{
if(Player.getCarriedItem()==496)
{
ModPE.setFov(10);
zoom = true;
}
i=0
}
else if(zoom==true)
{
if(Player.getCarriedItem()==496)
{
ModPE.setFov(70);
zoom = false;
}
i=0
}
}
}

function newLevel()
{
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
        try{
            var layout2 = new android.widget.LinearLayout(ctx);
            layout2.setOrientation(1);

            var button2 = new android.widget.Button(ctx);
            button2.setText("↑");
            button2.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                   i=777
                }
            }));
            layout2.addView(button2);

            GUI2 = new android.widget.PopupWindow(layout2, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            GUI2.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.GRAY));
            GUI2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 10, 200);
        }catch(err){
            print("An error occured: " + err);
        }
    }}));

}

function leaveGame()
{
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable(
{ 
run: function()
{        
if(GUI2 != null)
{
GUI2.dismiss();
GUI2 = null;
} 
if(GUI != null)
{
GUI.dismiss();
GUI = null;
}
}
}));
}
