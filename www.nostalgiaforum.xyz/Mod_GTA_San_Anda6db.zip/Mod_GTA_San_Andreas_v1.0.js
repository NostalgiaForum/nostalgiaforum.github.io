var zoom=false
var fcd=0
var fac=0
var fx
var fy
var fz
var enabled = true;
var itemId;
var blockId;
var damage;
var logdata;
var pigsy;
var car;
var isOnBoat = false;
var almondBread=0;
var sd=1;
var d=0;
var a=0;
var o=0;
var climb=0;
var s=0;
var x=Player.getX()
var y=Player.getY()
var z=Player.getZ()
var carVelG = 1;
var carVelI = 0.5;
var carVelD = 3;

var Xpos=getPlayerX();
var Zpos=getPlayerZ();
var Xdiff=getPlayerX()-Xpos;
var Zdiff=getPlayerZ()-Zpos;

var GUI;
var GUI2;
var GUI3;
var GUI4;
var GUI5;

var sd=1

ModPE.setItem(496,"rotten_flesh",0,"Snuperka");
ModPE.setItem(497,"nether_star",0,"Shotgun");
ModPE.setItem(498,"nether_wart",0,"The benzo");
ModPE.setItem(499,"fireworks",0,"M-4");
ModPE.setItem(500,"fireworks_charge",0,"Firextinguisher");
ModPE.setItem(502,"name_tag",0,"Ford");
ModPE.setItem(503,"lead",0,"Mostang");
ModPE.setItem(504,"spider_eye",0,"Jet-pack");
ModPE.setItem(505,"ruby",0,"Katana");
ModPE.setItem(506,"melon_speckled",0,"Bat");
ModPE.setItem(507,"skull_steve",0,"Flamethower");
ModPE.setItem(508,"skull_zombie",0,"10$");
ModPE.setItem(509,"skull_creeper",0,"Minigun");
ModPE.setItem(510,"skull_skeleton",0,"Bazooka");
ModPE.setItem(511,"skull_wither",0,"Handgun");

Block.defineBlock(210,"huynia",["snow",0],1,1,11);
Block.setDestroyTime(210,0.03);

Item.addCraftRecipe( 509, 63, 0, [508, 9, 0]);
Item.addCraftRecipe( 511, 11, 0, [508, 4, 0]);
Item.addCraftRecipe( 510, 9, 0, [508, 6, 0]);
Item.addCraftRecipe( 507, 10, 0, [508, 5, 0]);
Item.addCraftRecipe( 506, 1, 0, [508, 2, 0]);
Item.addCraftRecipe( 505, 1, 0, [508, 8, 0]);
Item.addCraftRecipe( 303, 1, 0, [508, 9, 0]);
Item.addCraftRecipe( 304, 1, 0, [508, 9, 0]);
Item.addCraftRecipe( 305, 1, 0, [508, 9, 0]);
Item.addCraftRecipe( 299, 1, 0, [508, 9, 0]);
Item.addCraftRecipe( 301, 1, 0, [508, 9, 0]);
Item.addCraftRecipe( 504, 1, 0, [508, 9, 0]);
Item.addCraftRecipe( 501, 1, 0, [508, 9, 0]);
Item.addCraftRecipe( 499, 10, 0, [508, 7, 0]);
Item.addCraftRecipe( 498, 1, 0, [508, 9, 0]);
Item.addCraftRecipe( 497, 10, 0, [508, 8, 0]);
Item.addCraftRecipe( 496, 10, 0, [508, 7, 0]);
Item.addCraftRecipe( 500, 25, 0, [508, 5, 0]);

Item.setMaxDamage(303,5000);
Item.setMaxDamage(304,5000);
Item.setMaxDamage(305,5000);
Item.setMaxDamage(299,5000);
Item.setMaxDamage(300,5000);
Item.setMaxDamage(301,5000);

ModPE.langEdit("item.chestplateChain.name","Shirt Grove-Street");
ModPE.langEdit("item.leggingsChain.name","Jeans");
ModPE.langEdit("item.bootsChain.name","Sneakers Grove-Street");
ModPE.langEdit("item.chestplateCloth.name","Shirt Ballas");
ModPE.langEdit("item.bootsCloth.name","Sneakers Ballas");

function deathHook(attacker, victim)
{
if(Entity.getEntityTypeId(victim)==32&&Math.floor(Math.random() * 4)==1)
{preventDefault();
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 508, 1, 0);
}
if(Entity.getEntityTypeId(victim)==32&&Math.floor(Math.random() * 4)==3)
{preventDefault();
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 508, 2, 0);
}
if(Entity.getEntityTypeId(victim)==32&&Math.floor(Math.random() * 4)==2)
{preventDefault();
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 511, 2, 0);
}
if(Entity.getEntityTypeId(victim)==32&&Math.floor(Math.random() * 4)==8)
{preventDefault();
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 509, 63, 0);
}
if(Entity.getEntityTypeId(victim)==32&&Math.floor(Math.random() * 4)==7)
{preventDefault();
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 510, 5, 0);
}
if(Entity.getEntityTypeId(victim)==32&&Math.floor(Math.random() * 4)==6)
{preventDefault();
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 499, 4, 0);
}
}

function useItem(x, y, z, itemId, blockId)
{
if(itemId==507)
{
setTile(x, y +1, z, 51)
setTile(x +1, y +1, z, 51)
setTile(x, y +1, z +1, 51)
setTile(x+1, y +1, z +1, 51)
setTile(x -1, y +1, z, 51)
setTile(x, y +1, z -1, 51)
setTile(x-1, y +1, z-1, 51)
addItemInventory (507, -1)
}
if(itemId==503&&blockId==66) 
{
addItemInventory (503, -1)
var car = Level.spawnMob( x, y + 1, z, 84, "entity/Moostang.png");
car = 1;
}
if(itemId==0&&Math.floor(Math.random() * 4)==1)
{
spawnPigZombie(Player.getX(), Player.getY(), Player.getZ(), 498, "mob/pigzombie.png" );
}
if(itemId==500)
{
fac=1
fx=x
fy=y
fz=z
setTile(x, y +1, z, 210)
setTile(x +1, y +1, z, 210)
setTile(x, y +1, z +1, 210)
setTile(x+1, y +1, z +1, 210)
setTile(x -1, y +1, z, 210)
setTile(x, y +1, z -1, 210)
setTile(x-1, y +1, z-1, 210)
setTile(x, y +2, z, 210)
Entity.setCarriedItem(getPlayerEnt(),getCarriedItem(),Player.getCarriedItemCount()-1);
}
}

function attackHook(attacker, victim)
{
if(getCarriedItem()==505)
  {
var hit = Entity.getHealth(victim) -8;
Entity.setHealth(victim, hit);
Entity.setFireTicks(victim,0)
}
if(getCarriedItem()==507)
  {
var hit = 
Entity.getHealth(victim) -1;
Entity.setHealth(victim, hit);
Entity.setFireTicks(victim,10)
addItemInventory (507, -1)
}
if(getCarriedItem()==506) 
{ 
preventDefault(); 
damage = Entity.getHealth(victim) -1.5; 
Entity.setHealth(victim,damage); 
ours = Entity.getHealth(getPlayerEnt()) + 0; 
Entity.setHealth(getPlayerEnt(),ours); 
if(Entity.getHealth(getPlayerEnt()) > 20) 
Entity.setHealth(getPlayerEnt(),20); 
var x = Entity.getX(victim); 
var y = Entity.getY(victim); 
var z = Entity.getZ(victim); 
setVelY(victim,1); 
}
if(getCarriedItem()==498)
  {
var hit = Entity.getHealth(victim) -4;
Entity.setHealth(victim, hit);
Entity.setFireTicks(victim,0)
}
}

function procCmd(cmd){
 var cmd = cmd.split(" "); 
if(cmd[0]=="BAGUVIX")
{ 
Player.setHealth (32767);
clientMessage("Cheat-code is activated");
}
if(cmd[0]=="HESOYAM")
{
Player.setHealth (20);
addItemInventory (508, 64)
clientMessage("Cheat-code is activated");
} 
if(cmd[0]=="AIYPWZQP")
{
addItemInventory (501, 1)
clientMessage("Cheat-code is activated");
} 
if(cmd[0]=="YECGAA")
{
addItemInventory (504, 1)
clientMessage("Cheat-code is activated");
} 
if(cmd[0]=="ROCKETMAN")
{
addItemInventory (504, 1)
clientMessage("Cheat-code is activated");
} 
if(cmd[0]=="SZCMAWO")
{
Player.setHealth (0);
clientMessage("Cheat-code is activated");
} 
if(cmd[0]=="AFPHULTL")
{
addItemInventory (505, 1)
clientMessage("Cheat-code is activated");
} 
if(cmd[0]=="LXGIWYL")
{
addItemInventory (511, 63)
addItemInventory (510, 63)
addItemInventory (509, 63)
addItemInventory (507, 63)
addItemInventory (499, 63)
addItemInventory (497, 63)
clientMessage("Cheat-code is activated");
} 
if(cmd[0]=="villager"){ 
Entity.setMobSkin(getPlayerEnt(),"mob/villager/farmer.png")
Entity.setRenderType(getPlayerEnt(),11
);
}
}

function newLevel()
{
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
        try{
            var layout2 = new android.widget.LinearLayout(ctx);
            layout2.setOrientation(1);

            var button2 = new android.widget.Button(ctx);
            button2.setText("Fire");
            button2.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                   a=777
                }
            }));
            layout2.addView(button2);

            GUI2 = new android.widget.PopupWindow(layout2, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            GUI2.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.GRAY));
            GUI2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 10, 100);
        }catch(err){
            print("An error occured: " + err);
        }
    }}));

}

function leaveGame()
{
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable(
{ 
run: function()
{        
if(GUI2 != null)
{
GUI2.dismiss();
GUI2 = null;
} 
if(GUI != null)
{
GUI.dismiss();
GUI = null;
}
}
}));
}

function modTick() 
{
if(a==777)
{
if(Player.getCarriedItem()==511)
{
addItemInventory (511, -1)
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow,velX); 
            setVelY(arrow,velY); 
            setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 30);

a=0
}
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
if(Player.getCarriedItem()==510)
{
addItemInventory (510, -1)
            velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var tnt = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY()+1,Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,65);
            setVelX(tnt,velX); 
            setVelY(tnt,velY); 
            setVelZ(tnt,velZ);  
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 30);

a=0
}
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
if(Player.getCarriedItem()==509)
{
addItemInventory (509, -1)
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow,velX); 
            setVelY(arrow,velY); 
            setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 30);

a=777
}
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
if(Player.getCarriedItem()==499&&almondBread==0)
{preventDefault();
almondBread=1;
addItemInventory (499, -1)
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow,velX); 
            setVelY(arrow,velY); 
            setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 30);

a=777
}
else if(Player.getCarriedItem()==499&&almondBread==1)
{preventDefault();
almondBread=2;
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow,velX); 
            setVelY(arrow,velY); 
            setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 30);

a=777
}
else if(Player.getCarriedItem()==499&&almondBread==2)
{preventDefault();
almondBread=3;
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow,velX); 
            setVelY(arrow,velY); 
            setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 30);

a=777
}
else if(Player.getCarriedItem()==499&&almondBread==3)
{preventDefault();
almondBread=4;
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow,velX); 
            setVelY(arrow,velY); 
            setVelZ(arrow,velZ);
clientMessage("");
almondBread=0;
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 30);

a=0
}
if(getCarriedItem()==497)
{
addItemInventory (497, -1)
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow,velX*5); 
            setVelY(arrow,velY*5); 
            setVelZ(arrow,velZ*5);

        var arrow2 = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow2,velX); 
            setVelY(arrow2,velY); 
            setVelZ(arrow2,velZ);

        var arrow3 = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow3,velX); 
            setVelY(arrow3,velY); 
            setVelZ(arrow3,velZ);

        var arrow4 = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow4,velX*5); 
            setVelY(arrow4,velY); 
            setVelZ(arrow4,velZ*5);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), 
"random.explode", 100, 30);

a=0
}
if(Player.getCarriedItem()==496)
{
addItemInventory (496, -1)
ModPE.setFov(70);
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 5.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 5.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
            setVelX(arrow,velX); 
            setVelY(arrow,velY); 
            setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.explode", 100, 30);

a=0
}
}
}

function destroyBlock(x, y, z, side)
{ 
 if (enabled == true)
 { 
  itemId=Player.getCarriedItem();
  blockId=getTile (x, y, z);
  if(itemId == 498)
  {
   if(blockId == 17)
   { 
    logdata=Level.getData(x, y, z); 
    Level.destroyBlock(x,y,z); 
    Level.dropItem(x,y,z,1,17,1,logdata); 
    for (var a = 1; a < 128; a++)
    {
     if(getTile (x, y + a, z) == 17)
     {
      logdata=Level.getData(x, y+a, z);
      Level.destroyBlock(x,y+a,z);
      Level.dropItem(x,y+a,z,1,17,1,logdata);
      Level.destroyBlock(x+1,y+a,z);
      Level.destroyBlock(x-1,y+a,z);
      Level.destroyBlock(x,y+a,z+1);
      Level.destroyBlock(x,y+a,z-1);
      Level.destroyBlock(x+2,y+a,z);
      Level.destroyBlock(x-2,y+a,z);
      Level.destroyBlock(x,y+a,z+2);
      Level.destroyBlock(x,y+a,z-2);
      Level.destroyBlock(x+1,y+a,z+1);
      Level.destroyBlock(x+1,y+a,z+2);
      Level.destroyBlock(x+2,y+a,z+1);
      Level.destroyBlock(x+2,y+a,z+2);
      Level.destroyBlock(x-1,y+a,z-1);
      Level.destroyBlock(x-1,y+a,z-2);
      Level.destroyBlock(x-2,y+a,z-1);
      Level.destroyBlock(x-2,y+a,z-2);
      Level.destroyBlock(x+1,y+a,z-1);
      Level.destroyBlock(x+1,y+a,z-2);
      Level.destroyBlock(x+2,y+a,z-1);
      Level.destroyBlock(x+2,y+a,z-2);
      Level.destroyBlock(x-1,y+a,z+1);
      Level.destroyBlock(x-1,y+a,z+2);
      Level.destroyBlock(x-2,y+a,z+1);
      Level.destroyBlock(x-2,y+a,z+2);
      Level.destroyBlock(x+3,y+a,z);
      Level.destroyBlock(x-3,y+a,z);
      Level.destroyBlock(x,y+a,z+3);
      Level.destroyBlock(x,y+a,z-3);
      Level.destroyBlock(x+1,y+a,z+3);
      Level.destroyBlock(x+3,y+a,z+1);
      Level.destroyBlock(x+3,y+a,z+3);
      Level.destroyBlock(x-1,y+a,z-3);
      Level.destroyBlock(x-3,y+a,z-1);
      Level.destroyBlock(x-3,y+a,z-3);
      Level.destroyBlock(x+1,y+a,z-3);
      Level.destroyBlock(x+3,y+a,z-1);
      Level.destroyBlock(x+3,y+a,z-3);
      Level.destroyBlock(x-1,y+a,z+3);
      Level.destroyBlock(x-3,y+a,z+1);
      Level.destroyBlock(x-3,y+a,z+3);
     }
     else if(getTile(x,y+a,z) == 18)
     {
      Level.destroyBlock(x,y+a,z);
      Level.dropItem (x, y+a, z, 1, 260, 1, 0);
      Level.destroyBlock(x+1,y+a,z);
      Level.dropItem (x+1, y+a, z, 1, 6, 1, logdata);
      Level.destroyBlock(x-1,y+a,z);
      Level.dropItem (x-1, y+a, z, 1, 6, 1, logdata);
      Level.destroyBlock(x,y+a,z+1);
      Level.destroyBlock(x,y+a,z-1);
     }
    } 
    preventDefault();
   }
  }
 }
}


