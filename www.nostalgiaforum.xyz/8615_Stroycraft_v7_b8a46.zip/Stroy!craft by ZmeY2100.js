var anti=-1
var tptime=0



Block.defineBlock(210,"Assembly Foam Block",["snow",0],1,1,11);
Block.setDestroyTime(210,0.03);
Player.addItemCreativeInv(210,1,0);
Block.setColor(210,[0xfff6ffd1]);
Block.defineBlock(211,"Hardened Assembly Foam Block",["snow",0],17,1,11);
Block.setDestroyTime(211,0.3);
Player.addItemCreativeInv(211,1,0);
Block.setColor(211,[0xffffc557]);
Block.defineBlock(212,"Cement Block",["quartz_block",0],17,1,11);
Block.setDestroyTime(212,0.03);
Player.addItemCreativeInv(212,1,0);
Block.setColor(212,[0xffa8a8a8]);
Block.defineBlock(213,"Hardened Cement Block",["brewing_stand_base",0],1,1,11);
Block.setDestroyTime(213,1.9);
Player.addItemCreativeInv(213,1,0);
Block.defineBlock(214,"Signal lamp",["redstone_lamp_on",0],1,1,11);
Block.setLightLevel(214,15);
Block.defineBlock(215,"Signal lamp",["redstone_lamp_off",0],1,1,11);
Block.setDestroyTime(214,0.5);
Player.addItemCreativeInv(214,1,0);


Block.defineBlock(216,"Piston",["piston_top_sticky",0],1,1,11);
Block.setDestroyTime(216,0.5);
Player.addItemCreativeInv(216,1,0);
Block.defineBlock(217,"Troob",[["cauldron_inner",0],["cauldron_top",0]],1,1,11);
Block.setDestroyTime(217,0.5);
Player.addItemCreativeInv(217,1,0);
Block.defineBlock(218,"Cran",[["cauldron_top",0],["cauldron_inner",0]],1,1,11);
Block.setDestroyTime(218,0.5);
Player.addItemCreativeInv(218,1,0);
Block.defineBlock(220,"Magnet",[["glowing_obsidian",0]],1,1,11);
Block.setDestroyTime(220,0.5);
Player.addItemCreativeInv(220,1,0);
Block.defineBlock(221,"Hotter",[["redstone_block",0]],1,1,11);
Block.setDestroyTime(221,0.5);
Player.addItemCreativeInv(221,1,0);
Block.defineBlock(222,"Cooler",[["diamond_block",0]],1,1,11);
Block.setDestroyTime(222,0.5);
Player.addItemCreativeInv(222,1,0);
Block.defineBlock(223,"Baterry",[["redstone_dust_cross",0]],1,1,11);
Block.setDestroyTime(223,0.5);
Player.addItemCreativeInv(223,1,0);

Block.defineBlock(224,"Industrial Teleporter To",[["cauldron_top",0]],1,1,11);
Block.setDestroyTime(224,0.5);
Player.addItemCreativeInv(224,1,0);

Block.defineBlock(225,"Industrial Teleporter From",[["cauldron_inner",0]],1,1,11);
Block.setDestroyTime(225,0.5);
Player.addItemCreativeInv(225,1,0);


Block.defineBlock(219,"Wood",[["planks",0]],1,1,11);
Block.setDestroyTime(219,0.5);
Player.addItemCreativeInv(219,64,0);
Player.addItemCreativeInv(482,64,0);
ModPE.setItem(480,"apple_golden",0,"Assembly Foam Spray");
ModPE.setItem(481,"bucket",1,"Cement Bucket");

ModPE.setItem(482,"minecart_normal",1,"Metro Creator");

Item.addShapedRecipe(480,5,0,["isi","iai","isi"],["i",265,0,"s",12,0]);
Item.addShapedRecipe(482,5,0,["sss","sss","sis"],["i",265,0,"s",45,0]);
Item.addShapedRecipe(217,2,0,["iai","iai","iai"],["i",265,0]);
Item.addShapedRecipe(218,2,0,["iii","afa","fff"],["i",265,0,"f",85,0]);
Item.addShapedRecipe(219,2,0,["sss","sss","ppp"],["s",280,0,"p",5,0]);
Item.addShapedRecipe(481,1,0,["asa","aga","awa"],["w",325,8,"s",12,0,"g",13,0]);
Item.addShapedRecipe(214,1,0,["aga","grg","aga"],["g",348,0,"r",331,0]);
Item.addShapedRecipe(216,1,0,["zzz","prp","prp"],["p",5,0,"r",331,0,"z",85,0]);

Item.addShapedRecipe(220,1,0,["iii","iri","iri"],["r",331,0,"i",265,0]);
Item.addShapedRecipe(221,1,0,["iii","iri","iii"],["r",331,0,"i",265,0]);
Item.addShapedRecipe(222,1,0,["iii","iri","iii"],["r",331,0,"i",49,0]);
Item.addShapedRecipe(223,3,0,["iri","iri","iri"],["r",331,0,"i",265,0]);
Item.addShapedRecipe(220,1,0,["iii","iri","iri"],["r",331,0,"i",265,0]);

Item.addShapedRecipe(224,1,0,["iai","iri","iii"],["r",331,0,"i",265,0]);
Item.addShapedRecipe(225,1,0,["iai","iri","iii"],["r",331,0,"i",265,0]);



function newLevel()
{
clientMessage("Stroy! craft mod")
clientMessage("by §4ZmeY2100")
clientMessage("§2release")
}

var fcd=0
var fac=0
var fx
var fy
var fz

var mcd=0
var mac=0
var mx
var my
var mz

var ccd=0
var cac=0
var cx
var cy
var cz

var lcd=0
var lac=0
var lx
var ly
var lz
var on=false

var pcd=0
var pac=0
var px
var py
var pz

var ucd=0
var uac=0
var ux
var uy
var uz

var wcd=0
var wac=0
var wx
var wy
var wz

var hcd=0
var hac=0
var hx
var hy
var hz

var xcd=0
var xac=0
var xx
var xy
var xz

var tcd=0
var tac=0
var tx
var ty
var tz

var ocd=0
var oac=0
var ox
var oy
var oz

function useItem(x,y,z,i,b,s,iD)
{
if(i==79)
{
if(b==210)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),79,Player.getCarriedItemCount()-1,Player.getCarriedItemData())
setTile(x,y,z,211)
}
if(b==212)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),79,Player.getCarriedItemCount()-1,Player.getCarriedItemData())
setTile(x,y,z,213)
}
}
if(i==79)
{
if(b==210)
{
setTile(x,y,z,211)
}
if(b==212)
{
setTile(x,y,z,213)
}
}
if(i==224)
{
preventDefault();
setTile(x,y,z,224)
tx=x
ty=y
tz=z
}
if(i==225)
{
preventDefault();
setTile(x,y,z,225)
ox=x
oy=y
oz=z
}
if(b==224)
{
tac=1
tptime=1
}
if(b==225)
{
oac=1
tptime=1
}
if(b==221)
{
if(getTile(x+1,y,z)==223)
{
Entity.setCarriedItem(getPlayerEnt(),getCarriedItem(),Player.getCarriedItemCount()-2,Player.getCarriedItemData())
preventDefault();
hac=1
hx=x-1
hy=y
hz=z
}
if(getTile(x-1,y,z)==223)
{
Entity.setCarriedItem(getPlayerEnt(),getCarriedItem(),Player.getCarriedItemCount()-2,Player.getCarriedItemData())
preventDefault();
hac=1
hx=x+1
hy=y
hz=z
}
if(getTile(x,y,z+1)==223)
{
Entity.setCarriedItem(getPlayerEnt(),getCarriedItem(),Player.getCarriedItemCount()-2,Player.getCarriedItemData())
preventDefault();
hac=1
hx=x
hy=y
hz=z-1
}
if(getTile(x,y,z-1)==223)
{
Entity.setCarriedItem(getPlayerEnt(),getCarriedItem(),Player.getCarriedItemCount()-2,Player.getCarriedItemData())
preventDefault();
hac=1
hx=x
hy=y
hz=z+1
}
}
if(b==222&&i==325&&iD==8)
{
if(getTile(x+1,y,z)==223)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),325,1,0);
xac=1
xx=x-1
xy=y
xz=z
}
if(getTile(x-1,y,z)==223)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),325,1,0);
xac=1
xx=x+1
xy=y
xz=z
}
if(getTile(x,y,z+1)==223)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),325,1,0);
xac=1
xx=x
xy=y
xz=z-1
}
if(getTile(x,y,z-1)==223)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),325,1,0);
xac=1
xx=x
xy=y
xz=z+1
}
}
if(i==482)
{
if(s==2||s==3)
{
setTile(x+2,y-2,z,45)
setTile(x+1,y-2,z,45)
setTile(x-2,y-2,z,45)
setTile(x-1,y-2,z,45)
setTile(x,y-2,z,45)
setTile(x+2,y+2,z,45)
setTile(x+1,y+2,z,45)
setTile(x-2,y+2,z,45)
setTile(x-1,y+2,z,45)
setTile(x,y+2,z,89)
setTile(x+2,y-1,z,45)
setTile(x+2,y,z,45)
setTile(x+2,y+1,z,45)
setTile(x-2,y-1,z,45)
setTile(x-2,y,z,45)
setTile(x-2,y+1,z,45)
setTile(x,y,z,0)
setTile(x+1,y,z,0)
setTile(x-1,y,z,0)
setTile(x,y+1,z,0)
setTile(x+1,y+1,z,0)
setTile(x-1,y+1,z,0)
setTile(x,y-1,z,27)
setTile(x+1,y-1,z,0)
setTile(x-1,y-1,z,0)
}
if(s==4||s==5)
{
setTile(x,y-2,z+2,45)
setTile(x,y-2,z+1,45)
setTile(x,y-2,z-2,45)
setTile(x,y-2,z-1,45)
setTile(x,y-2,z,45)
setTile(x,y+2,z+2,45)
setTile(x,y+2,z+1,45)
setTile(x,y+2,z-2,45)
setTile(x,y+2,z-1,45)
setTile(x,y+2,z,89)
setTile(x,y-1,z+2,45)
setTile(x,y,z+2,45)
setTile(x,y+1,z+2,45)
setTile(x,y-1,z-2,45)
setTile(x,y,z-2,45)
setTile(x,y+1,z-2,45)
setTile(x,y,z,0)
setTile(x,y,z+1,0)
setTile(x,y,z-1,0)
setTile(x,y+1,z,0)
setTile(x,y+1,z+1,0)
setTile(x,y+1,z-1,0)
setTile(x,y-1,z,27)
setTile(x,y-1,z+1,0)
setTile(x,y-1,z-1,0)
}
}
if(b==218)
{
preventDefault();
uac=1
ux=x
uy=y
uz=z
}
if(b==220)
{
preventDefault();
mac=1
mx=x
my=y
mz=z
}
if(b==219)
{
preventDefault();
wac=1
wx=x
wy=y
wz=z
}
if(b==217)
{
if(getTile(x,y+1,z)==217&&getTile(x,y+2,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+2,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
if(getTile(x,y+2,z)==217&&getTile(x,y+3,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+3,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
if(getTile(x,y+3,z)==217&&getTile(x,y+4,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+4,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
if(getTile(x,y+4,z)==217&&getTile(x,y+5,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+5,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
if(getTile(x,y+5,z)==217&&getTile(x,y+6,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+6,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
if(getTile(x,y+6,z)==217&&getTile(x,y+7,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+7,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
if(getTile(x,y+7,z)==217&&getTile(x,y+8,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+8,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
if(getTile(x,y+8,z)==217&&getTile(x,y+9,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+9,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
if(getTile(x,y+9,z)==217&&getTile(x,y+10,z)==0)
{
preventDefault();
Entity.setCarriedItem(getPlayerEnt(),0,0,0)
Level.dropItem(x,y+10,z,0,i,Player.getCarriedItemCount(),Player.getCarriedItemData())
}
}
if(i==325&&b==212)
{
setTile(x,y,z,0)
Entity.setCarriedItem(getPlayerEnt(),getCarriedItem(),Player.getCarriedItemCount()-1,0)
}
if(i==280)
{
addItemInventory(480,63,0)
addItemInventory(481,63,0)
}
if(i==480)
{
fac=1
fx=x
fy=y
fz=z
setTile(x,y+1,z,210);
Entity.setCarriedItem(getPlayerEnt(),getCarriedItem(),Player.getCarriedItemCount()-1);
}
if(i==481)
{
cac=1
cx=x
cy=y
cz=z
setTile(x,y+1,z,212);
addItemInventory(325,1,0);
Entity.setCarriedItem(getPlayerEnt(),getCarriedItem(),Player.getCarriedItemCount()-1);
}
if(i==214)
{
lac=1
lx=x
ly=y
lz=z
on=true
}
if(b==216)
{
pac=1
px=x
py=y
pz=z
}
}

function modTick()
{
if(hac==1)
{
hcd ++;
}
if(hac==0)
{
hcd=0
}
if(hcd==20)
{
Level.dropItem(hx,hy,hz,0,10,1,0);
hac=0
}
if(xac==1)
{
xcd ++;
}
if(xac==0)
{
xcd=0
}
if(xcd==20)
{
Level.dropItem(xx,xy,xz,0,79,1,0);
xac=0
}
if(wac==1)
{
wcd ++;
}
if(wac==0)
{
wcd=0
}
if(wcd==2)
{
setTile(wx,wy+1,wz,85)
}
if(wcd==4)
{
setTile(wx,wy+2,wz,85)
}
if(wcd==6)
{
setTile(wx,wy+3,wz,85)
}
if(wcd==8)
{
setTile(wx,wy+4,wz,5)
wac=0
wcd=0
}
if(fac==1)
{
fcd ++;
}
if(fcd==100)
{
setTile(fx,fy+1,fz,211);
fac=0
fcd=0
}
if(pac==1)
{
pcd ++;
}
if(pcd==5)
{
setTile(px,py+2,pz,getTile(px,py+1,pz));
setTile(px,py+1,pz,85);
}
if(pcd==10)
{
setTile(px,py+3,pz,getTile(px,py+2,pz));
setTile(px,py+2,pz,85);
}
if(pcd==15)
{
setTile(px,py+4,pz,getTile(px,py+3,pz));
setTile(px,py+3,pz,85);
pac=0
pcd=0
}
if(lac==1)
{
lcd ++;
}
if(on==true&&lcd==5)
{
setTile(lx,ly+1,lz,215);
lcd=0
on=false
}
if(on==false&&lcd==5)
{
setTile(lx,ly+1,lz,214);
lcd=0
on=true
}
if(cac==1)
{
ccd ++;
}
if(ccd==100)
{
setTile(cx,cy+1,cz,213);
cac=0
ccd=0
}
if(uac==0)
{
ucd=0
}
if(uac==1)
{
ucd ++;
}
if(ucd==3)
{
setTile(ux,uy-1,uz,85)
}
if(ucd==6)
{
setTile(ux,uy-2,uz,85)
}
if(ucd==9)
{
setTile(ux,uy-3,uz,85)
}
if(ucd==12)
{
setTile(ux,uy-4,uz,85)
}
if(ucd==15)
{
setTile(ux,uy-5,uz,85)
}
if(ucd==18)
{
setTile(ux,uy-5,uz,getTile(ux,uy-6,uz))
setTile(ux,uy-6,uz,0)
}
if(ucd==21)
{
setTile(ux,uy-4,uz,getTile(ux,uy-5,uz))
setTile(ux,uy-5,uz,0)
}
if(ucd==24)
{
setTile(ux,uy-3,uz,getTile(ux,uy-4,uz))
setTile(ux,uy-4,uz,0)
}
if(ucd==27)
{
setTile(ux,uy-2,uz,getTile(ux,uy-3,uz))
setTile(ux,uy-3,uz,0)
}
if(ucd==30)
{
setTile(ux,uy-1,uz,getTile(ux,uy-2,uz))
setTile(ux,uy-2,uz,0)
uac=0
ucd=0
}
if(getTile(mx,my-2,mz)==42)
{
setTile(mx,my-2,mz,0)
setTile(mx,my-1,mz,42)
}
if(getTile(mx,my-3,mz)==42)
{
setTile(mx,my-3,mz,0)
setTile(mx,my-2,mz,42)
}
if(getTile(mx,my-4,mz)==42)
{
setTile(mx,my-4,mz,0)
setTile(mx,my-3,mz,42)
}
if(getTile(mx,my-5,mz)==42)
{
setTile(mx,my-5,mz,0)
setTile(mx,my-4,mz,42)
}
if(getTile(mx,my-6,mz)==42)
{
setTile(mx,my-6,mz,0)
setTile(mx,my-5,mz,42)
}
if(getTile(mx,my-7,mz)==42)
{
setTile(mx,my-7,mz,0)
setTile(mx,my-6,mz,42)
}
if(getTile(mx,my-8,mz)==42)
{
setTile(mx,my-8,mz,0)
setTile(mx,my-7,mz,42)
}
if(getTile(mx,my-9,mz)==42)
{
setTile(mx,my-9,mz,0)
setTile(mx,my-8,mz,42)
}
if(getTile(mx,my-10,mz)==42)
{
setTile(mx,my-10,mz,0)
setTile(mx,my-9,mz,42)
}
if(oac==1)
{
ocd ++;
}
if(oac==0)
{
ocd=0
}
if(tptime==1)
{
setVelX(getPlayerEnt(),Entity.getVelX(getPlayerEnt())*anti)
setVelZ(getPlayerEnt(),Entity.getVelZ(getPlayerEnt())*anti)
Level.setTime(Level.getTime()-8000)
}
if(ocd==50)
{
setPosition(getPlayerEnt(),tx,ty+4,tz)
oac=0
ocd=0
tptime=0
}
if(tac==1)
{
tcd ++;
}
if(tac==0)
{
tcd=0
}
if(tcd==50)
{
setPosition(getPlayerEnt(),ox,oy+4,oz)
tac=0
tptime=0
}
}



function destroyBlock(x,y,z)
{
if(getTile(x,y,z)==214||getTile(x,y,z)==215)
{
Level.destroyBlock(x,y,z)
on=false
lac=0
}
}