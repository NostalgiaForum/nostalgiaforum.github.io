<?php

/*
__PocketMine Plugin__
name=tCoords
description=Просмотр координат.
version=0.8.1
author=Tema1d
class=tCoords
apiversion=11,12,12.1
*/

// special for VanillaPE...

class tCoords implements Plugin{
	
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->console->register("xyz", "Просмотр твоих координат.", array($this, "command"));
		$this->api->console->alias("coords", "xyz");
		$this->api->console->alias("loc", "xyz");
		$this->api->console->alias("getpos", "xyz");
		$this->api->ban->cmdWhitelist("xyz");
	}
	public function buildMsg($msg){
		return "[tCoords] {$msg}";
	}
	
	public function getCoordsAndWorldName($entity){
		return ["x" => round($entity->x, 1, PHP_ROUND_HALF_UP), 
				"y" => round($entity->y, 1, PHP_ROUND_HALF_UP), 
				"z" => round($entity->z, 1, PHP_ROUND_HALF_UP), 
				"levelname" => $entity->level->getName()];
	}
	
	public function command($cmd, $params, $issuer, $alias){
		$output = "";
	 	switch($cmd){
			case "xyz":
				if(isset($params[0]) && ($this->api->ban->isOp($issuer->username) || !($issuer instanceof Player))){
					$player = $this->api->player->get($params[0]);
					if($player instanceof Player){
						$playerData = $this->getCoordsAndWorldName($player->entity);
						$output = "Координаты игрока {$player->username}: x: {$playerData["x"]}, y: {$playerData["y"]}, z: {$playerData["z"]}, Мир: {$playerData["levelname"]}.";
					}else{
						$output = "Игрок с таким ником не найден.";
					}
				}else if(!($issuer instanceof Player)){
					$output = "Пожалуйста введите ник игрока.";
				}else{
					$playerData = $this->getCoordsAndWorldName($issuer->entity);
					$output = "Твои координаты: x: {$playerData["x"]}, y: {$playerData["y"]}, z: {$playerData["z"]}, Мир: {$playerData["levelname"]}.";
				}
		}
		return $this->buildMsg($output);
	}
	
	public function __destruct(){}
	
}
