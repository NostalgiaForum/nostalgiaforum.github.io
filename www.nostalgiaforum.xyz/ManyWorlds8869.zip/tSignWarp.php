<?php

  /*
  __PocketMine Plugin__
  name=tSignWarp
  description=Создания варпов через табличку.
  version=0.8.1
  author=Tema1d
  class=tSignWarp
  apiversion=11,12,12.1
  */
 
 //Благодарю за помощь, GameHerobrine, ArkQuark

  class tSignWarp implements Plugin
  {
    private $api;

    public function __construct(ServerAPI $api, $server = false)
    {
      $this->api = $api;
    }

    public function init()
    {
      $this->api->addHandler("tile.update", array($this, "eventHandler"));
      $this->api->addHandler("player.block.touch", array($this, "eventHandler"), 666);
    }

    public function __destruct()
    {

    }

    public function handle($data, $event)
    {

    }

    public function eventHandler(&$data, $event)
    {
      switch ($event) {
        case "tile.update":
          if ($data->class === TILE_SIGN) {
            if(!$this->api->ban->isOp($data->data['creator'])){
                return;
            }
            if ($data->data["Text1"] != "w:" and $data->data["Text3"] != "tp")
              return;
            $lvl = $data->data["Text2"];
            if ($this->api->level->loadLevel($lvl) === false) {
              $this->api->chat->sendTo(false, "[tSignWarp] Мир под названием $lvl не существует.", $data->data['creator']);
              break;
            }
            $data->data["Text1"]="[tSignWarp]";
            $data->data["Text2"]="Телепорт в мир";
            $data->data["Text3"]="$lvl";
            $data->data["Text4"]="*клик*";
            $this->api->tile->spawnToAll($data);
          }
          break;
        case "player.block.touch":
          $tile = $this->api->tile->get(new Position($data['target']->x, $data['target']->y, $data['target']->z, $data['target']->level));
          if ($tile === false) break;
          $class = $tile->class;
          switch ($class) {
            case TILE_SIGN:
              switch ($data['type']) {
                case "place":
                  if ($tile->data['Text2'] == "Телепорт в мир" and $this->api->ban->isOp($tile->data['creator']) ){
                    $mapname = $tile->data['Text3'];

                    $lvlname = "w:" . $mapname;
                    $username=$data['player']->username;
                    $this->api->level->loadLevel($mapname);
                    $this->api->player->teleport($username,$lvlname);
                    $this->api->chat->sendTo(false,"[tSignWarp] Вы телепортированы в мир: $mapname." , $username);
                  }
                  break;
              }
              break;
          }
          break;
      }

    }
  }
