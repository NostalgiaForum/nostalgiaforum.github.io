<?php
 
/*
__PocketMine Plugin__
name=BanItem
description=Блокировка предметов на сервере.
version=1.4/Tema1d_Modificated
apiversion=10,11,12,12.1
author=PocketMine/Tema1d
class=BanItem
*/
 
define("PLUGIN_VERSION", 1.4);

class BanItem implements Plugin{
    private $api, $config;
 
    public function __construct(ServerAPI $api, $server = false){
        $this->api = $api;
    }
    
    public function init()
    {
    	$this->api->addHandler("player.equipment.change", array($this, 'handler'), 15);
    	$this->api->console->register("item", "Управления предметами сервера.", array($this, 'commands'));
    	
        $this->config = new Config($this->api->plugin->configPath($this) . "config.yml", CONFIG_YAML, array(
    		"banned-item-list" 			=> array(),
    		"plugin-version"			=> PLUGIN_VERSION,
    		"msg-on-equipment-change" 	=> "Этот предмет запрещен на сервере .",
    		"msg-on-ban-item"			=> "[BanItem] Блок с ID: @name запрещен на сервере.",
    		"msg-on-unban-item"			=> "[BanItem] Блок с ID: @name разрешен на сервере."
    	));

    	if($this->config->get('plugin-version') != PLUGIN_VERSION)
    	{
    		unlink($this->api->plugin->configPath($this) . "config.yml");
    		$this->config = new Config($this->api->plugin->configPath($this) . "config.yml", CONFIG_YAML, array(
				"banned-item-list" 			=> array(),
    		    "plugin-version"			=> PLUGIN_VERSION,
				"msg-on-equipment-change" 	=> "Этот предмет запрещен на сервере .",
				"msg-on-ban-item"			=> "[BanItem] Блок с ID: @name запрещен на сервере.",
				"msg-on-unban-item"			=> "[BanItem] Блок с ID: @name разрешен на сервере."
    		));
    	}
    }

    public function handler(&$data, $event)
    {
    	if($event === "player.equipment.change")
    	{
			if($this->api->ban->isOp($data['player']->iusername) === true) return true;
            $list = $this->config->get('banned-item-list');

    		if(in_array($data['item']->getID(), $list))
    		{
    			$msg = str_replace('@name', $data['item']->getName(), $this->config->get('msg-on-equipment-change'));
    			$data['player']->sendChat($msg);
    			return false;
    		}
            elseif(in_array($data["item"]->getName(), $list))
            {
                $msg = str_replace('@name', $data['item']->getName(), $this->config->get('msg-on-equipment-change'));
                $data['player']->sendChat($msg);
                return false;
            }
    	}
    }

    public function commands($cmd, $params, $issuer, $alias)
    {
    	if($cmd == 'item')
    	{
            $c = $this->config->getAll();
            $list = $c["banned-item-list"];

    		switch (strtolower(array_shift($params))) 
            {
            
    			case 'ban':
    			    $player = strtolower((string)$args[0]);
    				$id = array_shift($params);
                    if(empty($id) || (is_int($id) && $id <= 0) || $id === NULL)
                    {
                        $output = "Usage: /item ban <id:meta>";
                        return $output;
                    }

    				if(!in_array($id, $list))
    				{
                        if(!is_array($list))
                            $list = array($id);
                        else
                            $list[] = $id;

    					//$msg = str_replace('@name', $id, $this->config->get('msg-on-ban-item'));
						//$this->api->chat->broadcast($msg);
						//return $msg;
    				}
                    else
                    {
                        $output = "[BanItem] Предмет уже запрещен на сервере.";
						return $output;
                    }

                    $c["banned-item-list"] = $list;
                    $this->config->setAll($c);
                    $this->config->save();
					
					$msg = str_replace('@name', $id, $this->config->get('msg-on-ban-item'));
						//$this->api->chat->broadcast($msg);
						return $msg;
						
    			break;
    			
    			case 'unban':
    				$id = array_shift($params);
                    if(empty($id) || (is_int($id) && $id <= 0) || $id === NULL)
                    {
                        $output = "Usage: /item unban <id:meta>";
                        return $output;
                    }

    				if(in_array($id, $list))
    				{
				        $key = array_search($id, $list);
				        unset($list[$key]);

    				}
                    else
                    {
                        $output = "[BanItem] Предмет уже разрешен на сервере.";
						return $output;
                    }

                    $c["banned-item-list"] = $list;
                    $this->config->setAll($c);
                    $this->config->save();
					
					$msg = str_replace('@name', $id, $this->config->get('msg-on-unban-item'));
    					//$this->api->chat->broadcast($msg);
						return $msg;
						
    			break;
    			default:
    			    $output = "BanItem - Управления предметами сервера.\n /item - эта информация.\n /item ban <id:meta> - блокировка предмета.\n /item unban <id:meta> - разблокировка предмета.\nrewrite by tema1d&GameHerobine";
            return $output;
    		}
    }
}
    public function __destruct(){}
}
