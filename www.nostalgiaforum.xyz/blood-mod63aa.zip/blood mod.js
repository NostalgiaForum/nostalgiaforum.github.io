ModPE.setItem(250,"clock_item",0,"day time")
ModPE.setFoodItem(251,"ruby","ruby",2,"heart")
ModPE.setItem(252,"rotten_flesh",0,"piece of a body")
ModPE.setItem(253,"spawn_egg",2,"spawn weak player")
Item.addCraftRecipe(251, 1, 0, [252, 5, 8])
Item.addCraftRecipe(253, 1, 0, [251, 2, 8])
Item.addCraftRecipe(250, 1, 0, [252, 1, 8])
Block.defineBlock(101,"blood","redstone_block",101,101,0)
Block.setDestroyTime(101,0,1)
Block.setShape(101,0,0,0,1,1/120,1)
Block.setRenderLayer(101,1);
function deathHook(attacker, victim)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 2, 252, 5, 0)
Level.setTile(Entity.getX(victim),Entity.getY(victim),Entity.getZ(victim),101)
}
function useItem(x, y, z, itemId, blockId, side)
{
if(itemId==253&&blockId==2)
{
addItemInventory(253,-1)
mob = Level.spawnMob(x,y+1 ,z,11,"mob/char.png")
Entity.setHealth(mob,1)
Entity.setRenderType(mob,3)
Entity.setNameTag(mob, "weak player")
}
{
if(itemId==250)
{
Level.setTime(0)
clientMessage("enjoy the daytime!!!")
}
}
}
