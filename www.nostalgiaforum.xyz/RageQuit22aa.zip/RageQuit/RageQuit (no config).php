<?php

/*
__Pocketmine Plugin__
name=RageQuit
version=0.2.1
author=ZacHack
class=Rage
apiversion=9, 10
*/

class Rage implements Plugin{
		private $api, $config;
		public function __construct(ServerAPI $api, $server = false){
				$this->api = $api;
		}
		
		public function init(){
				$this->api->addHandler("player.quit", array($this, "handle"), 15);
				$this->api->console->register("ragequit", "<reload>", array($this, "reload"));
				$this->api->console->alias("rq", "ragequit");
		}
		
		public function __destruct(){
		
		}
		
		public function handle($data, $event){
				$user = $data->username;
				switch($event){
						case "player.quit";
								$this->api->chat->broadcast("RAGE QUIT!!!!");
								$this->api->chat->broadcast(" ".$user." threw his iphone out the window!");
								break;
				}
		}
}
	