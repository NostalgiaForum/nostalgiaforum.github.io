
var Rx = getPlayerX(); 
var Ry = getPlayerY(); 
var Rz = getPlayerZ(); 
var healtharmor=false;
var firearmor=false;
var waterarmor=false;

function modTick(ticks, itemDamage){

checkArmor();

if(firearmor==true){

  
  if(getTile(Rx,Ry+2,Rz) == 0)
  if(getTile(Rx, Ry+1, Rz) == 0)
  {
  
  setTile(Rx, Ry-1, Rz,1)
Player.setHealth(20);}
}
}
  



function checkArmor()
{ 
if(Player.getArmorSlot(3) == 305&&Player.getArmorSlot(2) == 304&&Player.getArmorSlot(1) == 303&& Player.getArmorSlot(0) == 302 )
 { 
firearmor = true;
 }  
if( Player.getArmorSlot(1)!== 303&&Player.getArmorSlot(0)!== 302&&Player.getArmorSlot(2)!==304&&Player.getArmorSlot(3)!== 305)
 { 
firearmor = false; 
} 
}



function attackHook(attacker, victim) {
  var healFull = "Health";
var redhealFull = "§4Health";
var yellowhealFull = "§eHealth";
var greenhealFull = "§2Health";
  var hp = Entity.getHealth(victim)-1;
 if(hp>7){
Entity.setNameTag(victim, greenhealFull + " " + hp);}
if(hp<4){
Entity.setNameTag(victim, yellowhealFull + " " + hp);}
if(hp<3){
Entity.setNameTag(victim, redhealFull + " " + hp);}
if(firearmor==true){
Entity.setFireTicks(victim,50);
}
else if( firearmor ==false){
Entity.setFireTicks(victim,0);
}
}

