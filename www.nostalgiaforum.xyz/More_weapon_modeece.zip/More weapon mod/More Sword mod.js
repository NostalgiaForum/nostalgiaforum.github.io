var Ydiff=0;
var  randomdamage;
var itemSword=false;
var f=422;
var txt="armor__with_health_cristall.png"
var part = ParticleType.smoke;
//Fire sword,cristall,armor
ModPE.setItem(377,"blaze_powder",0,"Fire Sword");
ModPE.setItem(378,"magma_cream",0,"§6Fire Cristall");
ModPE.setItem(374,"potion_bottle_drinkable", 0,"§dObsidian Cristall");
ModPE.setItem(444,"ender_pearl",0,"Ender Pearl");
ModPE.setItem(368,"ender_eye",0,"§2Repulsive Cristall");
ModPE.setItem(422,"skull_wither",0,"Ripulsive Sword");
ModPE.setItem(432,"skull_steve",0,"Obsidian Dust");
ModPE.setItem(403,"book_enchanted",0,"Reinforced Iron Ingot");
ModPE.setItem(418, "gold_horse_armor", 0, "§4Explosive Cristall");
ModPE.setItem(384,"experience_bottle", 0, "Health Sword");
ModPE.setItem (346,"fishing_rod_uncast",0,"§eHealth Cristall");
 ModPE.setItem(382,"melon_speckled",0,"Explosive Sword");
ModPE.setItem(497,"skull_creeper", 0," §1Water Cristall");
ModPE.setItem(333, "boat", 0, "Water Sword");
ModPE.setItem(394,"potato_poisonous",0,"Dark Sword");
ModPE.langEdit("item.helmetChain.name","Fire Helmet");
ModPE.langEdit("item.chestplateChain.name","Fire Chestplate");
ModPE.langEdit("item.leggingsChain.name","Fire Leggings");
ModPE.langEdit("item.bootsChain.name","Fire Boots");
ModPE.setItem(402,"fireworks_charge",0,"Health Helment");
ModPE.setItem(371,"gold_nugget",0,"Health Chesplate");
ModPE.setItem(396,"carrot_golden",0,"Health Leggings");
ModPE.setItem(376,"spider_eye_fermented",0,"Health Boots");
ModPE.setItem(373,"fireworks_charge_overlay",0,"Water Chesplate");
ModPE.setItem(342,"book_written",0,"Water Helmet");
ModPE.setItem(399,"nether_star",0,"Water Leggings");
ModPE.setItem(421,"name_tag",0,"Water Boots");
Item.addShapedRecipe(342,1, 0 ,["eee","eae","aaa"],["e", 497 ,0]);
Item.addShapedRecipe(373,1, 0 ,["eae","eee","eee"],["e", 497 ,0 ]);
Item.addShapedRecipe(399,1, 0 ,["eee","eae","eae"],["e", 497 ,0 ]);
Item.addShapedRecipe(421,1,0,["aaa","eae","eae"],["e", 497 ,0 ]);
Item.addShapedRecipe(302,1,-30,["eee","eae","aaa"],["e",378,0]);
Item.addShapedRecipe(303,1,-30,["eae","eee","eee"],["e",378,0]);
Item.addShapedRecipe(304,1,-30,["eee","eae","eae"],["e",378,0]);
Item.addShapedRecipe(305,1,-30,["aaa","eae","eae"],["e",378,0]);
Item.addShapedRecipe(402,1,0,["eee","eae","aaa"],["e", 346 ,0]);
Item.addShapedRecipe(371,1,0,["eae","eee","eee"],["e", 346 ,0 ]);
Item.addShapedRecipe(396,1,0,["eee","eae","eae"],["e", 346 ,0 ]);
Item.addShapedRecipe(376,1,0,["aaa","eae","eae"],["e", 346 ,0 ]);
Block.defineBlock(23, "Fire Block", [["still_lava", 0]], 46, false, 0);
Block.setLightLevel(23, 15);

function slot(item,nb) {
var sl= Player.getSelectedSlotId()
if(sl!== -1) {
var sn= Player.getInventorySlotCount(sl)-nb;
var sd= Player.getInventorySlotData(sl);
if(sn >= nb){
Entity.setCarriedItem(getPlayerEnt(),item,sn,sd);
}else if(sn+nb == nb) {
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
}
}
}


Item.setMaxDamage(394,2098);
ModPE.setItem(335, "potion_overlay", 0, "§0Dark Cristall");
Item.addShapedRecipe(394,1,0,[" f " ," f ", " u "],["f",335,0,"u",403,0,]);
Item.addShapedRecipe(335,1,0,["ooo","odo","ooo"],["o",367,0,"d",264,0,]);
Item.addShapedRecipe(333,1,0,[" f " ," f ", " u "],["f",497,0,"u",403,0,]);
Item.addShapedRecipe(497,1,0,["fff","fdf","fff"],["f",325,8,"d",264,0,]);
Item.addShapedRecipe(382,1,0,[" f "," f "," u "],["f",418,0,"u",403,0,]);
Item.addShapedRecipe(418,1,0, ["fff","fdf","fff"] , ["f",46,0,"d", 264,0,]);//Explosive cristall
Item.addShapedRecipe(403,1,0,["cic","ici","cic"],["c", 374,0,"i",265,0,]);
Item.addFurnaceRecipe(318,51,0);
Item.addShapedRecipe(384,1,0,[" f " ," f ", " u "],["f",346,0,"u",403,0,]);
 Item.addShapedRecipe(346,1,0,["fff","fdf","fff"],["f",41,0,"d",264,0,]);//ingridients
Item.addShapedRecipe(422,1,0,[" f "," f "," u "],["f",368,0,"u",403,0,]);
Item.addShapedRecipe(368,1,0, ["fff","fdf","fff"] , ["f",444,0,"d", 264,0,]);//repulsive cristall
Item.addShapedRecipe(378,1,0,["fff","fdf","fff"],["f",51,0,"d", 264,0,]);
Item.addShapedRecipe(374,1,0,["fff","fdf","fff"],["f",432,0,"d", 264,0,]);
Item.addShapedRecipe(432,1,0,["aoa","oao","aoa"],["o",49,0,]);
Item.addShapedRecipe(377,1,0,[" a "," a "," s"],["s",403,0,"a",378,0,]);

function attackHook(attacker,victim)
{
var firedamage =Math.floor((Math.random()*2))
var damage=Math.floor(( Math.random()*4)-firedamage);
var xx=Entity.getX(victim);
var yy=Entity.getY(victim);
var zz=Entity.getZ(victim);
{
if(getCarriedItem()==377)
{
preventDefault();
Entity.setFireTicks(victim,1000);
toolUse(2000,377);
Entity.setHealth(victim,damage+1.7);
setTile(Entity.getX(victim), Entity.getY(victim),Entity.getZ(victim), 51);
}
else if(getCarriedItem() ==  f && getYaw(Player.getEntity) < 0)
	{
toolUse(1998,f)
Entity.setHealth(victim,damage+1.7);
 var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
   
	}
	else if(getCarriedItem() == f && getYaw(Player.getEntity) > 0 && getYaw(Player.getEntity) < 360)
	{
		var temp = getYaw(Player.getEntity)+90;
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.9);
		setVelZ(victim, z*4);
toolUse(1998,f)
Entity.setHealth(victim,damage+1.7);
	}
	else if(getCarriedItem() == f && getYaw(Player.getEntity) >= 360)
	{
		var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp>=360; i++)
		{
			temp -= 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
   toolUse(1998,f)
Entity.setHealth(victim,damage+1.7);
	}
if(getCarriedItem() == f && getYaw(Player.getEntity) < 0)
	{
		var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
toolUse(1998,f)
Entity.setHealth(victim,damage+2);
}   
else if (getCarriedItem()==382){
preventDefault();
toolUse(3000,382);
Entity.setHealth(victim,damage+1.7);
setVelY(victim,1);
Level.explode( Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1);
}
if (getCarriedItem()==384)
{
part = ParticleType.heart;
Level.addParticle(part.toString(), Entity.getX(victim), Entity.getY(victim)+2, Entity.getZ(victim) ,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)-1, Entity.getY(victim)+2, Entity.getZ(victim) ,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)+1, Entity.getY(victim)+2, Entity.getZ(victim) ,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim), Entity.getY(victim)+2, Entity.getZ(victim)-1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)-1, Entity.getY(victim)+2, Entity.getZ(victim)-1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)+1, Entity.getY(victim)+2, Entity.getZ(victim)-1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim), Entity.getY(victim)+2, Entity.getZ(victim)+1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)-1, Entity.getY(victim)+2, Entity.getZ(victim)+1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)+1, Entity.getY(victim)+2, Entity.getZ(victim)+1,0,0,0,2.5);
Entity.setHealth(victim, Entity.getHealth(victim)+2.3);
toolUse(400,384);
}
else  if(getCarriedItem()==333){
preventDefault();
toolUse(1023,333);
Entity.setHealth(victim,2);
setTile (xx-2,yy,zz,30);
setTile (xx-1,yy,zz,30);
setTile (xx,yy,zz,30);
setTile (xx,yy,zz-1,30);
setTile (xx+1,yy,zz-1,30);
setTile (xx+2,yy,zz-1,30);
setTile (xx-2,yy,zz-2,30);
setTile (xx-1,yy,zz-2,30);
setTile (xx,yy,zz-2,30);
setTile (xx+1,yy,zz-1,30);
setTile (xx+2,yy,zz-1,30);
setTile (xx+1,yy,zz-1,30);
setTile (xx+2,yy,zz-2,30);
setTile (xx-2,yy,zz-1,30);
setTile (xx-1,yy,zz-1,30);
setTile (xx,yy,zz-1,30);
setTile (xx+1,yy,zz-1,30);
setTile (xx+2,yy,zz-1,30);

setTile(xx+1, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz-2, 9);
setTile(xx+1, yy-1, zz-2, 9);
setTile(xx-1, yy-1, zz-2, 9);
setTile(xx-2, yy-1, zz-1, 9);
setTile(xx-2, yy-1, zz, 9);
setTile(xx+1, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz-2, 9);
setTile(xx+1, yy-1, zz-2, 9);
setTile(xx-1, yy-1, zz-2, 9);
setTile(xx-2, yy-1, zz-1, 9);
setTile(xx-2, yy-1, zz, 9);
setTile(xx+1, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz+2, 9);
setTile(xx, yy+2, zz+2, 9);
setTile(xx-1, yy+1, zz-2, 9);
setTile(xx+1, yy+2, zz+2, 9);
setTile(xx+1, yy+3, zz-1, 9);
setTile(xx, yy+3, zz-1, 9);
setTile(xx+1, yy+3, zz, 9);
setTile(xx, yy+3, zz, 9);
setTile(xx+1, yy+3, zz+1, 9);
setTile(xx+1, yy+3, zz+1, 9);
setTile(xx, yy+3, zz+1, 9);
setTile(xx+1, yy+1, zz+2, 9);
setTile(xx+2, yy+2, zz-1, 9);
setTile(xx+2, yy+2, zz,9);
setTile(xx+2, yy+2, zz+1, 9);
setTile(xx-1, yy+2, zz-1, 9);
setTile(xx-1, yy+2, zz, 9);
setTile(xx-1, yy+2, zz+1, 9);
setTile(xx+3, yy+1, zz, 9);
setTile(xx+3, yy+1, zz+1, 9);
setTile(xx+1, yy+2, zz-2, 9);
setTile(xx, yy+2, zz-2, 9);
setTile(xx, yy+1, zz-2, 9);
setTile(xx-2, yy+1, zz+1, 9);
setTile(xx-1, yy+1, zz-2, 9);
setTile(xx, yy+2, zz+1, 9);
setTile(xx+3, yy+1, zz-1, 9);
setTile(xx-1, yy+1, zz+2, 9);
setTile(xx, yy+1, zz+2, 9);
setVelY(victim,-6);
}
if (getCarriedItem()==394)
{
part = ParticleType.crit;
Level.addParticle(part.toString(), Entity.getX(victim), Entity.getY(victim)+2, Entity.getZ(victim) ,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)-1, Entity.getY(victim)+2, Entity.getZ(victim) ,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)+1, Entity.getY(victim)+2, Entity.getZ(victim) ,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim), Entity.getY(victim)+2, Entity.getZ(victim)-1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)-1, Entity.getY(victim)+2, Entity.getZ(victim)-1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)+1, Entity.getY(victim)+2, Entity.getZ(victim)-1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim), Entity.getY(victim)+2, Entity.getZ(victim)+1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)-1, Entity.getY(victim)+2, Entity.getZ(victim)+1,0,0,0,2.5);
Level.addParticle(part.toString(), Entity.getX(victim)+1, Entity.getY(victim)+2, Entity.getZ(victim)+1,0,0,0,2.5);
Entity.setHealth(victim, 2);
toolUse(2004,394);
}
if(firearmor==true){
Entity.setFireTicks(victim,50);
}
if( firearmor ==false){
Entity.setFireTicks(victim,0);
}
}
if(waterarmor==true){
preventDefault();
Entity.setHealth(victim,1);
setTile (xx-2,yy,zz,30);
setTile (xx-1,yy,zz,30);
setTile (xx,yy,zz,30);
setTile (xx,yy,zz-1,30);
setTile (xx+1,yy,zz-1,30);
setTile (xx+2,yy,zz-1,30);
setTile (xx-2,yy,zz-2,30);
setTile (xx-1,yy,zz-2,30);
setTile (xx,yy,zz-2,30);
setTile (xx+1,yy,zz-1,30);
setTile (xx+2,yy,zz-1,30);
setTile (xx+1,yy,zz-1,30);
setTile (xx+2,yy,zz-2,30);
setTile (xx-2,yy,zz-1,30);
setTile (xx-1,yy,zz-1,30);
setTile (xx,yy,zz-1,30);
setTile (xx+1,yy,zz-1,30);
setTile (xx+2,yy,zz-1,30);

setTile(xx+1, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz-2, 9);
setTile(xx+1, yy-1, zz-2, 9);
setTile(xx-1, yy-1, zz-2, 9);
setTile(xx-2, yy-1, zz-1, 9);
setTile(xx-2, yy-1, zz, 9);
setTile(xx+1, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz-2, 9);
setTile(xx+1, yy-1, zz-2, 9);
setTile(xx-1, yy-1, zz-2, 9);
setTile(xx-2, yy-1, zz-1, 9);
setTile(xx-2, yy-1, zz, 9);
setTile(xx+1, yy-1, zz+2, 9);
setTile(xx+2, yy-1, zz+2, 9);
setTile(xx, yy+2, zz+2, 9);
setTile(xx-1, yy+1, zz-2, 9);
setTile(xx+1, yy+2, zz+2, 9);
setTile(xx+1, yy+3, zz-1, 9);
setTile(xx, yy+3, zz-1, 9);
setTile(xx+1, yy+3, zz, 9);
setTile(xx, yy+3, zz, 9);
setTile(xx+1, yy+3, zz+1, 9);
setTile(xx+1, yy+3, zz+1, 9);
setTile(xx, yy+3, zz+1, 9);
setTile(xx+1, yy+1, zz+2, 9);
setTile(xx+2, yy+2, zz-1, 9);
setTile(xx+2, yy+2, zz,9);
setTile(xx+2, yy+2, zz+1, 9);
setTile(xx-1, yy+2, zz-1, 9);
setTile(xx-1, yy+2, zz, 9);
setTile(xx-1, yy+2, zz+1, 9);
setTile(xx+3, yy+1, zz, 9);
setTile(xx+3, yy+1, zz+1, 9);
setTile(xx+1, yy+2, zz-2, 9);
setTile(xx, yy+2, zz-2, 9);
setTile(xx, yy+1, zz-2, 9);
setTile(xx-2, yy+1, zz+1, 9);
setTile(xx-1, yy+1, zz-2, 9);
setTile(xx, yy+2, zz+1, 9);
setTile(xx+3, yy+1, zz-1, 9);
setTile(xx-1, yy+1, zz+2, 9);
setTile(xx, yy+1, zz+2, 9);
setVelY(victim,-6);
}
}


function useItem(x,y,z,itemId)
{
if(itemId==402)
{
addItemInventory(402,-1);
Player.setArmorSlot(0, 402, 0);
slot(402,1);
Entity.setMobSkin(getPlayerEnt(),txt);
}
else if(itemId==371)
{
addItemInventory(371,-1);
Player.setArmorSlot(1, 371, 0);
Entity.setMobSkin(getPlayerEnt(),txt);
slot(371,1);
}
if(itemId==396)
{
addItemInventory(396,-1);
Player.setArmorSlot(2, 396, 0);
slot(396,1);
Entity.setMobSkin(getPlayerEnt(),txt);
}
else if(itemId==376)
{
addItemInventory(376,-1);
Player.setArmorSlot(3, 376, 0);
Entity.setMobSkin(getPlayerEnt(),txt);
slot(376,1);
 }
else if(itemId==342)
{
addItemInventory(342,-1);
Player.setArmorSlot(0, 342, 0);
slot(342,1);
Entity.setMobSkin(getPlayerEnt(),"water_armor.png");
}
else if(itemId==373)
{
addItemInventory(373,-1);
Player.setArmorSlot(1, 373, 0);
Entity.setMobSkin(getPlayerEnt(),"water_armor.png");
slot(373,1);
}
if(itemId==399)
{
addItemInventory(399,-1);
Player.setArmorSlot(2, 399, 0);
slot(399,1);
Entity.setMobSkin(getPlayerEnt(),"water_armor.png");
}
else if(itemId==421)
{
addItemInventory( 421 ,-1);
Player.setArmorSlot(3, 421 , 0);
Entity.setMobSkin(getPlayerEnt(),"water_armor.png");
slot( 421 ,1); 
}
}




ModPE.setItem(367,"rotten_flesh", 0, "Dark Particle");
ModPE.setFoodItem(322,"apple_golden",0,20,"Golden Apple");
Item.addShapedRecipe(322,1,0,["ccc","cpc","ccc"],["c",266,0,"p",260,0]);
Item.setMaxDamage(f,3999);
Item.setMaxDamage(377,2090);
Item.setMaxDamage(382,1000);
Item.setMaxDamage(384,520);
Item.setMaxDamage(333,1020);

function toolUse(maxDamage,id)
{
var pcid=Player.getCarriedItemData();
if(pcid!==maxDamage)
{
Entity.setCarriedItem(getPlayerEnt(),id,1,pcid+1);
}
else if(pcid==maxDamage) 
{
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
addItemInventory(id,-1);
}
}

function checkArmor()
{ 
if(Player.getArmorSlot(3) == 376&& Player.getArmorSlot(2) == 396&&Player.getArmorSlot(1) == 371&& Player.getArmorSlot(0) == 402 ) 
{ 
Entity.setMobSkin(getPlayerEnt(),txt);
healtharmor=true;
}  
if( Player.getArmorSlot(1)!== 371&&Player.getArmorSlot(0)!== 402&&Player.getArmorSlot(2)!==396&&Player.getArmorSlot(3)!== 375 )
 { 
Entity.setMobSkin(getPlayerEnt(),"mob/char.png");
healtharmor=false;
}
if(Player.getArmorSlot(3) == 421 && Player.getArmorSlot(2) == 399 &&Player.getArmorSlot(1) == 373 && Player.getArmorSlot(0) == 342 ) 
{ 
Entity.setMobSkin(getPlayerEnt(),"water_armor.png");
waterarmor=true;
}  
if( Player.getArmorSlot(1)!== 373 &&Player.getArmorSlot(0)!== 342 &&Player.getArmorSlot(2)!== 399 &&Player.getArmorSlot(3)!== 421 ) 
{ 
Entity.setMobSkin(getPlayerEnt(),"mob/char.png");
waterarmor =false;
}
}

ModPE.setItem(342,"book_written",0,"Water Helmet"); ModPE.setItem(373,"fireworks_charge_overlay",0,"Water Chesplate");
ModPE.setItem(399,"nether_star",0,"Water Leggings");
ModPE.setItem(421,"name_tag",0,"Water Boots");

ModPE.setItem(402,"fireworks_charge",0,"Health Helment");
ModPE.setItem(371,"gold_nugget",0,"Health Chesplate");
ModPE.setItem(396,"carrot_golden",0,"Health Leggings");
ModPE.setItem(376,"spider_eye_fermented",0,"Health Boots");




var Rx = getPlayerX(); 
var Ry = getPlayerY(); 
var Rz = getPlayerZ(); 
var healtharmor=false;
var firearmor=false;
var waterarmor=false;
  
function modTick(ticks, itemDamage){

checkArmor();

if(healtharmor==true){
Entity.setMobSkin(getPlayerEnt(),txt);
part = ParticleType.heart;
Level.addParticle(part.toString(),getPlayerX(),getPlayerY()+2+Ydiff,getPlayerZ()-1.5,0,0,0,2);
Level.addParticle(part.toString(),getPlayerX(),getPlayerY()+2+Ydiff,getPlayerZ()+1.3,0,0,0,2);
Level.addParticle(part.toString(),getPlayerX()-1.2,getPlayerY()+2+Ydiff,getPlayerZ(),0,0,0,2);
Level.addParticle(part.toString(),getPlayerX()+0.3,getPlayerY()+2+Ydiff,getPlayerZ(),0,0,0,2);
Level.addParticle(part.toString(),getPlayerX(),getPlayerY()+2+Ydiff,getPlayerZ()-0.47,0,0,0,2);
Level.addParticle(part.toString(),getPlayerX(),getPlayerY()+2+Ydiff,getPlayerZ()+0.5,0,0,0,2);
Level.addParticle(part.toString(),getPlayerX()-0.2,getPlayerY()+2+Ydiff,getPlayerZ(),0,0,0,2);
Level.addParticle(part.toString(),getPlayerX()+1.2,getPlayerY()+2+Ydiff,getPlayerZ(),0,0,0,2);
Player.setHealth(50);
}
else if( waterarmor==true){
if(getTile(Rx, Ry+1, Rz) == 0)
if(getTile(Rx, Ry+2, Rz) == 0)
{
 setTile(Rx, Ry-2, Rz,9)
 Player.setHealth(20);}
}
}

function deathHook (attacker, victim) 
{
if (Entity.getEntityTypeId(victim) == 38) //паук
{
preventDefault();
var ender= Math.floor((Math.random()*50)+1);//задаём числа от 1 до 10
 if( ender ==1)//
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 444, 1, 0);
}
if( ender ==4)//
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 367, 1, 0);
}
}
}


