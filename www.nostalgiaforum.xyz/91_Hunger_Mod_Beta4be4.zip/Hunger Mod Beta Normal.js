var hunger20 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger20.png");
var hunger19 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger19.png");
var hunger18 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger18.png");
var hunger17 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger17.png");
var hunger16 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger16.png");
var hunger15 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger15.png");
var hunger14 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger14.png");
var hunger13 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger13.png");
var hunger12 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger12.png");
var hunger11 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger11.png");
var hunger10 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger10.png");
var hunger9 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger9.png");
var hunger8 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger8.png");
var hunger7 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger7.png");
var hunger6 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger6.png");
var hunger5 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger5.png");
var hunger4 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger4.png");
var hunger3 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger3.png");
var hunger2 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger2.png");
var hunger1 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger1.png");
var hunger0 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/hunger0.png");
var sprint = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/Download/Images/sprint.png");

var hunger20img = new android.graphics.drawable.BitmapDrawable(hunger20);
var hunger19img = new android.graphics.drawable.BitmapDrawable(hunger19);
var hunger18img = new android.graphics.drawable.BitmapDrawable(hunger18);
var hunger17img = new android.graphics.drawable.BitmapDrawable(hunger17);
var hunger16img = new android.graphics.drawable.BitmapDrawable(hunger16);
var hunger15img = new android.graphics.drawable.BitmapDrawable(hunger15);
var hunger14img = new android.graphics.drawable.BitmapDrawable(hunger14);
var hunger13img = new android.graphics.drawable.BitmapDrawable(hunger13);
var hunger12img = new android.graphics.drawable.BitmapDrawable(hunger12);
var hunger11img = new android.graphics.drawable.BitmapDrawable(hunger11);
var hunger10img = new android.graphics.drawable.BitmapDrawable(hunger10);
var hunger9img = new android.graphics.drawable.BitmapDrawable(hunger9);
var hunger8img = new android.graphics.drawable.BitmapDrawable(hunger8);
var hunger7img = new android.graphics.drawable.BitmapDrawable(hunger7);
var hunger6img = new android.graphics.drawable.BitmapDrawable(hunger6);
var hunger5img = new android.graphics.drawable.BitmapDrawable(hunger5);
var hunger4img = new android.graphics.drawable.BitmapDrawable(hunger4);
var hunger3img = new android.graphics.drawable.BitmapDrawable(hunger3);
var hunger2img = new android.graphics.drawable.BitmapDrawable(hunger2);
var hunger1img = new android.graphics.drawable.BitmapDrawable(hunger1);
var hunger0img = new android.graphics.drawable.BitmapDrawable(hunger0);
var sprint = new android.graphics.drawable.BitmapDrawable(sprint);

var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); 

var run = false;
s=1;
Xdiff=0;
Zdiff=0;
Xpos=0;
Zpos=0;
var ticks=400;
var ticker=100;
var healer=80;
var hunger = 21;
var hungry = false;
var active = 0;
var heldItemAmount = 0;
var changer;
var gmchecker = Level.getGameMode();

function newLevel()
{
if(gmchecker=0)
{
changer = 1;
}

ctx.runOnUiThread(new java.lang.Runnable(){
 
run: function(){
 
try{

GUI = new android.widget.PopupWindow();
var layout = new android.widget.LinearLayout(ctx);
layout.setOrientation(android.widget.LinearLayout.VERTICAL);
GUI.setContentView(layout);
GUI.setWidth(60);
GUI.setHeight(60);
var btn = new android.widget.Button(ctx);
layout.addView(btn);
btn.setBackgroundDrawable(sprint);
btn.setOnClickListener(new android.view.View.OnClickListener({ 
onClick: function(viewarg)
{
if(run==false)
{
run = true;
}
else if(run==true)
{
run = false;
}
}
}));
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.RIGHT, 10, 10);
}
catch(e)
{
print("Sprinting failed: " + e);
}
}
})
}

function modTick()
{

if(run==true&&hunger > 6)
{
if(s==1)
{
Xpos=getPlayerX();
Zpos=getPlayerZ();
s = s + 1;
}
else if(s==3)
{
s=1;
Xdiff=getPlayerX()-Xpos;
Zdiff=getPlayerZ()-Zpos;
setVelX(getPlayerEnt(),Xdiff);
setVelZ(getPlayerEnt(),Zdiff);
Xdiff=0;
Zdiff=0;
}
if(s!=1)
{
s = s + 1;
}
}

if(changer==1)
{


changer = 0;
ctx.runOnUiThread(new java.lang.Runnable(){
 
run: function(){
 
try{
GUIHunger = new android.widget.PopupWindow();
var layoutHunger = new android.widget.LinearLayout(ctx);
layoutHunger.setOrientation(android.widget.LinearLayout.VERTICAL);
GUIHunger.setContentView(layoutHunger);
GUIHunger.setWidth(450);
GUIHunger.setHeight(45);
var btnHunger = new android.widget.Button(ctx);
layoutHunger.addView(btnHunger);
if(hunger==21)
{
btnHunger.setBackgroundDrawable(hunger20img);
}
else if(hunger==20)
{
btnHunger.setBackgroundDrawable(hunger20img);
}
else if(hunger==19)
{
btnHunger.setBackgroundDrawable(hunger19img);
}
else if(hunger==18)
{
btnHunger.setBackgroundDrawable(hunger18img);
}
else if(hunger==17)
{
btnHunger.setBackgroundDrawable(hunger17img);
}
else if(hunger==16)
{
btnHunger.setBackgroundDrawable(hunger16img);
}
else if(hunger==15)
{
btnHunger.setBackgroundDrawable(hunger15img);
}
else if(hunger==14)
{
btnHunger.setBackgroundDrawable(hunger14img);
}
else if(hunger==13)
{
btnHunger.setBackgroundDrawable(hunger13img);
}
else if(hunger==12)
{
btnHunger.setBackgroundDrawable(hunger12img);
}
else if(hunger==11)
{
btnHunger.setBackgroundDrawable(hunger11img);
}
else if(hunger==10)
{
btnHunger.setBackgroundDrawable(hunger10img);
}
else if(hunger==9)
{
btnHunger.setBackgroundDrawable(hunger9img);
}
else if(hunger==8)
{
btnHunger.setBackgroundDrawable(hunger8img);
}
else if(hunger==7)
{
btnHunger.setBackgroundDrawable(hunger7img);
}
else if(hunger==6)
{
btnHunger.setBackgroundDrawable(hunger6img);
}
else if(hunger==5)
{
btnHunger.setBackgroundDrawable(hunger5img);
}
else if(hunger==4)
{
btnHunger.setBackgroundDrawable(hunger4img);
}
else if(hunger==3)
{
btnHunger.setBackgroundDrawable(hunger3img);
}
else if(hunger==2)
{
btnHunger.setBackgroundDrawable(hunger2img);
}
else if(hunger==1)
{
btnHunger.setBackgroundDrawable(hunger1img);
}
else if(hunger==0)
{
btnHunger.setBackgroundDrawable(hunger0img);
}
btnHunger.setText("\n");
GUIHunger.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 35, 70);
}
catch(e)
{
print("Check the Instructions, you've made something wrong!");
}
}
})
}

if(Player.getCarriedItem() == 297) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-5);
hunger = hunger + 5;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 260) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-4);
hunger = hunger + 4;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 319) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-3);
hunger = hunger + 3;
active = 0;
}
}
}


else if(Player.getCarriedItem() == 320) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-8);
hunger = hunger + 8;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 357) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-2);
hunger = hunger + 2;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 360) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-2);
hunger = hunger + 2;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 363) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-3);
hunger = hunger + 3;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 364) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-8);
hunger = hunger + 8;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 365) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-2);
hunger = hunger + 2;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 366) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-6);
hunger = hunger + 6;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 391) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-4);
hunger = hunger + 4;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 392) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-1);
hunger = hunger + 1;
active = 0;
}
}
}

else if(Player.getCarriedItem() == 457) 
{
      if(active == 0) 
	  {
         heldItemAmount = Player.getCarriedItemCount();
         active = 1;
         return;
} if(active == 1) 
{
if(heldItemAmount - 1 == Player.getCarriedItemCount()) 
{
changer = 1;
Player.setHealth(Entity.getHealth(getPlayerEnt())-1);
hunger = hunger + 1;
active = 0;
}
}
}

if(hunger==21)
{
ticks--;
if(ticks==0)
{
hunger=20;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger>=22)
{
hunger=21;
}
else if(hunger==20)
{
ticks--;
if(ticks==0)
{
hunger=19;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==19)
{
ticks--;
if(ticks==0)
{
hunger=18;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==18)
{
ticks--;
if(ticks==0)
{
hunger=17;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==17)
{
ticks--;
if(ticks==0)
{
hunger=16;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==16)
{
ticks--;
if(ticks==0)
{
hunger=15;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==15)
{
ticks--;
if(ticks==0)
{
hunger=14;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==14)
{
ticks--;
if(ticks==0)
{
hunger=13;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==13)
{
ticks--;
if(ticks==0)
{
hunger=12;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==12)
{
ticks--;
if(ticks==0)
{
hunger=11;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==11)
{
ticks--;
if(ticks==0)
{
hunger=10;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==10)
{
ticks--;
if(ticks==0)
{
hunger=9;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==9)
{
ticks--;
if(ticks==0)
{
hunger=8;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==8)
{
ticks--;
if(ticks==0)
{
hunger=7;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==7)
{
ticks--;
if(ticks==0)
{
hunger=6;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==6)
{
ticks--;
if(ticks==0)
{
hunger=5;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==5)
{
ticks--;
if(ticks==0)
{
hunger=4;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==4)
{
ticks--;
if(ticks==0)
{
hunger=3;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==3)
{
ticks--;
if(ticks==0)
{
hunger=2;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==2)
{
ticks--;
if(ticks==0)
{
hunger=1;
changer = 1;
ticks=400;
hungry = false;
}
}
else if(hunger==1)
{
ticks--;
if(ticks==0)
{
hunger=0;
changer = 1;
ticks=400;
hungry = false;
}
}

else if(hunger==0)
{
ticks--;
if(ticks==0)
{
hungry = true;
changer = 1;
}
}
if(hungry==true)
{
ticker--;
if(ticker==0)
{
Entity.setHealth(getPlayerEnt(), Entity.getHealth(getPlayerEnt()-1));
ticker=100;
}
}
}

function leaveGame()
{
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); 
ctx.runOnUiThread(new java.lang.Runnable({ 
run: function(){ 
if(GUIHunger != null){ 
GUIHunger.dismiss();
GUIHunger = null;
}
}})); 
}
