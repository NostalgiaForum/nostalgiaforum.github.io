/*Potions mod v2.1*/

var slowness=false;
var swiftness=false;
var jumping = false;
var Xpos=0;
var Zpos=0;
var Ypos=0;
var s=1; 
var Xdiff=0;
var Zdiff=0;
var Ydiff=0;
//Items
ModPE.setFoodItem(23,"experience_bottle",0,6,"Potion of instant healing");
ModPE.setFoodItem(52,"experience_bottle",0,12,"Potion of instant healing II");
ModPE.setItem(55,"experience_bottle",0,"Night vision potion");
ModPE.setItem(69,"experience_bottle",0,"Potion of swiftness");
ModPE.setItem(70,"experience_bottle",0,"Potion of slowness");
ModPE.setFoodItem(25,"experience_bottle",0,-10,"Poison");
ModPE.setItem(28,"potion_bottle_empty",0,"Glass bottle");
ModPE.setItem(29,"nether_wart",0,"Nether Wart");
ModPE.setFoodItem(33,"experience_bottle",0,0,"Awkward potion ");
ModPE.setFoodItem(34,"rotten_flesh",0,-2,"Rotten flesh");
ModPE.setFoodItem(36,"spider_eye",0,-12,"Spider eye");
//Craft recipes
Item.addCraftRecipe(28,1,0,[20,3,0]);
Item.setCategory(28,4,0);
Item.addCraftRecipe(33,1,0,[29,1,0,325,1,8,28,1,0]);
Item.setCategory(33,4,0);
Item.addCraftRecipe(23,1,0,[33,1,0,360,1,0]);
Item.setCategory(23,4,0);
Item.addCraftRecipe(25,1,0,[36,1,0,33,1,0]);
Item.setCategory(25,4,0);
Item.addCraftRecipe(29,1,0,[87,1,0,295,1,0]);
Item.setCategory(29,4,0);
Item.addCraftRecipe(52,1,0,[348,1,0,23,1,0]);
Item.setCategory(52,4,0);
Item.addCraftRecipe(69,1,0,[33,1,0,353,1,0]);
Item.setCategory(69,4,0);

function deathHook(m, v)
{
Math.floor ((Math.random() * 10) + 1);
if(Entity.getEntityTypeId(v)== 32)
{
Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 34 , 1, 0);
}
Math.floor ((Math.random() * 10) + 1);
if(Entity.getEntityTypeId(v)== 35)
{
Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 36, 1, 0);
}
}


function useItem(x, y, z, itemId, blockId, side)
{
if (itemId==69)
{
swiftness=true;
addItemInventory(69,-1,0);
}

}

function attackHook(attacker, victim)
{

}

function modTick()
{
if(swiftness)
{
if(s==1)
      {
			   Xpos=getPlayerX();
        Zpos=getPlayerZ();
        s = s + 1;
      }
      else if(s==3)
      {
        s=1;
        Xdiff=getPlayerX()-Xpos;
        Zdiff=getPlayerZ()-Zpos;
        setVelX(getPlayerEnt(),Xdiff);
        setVelZ(getPlayerEnt(),Zdiff);
        Xdiff=0;
        Zdiff=0;
      }
  if(s!=1)
  {
  s = s + 1;
  }
}else if(!swiftness){

return null;

}

if(Entity.getVelY(Player.getEntity()) > 0 && !jumping){

Entity.setVelY(Player.getEntity(), 0.5);
jumping = true;

}

if(Level.getTile(Player.getX(), Player.getY() - 2, Player.getZ()) != 0 && jumping){

jumping = false;

}
if(Entity.getVelX()>=0.01)
{
setVelX(1);
setVelX(0)
}

}

function procCmd(command)
{
var cmd = command.split(" ");

}

function newLevel()
{
//New level
clientMessage("Potions mod made by The_PE_gamer. Have fun!!!!!!!!!");

}

function leaveGame()
{

}

