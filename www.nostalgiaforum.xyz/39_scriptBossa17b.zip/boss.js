//v.2.2
//by Fred (Илья Ш.)

var steve = 0;
var fast = 0;
var itemId;
var blockId;
var ZogSpawner = 476;

ModPE.overrideTexture("images/mob/Zog.png", "http://minecraft-pe.clan.su/Zog.png")

ModPE.setItem(476,"blaze_rod",0,"Zog Spawner");
ModPE.setItem(478,"ruby",0,"Kristal");
ModPE.setFoodItem(481,"rotten_flesh", 2, 2, "Rotten flesh");
ModPE.setItem (480,"slimeball",0,"moss");

ModPE.addCraftRecipe(476, 1, 13, [280,0,266,0,266,0,266,0,266,0,266,0, 266,0,266,0,266,0]);

function useItem(x,y,z,i,b,s)
{ 
if(i==ZogSpawner){
 if(b==49 && getTile(x,y-1,z)==48 && getTile(x,y-2,z)==155 &&
getTile(x-1,y-2,z)==48 && getTile(x+1,y-2,z)==48 && 
getTile(x,y-2,z+1)==48 &&
getTile(x,y-2,z-1)==48 &&
getTile(x-1,y-2,z-1)==38 &&
getTile(x-1,y-2,z+1)==38 &&
getTile(x+1,y-2,z-1)==38 &&
getTile(x+1,y-2,z+1)==38){
var stve = Level.spawnMob(x, y - 2, z, 34, "mob/Zog.png");
Entity.setRenderType(stve, 3);
Entity.setHealth(stve,1000);
explode(x,y,z,1,0)
steve = 1;
clientMessage("<Zog> Я появился ! Ха, ты мне больше не нужен, Бугагагаааааааа !!!");
Level.destroyBlock (x,y,z);
Level.destroyBlock (x,y-1,z);
Level.destroyBlock (x,y-2,z);
Level.destroyBlock (x-1,y-2,z);
Level.destroyBlock (x+1,y-2,z);
Level.destroyBlock (x,y-2,z+1);
Level.destroyBlock (x,y-2,z-1);
Level.destroyBlock (x-1,y-2,z-1);
Level.destroyBlock (x-1,y-2,z+1);
Level.destroyBlock (x+1,y-2,z-1);
Level.destroyBlock (x+1,y-2,z+1);
Player.addItemInventory(476,-1);
}
}
if (i == 480 && b == 4)
{
Level.destroyBlock (x,y,z);
setTile(x,y,z,48);
Player.addItemInventory(480,-1);
}
}

function destroyBlock(x, y, z, side)
{ 
itemId=Player.getCarriedItem();
  blockId=getTile (x, y, z);
{
  if(itemId == 359)
{
if(blockId == 2)
{
Level.destroyBlock (x,y,z,fast);
Level.dropItem (x, y, z, 1, 480, 1, 0);
Level.dropItem (x, y, z, 1, 3, 1, 0);
}
}
}
}

function attackHook(attacker,victim)
{
if(Entity.getEntityTypeId(victim)==34&&steve==1)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
}
}

function newLevel ()
{
clientMessage ("boss v2.2");
}

function deathHook(attacker,victim)
{
if(Entity.getEntityTypeId(victim)==34&&steve==1)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 264, 71, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 508, 2, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 17, 34, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 14, 16, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 41, 2, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 46, 11, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 51, 7, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 246, 19, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 286, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 303, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 330, 2, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 347, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 352, 31, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 510, 27, 0);
steve = 0;
}
}