var enabled = true; 
var itemId; var blockId; 
var damage; 
var logdata; 
function newLevel() { 
if (enabled == true) { } 
else if (enabled == false) { } } 
function destroyBlock(x, y, z, side) { 
if (enabled == true) { 
itemId=Player.getCarriedItem(); blockId=getTile (x, y, z); 
if(itemId == 271 || itemId == 275 || itemId == 279 || itemId == 286 || itemId == 258) { if(blockId == 17) { logdata=Level.getData(x, y, z); 
Level.destroyBlock(x,y,z); Level.dropItem(x,y,z,1,17,1,logdata); 
for (var a = 1; a < 128; a++) { 
if(getTile (x, y + a, z) == 17) { logdata=Level.getData(x, y+a, z); 
Level.destroyBlock(x,y+a,z); Level.dropItem(x,y+a,z,1,17,1,logdata); } else { break; } } preventDefault(); } } } } function procCmd(cmd) { var Data = cmd.split(" "); if (Data[0]=="TC") { if (Data[1]=="enable") { enabled = true; } else if (Data[1]=="disable") { enabled = false; } } } //Enter залип...(