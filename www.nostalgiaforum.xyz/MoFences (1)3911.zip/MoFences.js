//More Fences by LucasMCPE_br
function newLevel()
{
Block.defineBlock(186, "Red Mushroom Fence",[
["mushroom_block_skin_red",0], 
["mushroom_block_skin_red",0],
["mushroom_block_skin_red",0], 
["mushroom_block_skin_red",0],   
["mushroom_block_skin_red",0], 
["mushroom_block_skin_red",0]],0,0,11);
Block.setShape(186,0,0,0,1, 1,1);  
Block.setDestroyTime(186,0.5);

Block.defineBlock(187, "Diamond Fence",[
["diamond_block",0], 
["diamond_block",0],
["diamond_block",0], 
["diamond_block",0],   
["diamond_block",0], 
["diamond_block",0]],0,0,11);
Block.setShape(187,0,0,0,1, 1,1);  
Block.setDestroyTime(187,0.5);

Block.defineBlock(188, "Gold Fence",[
["gold_block",0], 
["gold_block",0],
["gold_block",0], 
["gold_block",0],   
["gold_block",0], 
["gold_block",0]],0,0,11);
Block.setShape(188,0,0,0,1, 1,1);  
Block.setDestroyTime(188,0.5);

Block.defineBlock(189, "Iron Fence",[
["iron_block",0], 
["iron_block",0],
["iron_block",0], 
["iron_block",0],   
["iron_block",0], 
["iron_block",0]],0,0,11);
Block.setShape(189,0,0,0,1, 1,1);  
Block.setDestroyTime(189,0.5);

Block.defineBlock(190, "Redstone Fence",[
["redstone_block",0], 
["redstone_block",0],
["redstone_block",0], 
["redstone_block",0],   
["redstone_block",0], 
["redstone_block",0]],0,0,11);
Block.setShape(190,0,0,0,1, 1,1);  
Block.setDestroyTime(190,0.5);

Block.defineBlock(191, "Emerald Fence",[
["emerald_block",0], 
["emerald_block",0],
["emerald_block",0], 
["emerald_block",0],   
["emerald_block",0], 
["emerald_block",0]],0,0,11);
Block.setShape(191,0,0,0,1, 1,1);  
Block.setDestroyTime(191,1);

Block.defineBlock(192, "Lapis Fence",[
["lapis_block",0], 
["lapis_block",0],
["lapis_block",0], 
["lapis_block",0],   
["lapis_block",0], 
["lapis_block",0]],0,0,11);
Block.setShape(192,0,0,0,1, 1,1);  
Block.setDestroyTime(192,0.5);

Block.defineBlock(193, "Coal Fence",[
["coal_block",0], 
["coal_block",0],
["coal_block",0], 
["coal_block",0],   
["coal_block",0], 
["coal_block",0]],0,0,11);
Block.setShape(193,0,0,0,1, 1,1);  
Block.setDestroyTime(193,0.5);

Block.defineBlock(194, "Wool Fence",[
["wool",0], 
["wool",0],
["wool",0], 
["wool",0],   
["wool",0], 
["wool",0]],0,0,11);
Block.setShape(194,0,0,0,1, 1,1);  
Block.setDestroyTime(194,0.5);

Block.defineBlock(195, "Orange Wool Fence",[
["wool",1], 
["wool",1],
["wool",1], 
["wool",1],   
["wool",1], 
["wool",1]],0,0,11);
Block.setShape(195,0,0,0,1, 1,1);  
Block.setDestroyTime(195,0.5);

Block.defineBlock(196, "Magenta Wool Fence",[
["wool",2], 
["wool",2],
["wool",2], 
["wool",2],   
["wool",2], 
["wool",2]],0,0,11);
Block.setShape(196,0,0,0,1, 1,1);  
Block.setDestroyTime(196,0.5);

Block.defineBlock(197, "Blue Light Wool Fence",[
["wool",3], 
["wool",3],
["wool",3], 
["wool",3],   
["wool",3], 
["wool",3]],0,0,11);
Block.setShape(197,0,0,0,1, 1,1);  
Block.setDestroyTime(197,0.5);

Block.defineBlock(198, "Yellow Wool Fence",[
["wool",4], 
["wool",4],
["wool",4], 
["wool",4],   
["wool",4], 
["wool",4]],0,0,11);
Block.setShape(198,0,0,0,1, 1,1);  
Block.setDestroyTime(198,0.5);

Block.defineBlock(199, "Lime Wool Fence",[
["wool",5], 
["wool",5],
["wool",5], 
["wool",5],   
["wool",5], 
["wool",5]],0,0,11);
Block.setShape(199,0,0,0,1, 1,1);  
Block.setDestroyTime(199,0.5);

Block.defineBlock(200, "Pink Wool Fence",[
["wool",6], 
["wool",6],
["wool",6], 
["wool",6],   
["wool",6], 
["wool",6]],0,0,11);
Block.setShape(200,0,0,0,1, 1,1);  
Block.setDestroyTime(200,0.5);

Block.defineBlock(201, "Gray Wool Fence",[
["wool",7], 
["wool",7],
["wool",7], 
["wool",7],   
["wool",7], 
["wool",7]],0,0,11);
Block.setShape(201,0,0,0,1, 1,1);  
Block.setDestroyTime(201,0.5);

Block.defineBlock(202, "Light Gray Wool Fence",[
["wool",8], 
["wool",8],
["wool",8], 
["wool",8],   
["wool",8], 
["wool",8]],0,0,11);
Block.setShape(202,0,0,0,1, 1,1);  
Block.setDestroyTime(202,0.5);

Block.defineBlock(203, "Cyan Wool Fence",[
["wool",9], 
["wool",9],
["wool",9], 
["wool",9],   
["wool",9], 
["wool",9]],0,0,11);
Block.setShape(203,0,0,0,1, 1,1);  
Block.setDestroyTime(203,0.5);

Block.defineBlock(204, "Purple Wool Fence",[
["wool",10], 
["wool",10],
["wool",10], 
["wool",10],   
["wool",10], 
["wool",10]],0,0,11);
Block.setShape(204,0,0,0,1, 1,1);  
Block.setDestroyTime(204,0.5);

Block.defineBlock(205, "Blue Wool Fence",[
["wool",11], 
["wool",11],
["wool",11], 
["wool",11],   
["wool",11], 
["wool",11]],0,0,11);
Block.setShape(205,0,0,0,1, 1,1);  
Block.setDestroyTime(205,0.5);

Block.defineBlock(206, "Brown Wool Fence",[
["wool",12], 
["wool",12],
["wool",12], 
["wool",12],   
["wool",12], 
["wool",12]],0,0,11);
Block.setShape(206,0,0,0,1, 1,1);  
Block.setDestroyTime(206,0.5);

Block.defineBlock(207, "Green Wool Fence",[
["wool",13], 
["wool",13],
["wool",13], 
["wool",13],   
["wool",13], 
["wool",13]],0,0,11);
Block.setShape(207,0,0,0,1, 1,1);  
Block.setDestroyTime(207,0.5);

Block.defineBlock(208, "Red Wool Fence",[
["wool",14], 
["wool",14],
["wool",14], 
["wool",14],   
["wool",14], 
["wool",14]],0,0,11);
Block.setShape(208,0,0,0,1, 1,1);  
Block.setDestroyTime(208,0.5);

Block.defineBlock(209, "Black Wool Fence",[
["wool",15], 
["wool",15],
["wool",15], 
["wool",15],   
["wool",15], 
["wool",15]],0,0,11);
Block.setShape(209,0,0,0,1, 1,1);  
Block.setDestroyTime(209,0.5);

Block.defineBlock(210, "Lava Fence",[
["still_lava",0], 
["still_lava",0],
["still_lava",0], 
["still_lava",0],   
["still_lava",0], 
["still_lava",0]],100,100,11);
Block.setShape(210,0,0,0,1, 1,1);  
Block.setDestroyTime(210,0.5);
Block.setLightLevel(210,15);

Block.defineBlock(211, "Sponge Fence",[
["sponge",0], 
["sponge",0],
["sponge",0], 
["sponge",0],   
["sponge",0], 
["sponge",0]],1,10,11);
Block.setShape(211,0,0,0,1, 1,1);  
Block.setDestroyTime(211,0.5);

Block.defineBlock(212, "Water Fence",[
["still_water",0], 
["still_water",0],
["still_water",0], 
["still_water",0],   
["still_water",0], 
["still_water",0]],100,100,11);
Block.setShape(212,0,0,0,1, 1,1);  
Block.setDestroyTime(212,0.5);

Block.defineBlock(213, "Redstone Lamp Fence ",[
["redstone_lamp_off", 0], 
["redstone_lamp_off", 0],   
["redstone_lamp_off", 0], 
["redstone_lamp_off", 0],   
["redstone_lamp_off", 0], 
["redstone_lamp_off", 0]],1,1,11);  
Block.setShape(213, 0, 0, 0, 1, 1,1);  
Block.setDestroyTime(213,.25);  
  
Block.defineBlock(214, "Redstone Lamp Fence",[
["redstone_lamp_on",0], 
["redstone_lamp_on",0],
["redstone_lamp_on",0], 
["redstone_lamp_on",0],   
["redstone_lamp_on",0], 
["redstone_lamp_on",0]],1,1,11);
Block.setShape(214,0,0,0,1, 1,1);  
Block.setDestroyTime(214,0.5);
Block.setLightLevel(214,30);
}
function procCmd(cmd)
{
var cmd = cmd.split(" ");
if(cmd[0]=="OreFences")
{
addItemInventory(187,16);
addItemInventory(188,16);
addItemInventory(189,16);
addItemInventory(190,16);
addItemInventory(191,16);
addItemInventory(192,16);
addItemInventory(193,16);
}
else if(cmd[0]=="WoolFences")
{
addItemInventory(194,16);
addItemInventory(195,16);
addItemInventory(196,16);
addItemInventory(197,16);
addItemInventory(198,16);
addItemInventory(199,16);
addItemInventory(200,16);
addItemInventory(201,16);
addItemInventory(202,16);
addItemInventory(203,16);
addItemInventory(204,16);
addItemInventory(205,16);
addItemInventory(206,16);
addItemInventory(207,16);
addItemInventory(208,16);
addItemInventory(209,16);
}
else if(cmd[0]=="MiscFences")
{
addItemInventory(212,16);
addItemInventory(211,16);
addItemInventory(210,16);
addItemInventory(186,16);
addItemInventory(213,16);
}
}
function destroyBlock(x,y,z,side)
{
if(getTile(x,y,z)==186|| getTile(x,y,z)==187|| getTile(x,y,z)==188|| getTile(x,y,z)==189|| getTile(x,y,z)==190|| getTile(x,y,z)==191|| getTile(x,y,z)==192|| getTile(x,y,z)==193|| getTile(x,y,z)==194|| getTile(x,y,z)==195|| getTile(x,y,z)==196|| getTile(x,y,z)==197|| getTile(x,y,z)==198|| getTile(x,y,z)==199|| getTile(x,y,z)==200|| getTile(x,y,z)==201|| getTile(x,y,z)==202|| getTile(x,y,z)==203|| getTile(x,y,z)==204|| getTile(x,y,z)==205||getTile(x,y,z)==206||getTile(x,y,z)==207||getTile(x,y,z)==208||getTile(x,y,z)==209||getTile(x,y,z)==210||getTile(x,y,z)==211||getTile(x,y,z)==212||getTile(x,y,z)==213&&getCarriedItem()>=0)
{
Level.dropItem(x,y,z,1,getTile(x,y,z),1);
}
}
function modTick()
{
if(getTile(getPlayerX()+1,getPlayerY()-1,getPlayerZ())==210||getTile(getPlayerX(),getPlayerY()-1,getPlayerZ()+1)==210||getTile(getPlayerX()-1,getPlayerY()-1,getPlayerZ())==210||getTile(getPlayerX(),getPlayerY()-1,getPlayerZ()-1)==210||getTile(getPlayerX(),getPlayerY()-2,getPlayerZ())==210)
{
Entity.setFireTicks(getPlayerEnt(),1);
}
}
function useItem(x,y,z,i,b,s)
{
if(b==213)
{
getTile(x,y,z);
setTile(x,y,z,214)
}
else if(b==214)
{
getTile(x,y,z);
setTile(x,y,z,213)
Block.setLightLevel(213,0);
}
}