﻿/*

	####   #   #    ##        #       #
	#  #   #   #   #  #       #       #
	####   #   #    #         #       #
	##     #   #     #        #       #
	# #    #   #   #  #   #   #   #   #
	#  #    ###     ##     ###     ###

	####    ###     ###    ####    ####   ####
	#      #   #   #   #   #   #   #      #  #
	####   #   #   #   #   #   #   ####   ####
	#      #   #   #   #   #   #   #      ##
	#      #   #   #   #   #   #   #      # #
	#       ###     ###    ####    ####   #  #

	#   #      #       #####     #
	#   #     ##       #        ##
	 # #     # #       ####    # #
	 # #       #           #     #
	  #        #       #   #     #
	  #      #####  #   ###    #####

*/

/* [ - New items - ] */

ModPE.setFoodItem(322, "apple_golden", 0, 8, "Golden Apple", 64);
ModPE.setFoodItem(367, "rotten_flesh", 0, 1, "Rotten Flesh", 64);
ModPE.setFoodItem(349, "fish_raw", 0, 3, "Raw Fish", 64);
ModPE.setFoodItem(350, "fish_cooked", 0, 6, "Cooked Fish", 64);
ModPE.setFoodItem(357, "cookie", 0, 1, "Cookie", 64);
ModPE.setFoodItem(376, "spider_eye", 0, 1, "Spider Eye", 64);
ModPE.setItem(346, "fishing_rod_uncast", 0, "Fishing Rod", 1);

ModPE.setFoodItem(215, "mushroom_stew" , 0, 6, "Chicken Soup", 1);
ModPE.setFoodItem(216, "mushroom_stew" , 0, 4, "Jelly", 16);
ModPE.setFoodItem(218, "pumpkin_pie" , 0, 8, "Apple Pie", 64);
ModPE.setFoodItem(219, "pumpkin_pie" , 0, 8, "Carrot Pie", 64);
ModPE.setFoodItem(220, "pumpkin_pie" , 0, 8, "Pie", 64);
ModPE.setFoodItem(221, "pumpkin_pie" , 0, 8, "Beetroot Pie", 64);
ModPE.setFoodItem(222, "pumpkin_pie" , 0, 8, "Melon Pie", 64);
ModPE.setFoodItem(223, "netherbrick" , 0, 3, "Chocolate", 16);

/* [ - New recipes - ] */

Item.addCraftRecipe(322, 1, 0, [266, 8, 0, 260, 1, 0]);
Item.addCraftRecipe(357, 8, 0, [296, 2, 0, 351, 1,  3]);
Item.addCraftRecipe(346, 1, 0, [280, 3, 0, 287, 2, 0]);
Item.addCraftRecipe(351, 4, 0, [263, 1, 0, 325, 1, 8]); 
Item.addCraftRecipe(215, 1, 0, [281, 1, 0, 365, 1, 0, 392, 1, 0]);
Item.addCraftRecipe(216, 3, 0, [281, 3, 0, 325, 1, 8, 351, 2, 15, 353, 2, 0]);
Item.addCraftRecipe(218, 1, 0, [260, 1, 0, 344, 1, 0, 353, 1, 0]); 
Item.addCraftRecipe(219, 1, 0, [391, 1, 0, 344, 1, 0, 353, 1, 0]);
Item.addCraftRecipe(220, 1, 0, [296, 1, 0, 344, 1, 0, 353, 1, 0]);
Item.addCraftRecipe(221, 1, 0, [457, 1, 0, 344, 1, 0, 353, 1, 0]);
Item.addCraftRecipe(222, 1, 0, [360, 1, 0, 344, 1, 0, 353, 1, 0]); 
Item.addCraftRecipe(223, 2, 0, [351, 2, 3, 353, 1,  0]);
Item.addCraftRecipe(351, 4, 0, [263, 1, 0, 325, 1, 8]); 
Item.addCraftRecipe(351, 3, 0, [263, 1, 1, 325, 1, 8]);

Item.addFurnaceRecipe(349, 350, 0);
Item.addFurnaceRecipe(367, 351, 1);
Item.addFurnaceRecipe(40, 351, 1);

Item.setMaxDamage(346, 60);

/* [ - Functions - ] */

function useItem(x, y, z, itemId, blockId, side) 
{
    if(itemId == 346) 
    {
        if(getTile(x,y+1,z) == 8 || getTile(x,y+1,z) == 9) 
        {
	        var fishDrop = random(0, 9);
			if(Player.getCarriedItemData() < 60)
			{
				Entity.setCarriedItem(Player.getEntity(), 346, 1, Player.getCarriedItemData() + 1);
			}
			else
			{
				Entity.setCarriedItem(Player.getEntity(), 0, 0, 0);
			}
			if(fishDrop == 0) 
            {
	            Level.dropItem(Player.getX(), Player.getY(), Player.getZ(), 4, 349, 1, 0);
	        }
	    }
    }
}

function deathHook(attacker, victim) 
{
    if(Entity.getEntityTypeId(victim) == 32 && Entity.getEntityTypeId(victim) == 36) 
    {
		var fleshDrop = random(0, 3);
	    if(fleshDrop == 0) 
        {
	        Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 367, 1, 0);
	    } 
        else if(fleshDrop == 1) 
        {
	        Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 367, 2, 0);
	    }
    }
    else if (Entity.getEntityTypeId(victim) == 35) 
    {
		var eyeDrop = random(0, 4);
	    if(eyeDrop == 0) 
        {
	        Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 376, 1, 0);
	    }
    }
}

function random(min, max)
{
    return Math.floor((Math.random() * max) + min);
}