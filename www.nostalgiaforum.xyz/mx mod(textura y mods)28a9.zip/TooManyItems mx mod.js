/*
 Too Many Items versión mx mod by Elcoshiloco
Gracias a MRARM por este mod
*/

var btnWindow = null;
var mainMenu = null;
var btnMenu = null;
var btnMenuSub = null;
var subMenu = null;
var infoMenu = null;

var addToInventory = false;
var addId;
var addDmg;
var addCount;
var ride = false;
var riding = false;
var ridingAnimal;
var spawnOnTap = -1;

function dip2px(ctx, dips){
 return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
}

function newLevel(){
	// run all the stuff at UI thread
	
	var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
	ctx.runOnUiThread(new java.lang.Runnable({ run: function() {
		try{
			var layout = new android.widget.RelativeLayout(ctx);
			var button = new android.widget.Button(ctx);
			button.setText("Mx");
			//button.setWidth(100);
			//button.setHeight(100);
			button.setOnClickListener(new android.view.View.OnClickListener({
				onClick: function(viewarg) {
				    spawnOnTap = -1;
					openMenu();
				}
			}));
			layout.addView(button);
			
			
			btnWindow = new android.widget.PopupWindow(layout, dip2px(ctx, 48), dip2px(ctx, 48));
		//	btnWindow.setContentView(layout);
		//	btnWindow.setWidth(dip2px(ctx, 48));
		//	btnWindow.setHeight(dip2px(ctx, 48));
			btnWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
			var flags;
			var bx = 0;
			var by = 0;
			var btnPosC = ModPE.readData("btnPos");
			if(btnPosC == "0"){
                flags = android.view.Gravity.TOP | android.view.Gravity.LEFT;
                by = dip2px(ctx, 20);
			}else if(btnPosC == "1"){
                flags = android.view.Gravity.TOP | android.view.Gravity.RIGHT;
                bx = dip2px(ctx, 38);
                
                btnWindow.setWidth(dip2px(ctx, 38));
			    btnWindow.setHeight(dip2px(ctx, 38));
			}else if(btnPosC == "2"){
                flags = android.view.Gravity.LEFT | android.view.Gravity.BOTTOM;
			}else if(btnPosC == "3" || btnPosC == ""){
                flags = android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM;
			}
			btnWindow.showAtLocation(ctx.getWindow().getDecorView(), flags, bx, by);
		}catch(err){
			print("Error al mostrar el boton.");
		}
	} }));
  
}

function compareMobs(mob1, mob2){
    if(mob1 == null || mob2 == null) return false;
    
    if(Entity.getX(mob1) == Entity.getX(mob2) &&
        Entity.getY(mob1) == Entity.getY(mob2) &&
        Entity.getZ(mob1) == Entity.getZ(mob2) &&
        Entity.getEntityTypeId(mob1) == Entity.getEntityTypeId(mob2))
        return true;
        
    return false;
}

function attackHook(attacker, entity){
    if(riding && compareMobs(entity, ridingAnimal)) { rideAnimal(attacker, entity); riding = false; preventDefault(); }
    else if(ride){ rideAnimal(attacker, entity); riding = true; ridingAnimal = entity; clientMessage("Para dejar de montar toque el animal de nuevo."); ride = false; preventDefault(); }
}

function useItem(x, y, z, itemid, blockid, side, itemDamage, blockDamage){
    if(spawnOnTap != -1){
        Level.spawnMob(x-(side==4?1:0)+(side==5?1:0)+0.5,y-(side==0?1:0)+(side==1?1:0)+0.5,z-(side==2?1:0)+(side==3?1:0)+0.5,spawnOnTap,null);
        preventDefault();
    }
}

var CAT_STARTER_KIT = 0;
var CAT_STARTER_KIT_ITEMS = [
  {name: "Casco de Diamante", id: 310, data: 0},
  {name: "Peto de Diamante", id: 311, data: 0},
  {name: "Pantalon de Diamante", id: 312, data: 0},
  {name: "Botas de Diamante", id: 313, data: 0},
  {name: "Espada de Diamante", id: 276, data: 0},
  {name: "Pala de Diamanate", id: 277, data: 0},
  {name: "Pico de Diamante", id: 278, data: 0},
  {name: "Azadon de Diamante", id: 293, data: 0},
  {name: "Hacha de Diamante", id: 279, data: 0},
  {name: "Brújula", id: 345, data: 0},
  {name: "Reloj", id: 347, data: 0},
  {name: "Mesa de Crafteo", id: 58, data: 0},
  {name: "Cama", id: 355, data: 0},
  {name: "Antorcha", id: 50, data: 0},
  {name: "Tabla de Madera", id: 5, data: 0}];
var CAT_BUILDING = 1;
var CAT_BUILDING_ITEMS = [
  {name: "Piedra", id: 1, data: 0},
  {name: "Hierba", id: 2, data: 0},
  {name: "Tierra", id: 3, data: 0},
  {name: "Podzol", id: 243, data: 0},
  {name: "Myceliun", id: 110, data: 0},
  {name: "Cobblestone", id: 4, data: 0},
  {name: "Granito", id: 1, data: 1},
  {name: "Granito Pulido", id: 1, data: 2},
  {name: "Diorito", id: 1, data: 3},
  {name: "Diorito Pulido ", id: 1, data: 4},
  {name: "Andesito", id: 1, data: 5},
  {name: "Andesito Pulido", id: 1, data: 6},
  {name: "Tabla de Acacia", id: 5, data: 4},
  {name: "Tabla de Jungla", id: 5, data: 5},
  {name: "Tabla de Madera", id: 5, data: 0},
  {name: "Tabla de Abeto", id: 5, data: 1},
  {name: "Tabla de Abedul", id: 5, data: 2},
  {name: "Tabla de Selva", id: 5, data: 3}, 
  {name: "Roca Base", id: 7, data: 0},
  {name: "Arena", id: 12, data: 0},
  {name: "Arena Roja", id: 12, data: 1},
  {name: "Grava", id: 13, data: 0},
  {name: "Madera de Jungla", id: 162, data: 1},
  {name: "Madera de Acacia", id: 162, data: 0},
  {name: "Madera de Roble", id: 17, data: 0},
  {name: "Madera de Abeto", id: 17, data: 1},
  {name: "Madera de Abedul", id: 17, data: 2},
  {name: "Madera de Selva", id: 17, data: 3},
  {name: "Bloque de Vidrio", id: 20, data: 0},
  {name: "Bloque Lapis Lazuli", id: 22, data: 0},
  {name: "Arenisca", id: 24, data: 0},
  {name: "Arenisca Cincelada", id: 24, data: 1},
  {name: "Piedra de Arenisca", id: 24, data: 2},
  {name: "Lana Blanca", id: 35, data: 0},
  {name: "Lana Naranja", id: 35, data: 1},
  {name: "Lana Magenta", id: 35, data: 2},
  {name: "Lana Azul", id: 35, data: 3},
  {name: "Lana Amarilla", id: 35, data: 4},
  {name: "Lana Lima", id: 35, data: 5},
  {name: "Lana Rosa", id: 35, data: 6},
  {name: "Lana Gris", id: 35, data: 7},
  {name: "Lana Gris Luz", id: 35, data: 8},
  {name: "Lana Cyan", id: 35, data: 9},
  {name: "Lana Púrpura", id: 35, data: 10},
  {name: "Lana Azul", id: 35, data: 11},
  {name: "Lana Marrón", id: 35, data: 12},
  {name: "Lana Verde", id: 35, data: 13},
  {name: "Lana Roja", id: 35, data: 14},
  {name: "Lana Negra", id: 35, data: 15},
  {name: "Bloque de esmeralda", id: 133, data: 0},
  {name: "Bloque de Diamante", id: 57, data: 0},
  {name: "Bloque de Oro", id: 41, data: 0},
  {name: "Bloque de Hierro", id: 42, data: 0},
  {name: "Bloque de Carbón", id: 173, data: 0},
  {name: "Losa de Acacia", id: 158, data: 4},
  {name: "Losa de Jungla", id: 158, data: 5},
  {name: "Losa de piedra", id: 43, data: 0},
  {name: "Losa de Arenisca", id: 43, data: 1},
  {name: "Losa de Madera", id: 43, data: 2},
  {name: "Losa de Cobblestone", id: 43, data: 3},
  {name: "Losa de Ladrillo", id: 43, data: 4},
  {name: "Losa de Piedra", id: 44, data: 0},
  {name: "Losa de Arenisca", id: 44, data: 1},
//Wooden Slab (44:2)
  {name: "Losa de Roble", id: 158, data: 0},
  {name: "Losa de Abeto", id: 158, data: 1},
  {name: "Losa de Abedul", id: 158, data: 2},
  {name: "Losa de Selva", id: 158, data: 3},
  {name: "Losa de Cobblestone", id: 44, data: 3},
  {name: "Losa de Ladrillo", id: 44, data: 4},
  {name: "Losa Piedra de Ladrillo", id: 44, data: 5},
//Stone Slab (44:6)
  {name: "Losa de Cuarzo", id: 44, data: 7},
  {name: "Bloque de Ladrillo", id: 45, data: 0},
  {name: "Ladrillo Nether", id: 112, data: 0},
  {name: "Musgosa Cobblestone", id: 48, data: 0},
  {name: "Obsidiana", id: 49, data: 0},
  {name: "Escaleras de Jungla", id: 164, data: 0},
  {name: "Escaleras de Acacia", id: 163, data: 0},
  {name: "Escaleras de Roble", id: 53, data: 0},
  {name: "Escaleras de Cobblestone", id: 67, data: 0},
  {name: "Escaleras de Ladrillo", id: 108, data: 0},
  {name: "Escaleras de Piedra", id: 109, data: 0},
  {name: "Escaleras de Ladrillo Nether", id: 114, data: 0},
  {name: "Escaleras de Arenisca", id: 128, data: 0},
  {name: "Escaleras de Abeto", id: 134, data: 0},
  {name: "Escaleras de Abedul", id: 135, data: 0},
  {name: "Escaleras de Selva", id: 136, data:0},
  {name: "Escaleras de Cuarzo", id: 156, data: 0},
  {name: "Arcilla", id: 82, data: 0},
  {name: "Valla", id: 85, data: 0},
  {name: "Puerta de Valla", id: 107, data: 0},
  {name: "Roca Nether", id: 87, data: 0},
// Invisible bedrock (95)
  {name: "Ladrillos Piedra", id: 98, data: 0},
  {name: "Piedra de Musgo", id: 98, data: 1},
  {name: "Piedra Agrietada", id: 98, data: 2},
  {name: "Panel de Cristal", id: 102, data: 0}];
  //******** por confirmar **********
  //{name: "Glitch Hierba", id: 253, data: 0},
  //{name: "Hojas Glitch", id: 254, data: 0},
  //{name: "Piedra Glitch", id: 255, data: 0}

var CAT_DECORATION = 2;
var CAT_DECORATION_ITEMS = [
  {name: "Lianas", id: 106, data: 0},
  {name: "Lilypad", id: 111, data: 0},
  {name: "End Portal", id: 120, data: 0},
  {name: "Piedra del End", id: 121, data: 0},
  {name: "Arcilla Horneada", id: 172, data: 0},
  {name: "Arcilla Blanca", id: 159, data: 0},
  {name: "Arcilla Naranja", id: 159, data: 1},
  {name: "Arcilla Magenta", id: 159, data: 2},
  {name: "Arcilla Azul Claro", id: 159, data: 3},
  {name: "Arcilla Amarilla", id: 159, data: 4},
  {name: "Arcilla Lima", id: 159, data: 5},
  {name: "Arcilla Rosa", id: 159, data: 6},
  {name: "Arcilla Gris", id: 159, data: 7},
  {name: "Arcilla Gris Claro", id: 159, data: 8},
  {name: "Arcilla Cyan", id: 159, data: 9},
  {name: "Arcilla Purpura", id: 159, data: 10},
  {name: "Arcilla Azul", id: 159, data: 11},
  {name: "Arcilla Marron", id: 159, data: 12},
  {name: "Arcilla Verde", id: 159, data: 13},
  {name: "Arcilla Roja", id: 159, data: 14},
  {name: "Arcilla Negra", id: 159, data: 15},
  {name: "Zeta ", id: 100, data: 14},
  {name: "Zeta ", id: 99, data: 0},
  {name: "Zeta ", id: 99, data: 14},
  {name: "Zeta ", id: 99, data: 15},
  {name: "Spawner", id: 52, data: 0},
  {name: "Esponja", id: 19, data: 0},
  {name: "Orquidea Azul", id: 38, data: 1},
  {name: "Flor Allium", id: 38, data: 2},
  {name: "Flor Austonia", id: 38, data: 3},
  {name: "Tulipan Rojo", id: 38, data: 4},
  {name: "Tulipan Naranja", id: 38, data: 5},
  {name: "Tulipan Blanco", id: 38, data: 6},
  {name: "Tulipan Rosa", id: 38, data: 7},
  {name: "Flor Daisy", id: 38, data: 8},
  {name: "Girasol", id: 175, data: 0},
  {name: "Flor Syringa", id: 175, data: 1},
  {name: "Pasto Doble", id: 175, data: 2},
  {name: "Planta Doble", id: 175, data: 3},
  {name: "Rosa", id: 175, data: 4},
  {name: "Flor Paeonia", id: 175, data: 5},
  {name: "Flor Amarilla", id: 37, data: 0},
  {name: "Flor Cyan", id: 38, data: 0},
  {name: "Libreria", id: 47, data: 0},
  {name: "Nieve", id: 78, data: 0},
  {name: "Hielo", id: 79, data: 0},
  {name: "Hielo Comprimido", id: 174, data: 2},
  {name: "Bloque de Nieve", id: 80, data: 0},
  {name: "Cactus", id: 81, data: 0},
  {name: "Caña de Azúcar", id: 338, data: 0},
//Sugar Cane (83)
  {name: "Piedra Luminosa", id: 89, data: 0},
  {name: "Calabaza Brillante", id: 91, data: 0},
// Cake block (92)
  {name: "Melon", id: 103, data: 0},
  {name: "Bloque de Cuarzo", id: 155, data: 0},
  {name: "Barras de Hierro", id: 101, data: 0},
  {name: "Pared de Cobblestone", id: 139, data: 0},
  {name: "Pared de Cobblestone Musgo", id: 139, data: 1},
  {name: "Bloque de Cuarzo Cincelado", id: 155, data: 1},
  {name: "Bloque de Cuarzo Pilar", id: 155, data: 2},
  {name: "Fardo de Paja", id: 170, data: 0},
  {name: "Alfombra", id: 171, data: 0},
  {name: "Obsidiana Brillante", id: 246, data: 0},
  {name: "Bloque de Actualización 1", id: 248, data: 0},
  {name: "Bloque de Actualización 2", id: 249, data: 0},
// grass_carried (253)
// leaves_carried (254)
// info_reserved6 (255)
  {name: "Cuadro", id: 321, data: 0}];
var CAT_ARMOUR = 3;
var CAT_ARMOUR_ITEMS = [
  {name: "Casco de Diamante", id: 310, data: 0},
  {name: "Peto de Diamante", id: 311, data: 0},
  {name: "Pantalon de Diamante", id: 312, data: 0},
  {name: "Botas de Diamante", id: 313, data: 0},
  {name: "Casco de Oro", id: 314, data: 0},
  {name: "Peto de Oro", id: 315, data: 0},
  {name: "Pantalon de Oro", id: 316, data: 0},
  {name: "Botas de Oro", id: 317, data: 0},
  {name: "Casco de Hierro", id: 306, data: 0},
  {name: "Peto de Hierro", id: 307, data: 0},
  {name: "Pantalon de Hierro", id: 308, data: 0},
  {name: "Botas de Hierro", id: 309, data: 0},
  {name: "Casco de Cuero", id: 298, data: 0},
  {name: "Peto de Cuero", id: 299, data: 0},
  {name: "Pantalones de Cuero", id: 300, data: 0},
  {name: "Botas de Cuero", id: 301, data: 0}];
var CAT_TOOLS = 4;
var CAT_TOOLS_ITEMS = [
  {name: "Mechero", id: 259, data: 0},
  {name: "Arco", id: 261, data: 0},
  {name: "Flecha", id: 262, data: 0},
  {name: "Cizalla", id: 359, data: 0},
  {name: "Espada de Diamante", id: 276, data: 0},
  {name: "Pala de Diamante", id: 277, data: 0},
  {name: "Pico de Diamante", id: 278, data: 0},
  {name: "Azadon de Diamante", id: 293, data: 0},
  {name: "Hacha de Diamante", id: 279, data: 0},
  {name: "Espada de Oro", id: 283, data: 0},
  {name: "Pala de Oro", id: 284, data: 0},
  {name: "Pico de Oro", id: 285, data: 0},
  {name: "Azadon de Oro", id: 294, data: 0},
  {name: "Hacha de Oro", id: 286, data: 0},
  {name: "Espada de Hierro", id: 267, data: 0},
  {name: "Pala de Hierro", id: 256, data: 0},
  {name: "Pico de Hierro", id: 257, data: 0},
  {name: "Azadon de Hierro", id: 292, data: 0},
  {name: "Hacha de Hierro", id: 258, data: 0},
  {name: "Espada de Piedra", id: 272, data: 0},
  {name: "Pala de piedra", id: 273, data: 0},
  {name: "Pico de Piedra", id: 274, data: 0},
  {name: "Azadon de Piedra", id: 291, data: 0},
  {name: "Hacha de Piedra", id: 275, data: 0},
  {name: "Espada de Madera", id: 268, data: 0},
  {name: "Pala de Madera", id: 269, data: 0},
  {name: "Pico de Madera", id: 270, data: 0},
  {name: "Azadon de Madera", id: 290, data: 0},
  {name: "Hacha de Madera", id: 271, data: 0}];
var CAT_FOOD = 5;
var CAT_FOOD_ITEMS = [
  {name: "Galleta", id: 357, data: 0},
  {name: "Calabaza", id: 86, data: 0},
  {name: "Manzana", id: 260, data: 0},
  {name: "Hongo Marrón", id: 39, data: 0},
  {name: "Seta Roja", id: 40, data: 0},
  {name: "Sopa de Hongos", id: 282, data: 0},
  {name: "Carne de Cerdo", id: 319, data: 0},
  {name: "Carne de Cerdo Cocinada", id: 320, data: 0},
  {name: "Carne Cruda", id: 363, data: 0},
  {name: "Filete", id: 364, data: 0},
  {name: "Pollo Crudo", id: 365, data: 0},
  {name: "Pollo Cocinado", id: 366, data: 0},
  {name: "Pastel", id: 354, data: 0},
  {name: "Zanahoria", id: 391, data: 0},
  {name: "Patata", id: 392, data: 0},
  {name: "Patata Horneada", id: 393, data: 0},
  {name: "Pastel de Calabaza", id: 400, data: 0},
  {name: "Remolacha", id: 457, data: 0},
  {name: "Sopa de Remolachas", id: 459, data: 0}];
var CAT_DYES = 6;
var CAT_DYES_ITEMS = [
  {name: "tinte", id: 351, data: 0},
  {name: "Rosa Roja", id: 351, data: 1},
  {name: "Cactus Verde", id: 351, data: 2},
  {name: "Granos de Cacao", id: 351, data: 3},
  {name: "Lapis Lazuli", id: 351, data: 4},
  {name: "Púrpura", id: 351, data: 5},
  {name: "Cyan", id: 351, data: 6},
  {name: "Gris claro", id: 351, data: 7},
  {name: "Gris", id: 351, data: 8},
  {name: "Rosa", id: 351, data: 9},
  {name: "Lima", id: 351, data: 10},
  {name: "Diente de León Amarillo", id: 351, data: 11},
  {name: "Azul claro", id: 351, data: 12},
  {name: "Magenta", id: 351, data: 13},
  {name: "Naranja", id: 351, data: 14},
  {name: "Polvo de Huesos", id: 351, data: 15}];
var CAT_ITEMS = 7;
var CAT_ITEMS_ITEMS = [
  {name: "Mineral de Esmeralda", id: 129, data: 0},
  {name: "Mineral de Diamante", id: 56, data: 0},
  {name: "Mineral de Oro", id: 14, data: 0},
  {name: "Mineral de Hierro", id: 15, data: 0},
  {name: "Mineral de Carbón", id: 16, data: 0},
  {name: "Mineral de Lapislázuli", id: 21, data: 0},
  {name: "Riel con Potencia", id: 27, data: 0},
  {name: "Riel", id: 66, data: 0},
  {name: "Mineral de Redstone", id: 73, data: 0},
// Glowing Redstone Ore (74)
  {name: "Esmeralda", id: 388, data: 0},
  {name: "Diamante", id: 264, data: 0},
  {name: "Lingote de Hierro", id: 265, data: 0},
  {name: "Lingote de Oro", id: 266, data: 0},
  {name: "Palo", id: 280, data: 0},
  {name: "Pedernal", id: 318, data: 0},
  {name: "Tazon", id: 281, data: 0},
  {name: "Hueso", id: 352, data: 0},
  {name: "Cuerda", id: 287, data: 0},
  {name: "Cuero", id: 334, data: 0},
  {name: "Pluma", id: 288, data: 0},
  {name: "Azucar", id: 353, data: 0},
  {name: "Pólvora", id: 289, data: 0},
  {name: "Trigo", id: 296, data: 0},
  {name: "Pan", id: 297, data: 0},
  {name: "Carro Minero", id: 328, data: 0},
  {name: "Silla de Montar", id: 329, data: 0},
  {name: "Bola de Nieve", id: 332, data: 0},
  {name: "Bola de Slime", id: 341, data: 0},
  {name: "Huevo", id: 344, data: 0},
  {name: "Arcilla", id: 337, data: 0},
  {name: "Ladrillo Arcilla", id: 336, data: 0},
  {name: "Ladrillo Nether", id: 405, data: 0},
  {name: "Cuarzo de Nether", id: 406, data: 0},
  {name: "Papel", id: 339, data: 0},
  {name: "Libro", id: 340, data: 0},
  {name: "Brújula", id: 345, data: 0},
  {name: "Reloj", id: 347, data: 0},
  {name: "Polvo de Piedra Brillante", id: 348, data: 0},
  {name: "Sandia", id: 360, data: 0}];
var CAT_SPAWN = 8;
var CAT_SPAWN_ITEMS = [
  {name: "Spawn Vacazeta", id: 383, data: 16},
  {name: "Spawn Lobo", id: 383, data: 14},
  {name: "Spawn Aldeano", id: 383, data: 15},
  {name: "Spawn Pollo", id: 383, data: 10},
  {name: "Spawn Vaca", id: 383, data: 11},
  {name: "Spawn Cerdo", id: 383, data: 12},
  {name: "Spawn Oveja", id: 383, data: 13}];
var CAT_MISCELLANEOUS = 9;
var CAT_MISCELLANEOUS_ITEMS = [
  {name: "Mesa de Crafteo", id: 58, data: 0},
  {name: "Horno", id: 61, data: 0},
// Burning Furnance (62)
  {name: "Cortador de Piedra", id: 245, data: 0},
  {name: "Cofre", id: 54, data: 0},
  {name: "Antorcha", id: 50, data: 0},
  {name: "Escalera", id: 65, data: 0},
  {name: "Puerta de Madera", id: 324, data: 0},
  {name: "Puerta de Hierro", id: 330, data: 0},
  {name: "Trampa", id: 96, data: 0},
  {name: "Cartel", id: 323, data: 0},
  {name: "Cama", id: 355, data: 0},
  {name: "Carbón", id: 263, data: 0},
  {name: "Carbón Vegetal", id: 263, data: 1},
  {name: "Arbol Jungla", id: 6, data: 3},
  {name: "Arbol Acacia", id: 6, data: 4},
  {name: "Arbol Oak", id: 6, data: 5},
  {name: "Arbol Roble", id: 6, data: 0},
  {name: "Arbol Abeto", id: 6, data: 1},
  {name: "Arbol Abedul", id: 6, data: 2},
  {name: "Vástago de Melón", id: 105, data: 0},
  {name: "Semillas de Trigo", id: 295, data: 0},
  {name: "Semillas de Calabaza", id: 361, data: 0},
  {name: "Semillas de Melón", id: 362, data: 0},
  {name: "Semillas de Remolacha", id: 458, data: 0},
  {name: "Cubo", id: 325, data: 0},
  {name: "Cubo de Leche", id: 325, data: 1},
  {name: "Cubo de Agua", id: 325, data: 8},
// Water (8)
  {name: "Agua Estacionaria", id: 9, data: 0},
  {name: "Cubo de Lava", id: 325, data: 10},
// Lava (10)
  {name: "Lava Estacionaria", id: 11, data: 0},
  {name: "Hojas de Roble", id: 18, data: 0},
  {name: "Hojas de Abeto", id: 18, data: 1},
  {name: "Hojas de Abedul", id: 18, data: 2},
  {name: "Hojas de la Selva", id: 18, data: 3},
  {name: "Cama", id: 26, data: 0},
  {name: "Telaraña", id: 30, data: 0},
  {name: "Hierba", id: 31, data: 0},
  {name: "Arbusto Muerto", id:32 , data: 0},
  {name: "TNT", id: 46, data: 0},
// Fire (51)
// Crops Block (59)
  {name: "Tierras de Cultivo", id: 60, data: 0},
// Sign Post (63)
// Wall Sign (68)
// Wooden Door Block (64)
// Iron Door Block (71)
  {name: "Reactor Nether", id: 247, data: 0},
  {name: "Cámara", id: 456, data: 0}];
var CAT_MONSTER = 10;
var CAT_MONSTER_ITEMS = [
  {name: "Spawn Pigman", id: 383, data: 36},
  {name: "Spawn Zombie", id: 383, data: 32},
  {name: "Spawn Spider", id: 383, data: 35},
  {name: "Spawn Slime", id: 383, data: 37},
  {name: "Spawn Skeleton", id: 383, data: 34},
  {name: "Spawn Sirvelfish", id: 383, data: 39},
  {name: "Spawn Enderman", id: 383, data: 38}];
var CAT_MX_MOD = 11;
var CAT_MX_MOD_ITEMS = [
  {name: "Bigote", id: 302, data: 0},
  {name: "Camisa de charro", id: 303, data: 0},
  {name: "Pantalon de charro", id: 304, data: 0},
  {name: "Botas de charro", id: 305, data: 0},
{name: " Masa", id: 407, data: 0},
{name: " Tortilla", id: 408, data: 0},
{name: " Taco", id: 409, data: 0},
{name: " Tomate", id: 410, data: 0},
{name: " Chile", id: 411, data: 0},
{name: " Salsa", id: 412, data: 0},
{name: " Taco con salsa", id: 413, data: 0},
{name: " Torta", id: 414, data: 0},
{name: " Tamal", id: 415, data: 0},
{name: " Tamal cocido", id: 416, data: 0},
{name: "Tequila", id: 419, data: 0},
{name: " Coca cola", id: 417, data: 0},
{name: " Cerveza", id: 418, data: 0},
{name: " Tarro", id: 420, data: 0},
{name: " Machete", id: 421, data: 0},
{name: " Filero", id: 422, data: 0},
{name: " Botella vacía", id: 424, data: 0},
{name: " Lata vacía", id: 425, data: 0},
{name: " Botella con agua", id: 426, data: 0},
{name: " Tarro con agua", id: 427, data: 0},
{name: "Morral", id: 428, data: 0},
{name: " Maíz", id: 429, data: 0},
{name: " Cebada", id: 430, data: 0},
{name: " Agave", id: 431, data: 0}];

function openInfoDialogMenu(ctx, id, damage){
	try{
		//var menu = new android.widget.PopupWindow();
		//menu.setFocusable(true);
		//infoMenu = menu;
		
		var layout = new android.widget.LinearLayout(ctx);
		layout.setOrientation(1);
		
		var textParams = new android.widget.LinearLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
		textParams.setMargins(dip2px(ctx, 5), 0, 0, 0);
		
		var textParams2 = new android.widget.LinearLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
		textParams2.setMargins(dip2px(ctx, 5), dip2px(ctx, 10), 0, 0);
		var title = new android.widget.TextView(ctx);
		title.setTextSize(24);
		title.setText("Too Many Items");
		title.setLayoutParams(textParams);
		layout.addView(title);
		var stitle = new android.widget.TextView(ctx);
		stitle.setTextSize(14);
		stitle.setText("Agregar Item...");
		stitle.setLayoutParams(textParams);
		layout.addView(stitle);
		
		var iidt = new android.widget.TextView(ctx);
		iidt.setTextSize(14);
		iidt.setText("Item ID:");
		iidt.setLayoutParams(textParams2);
		layout.addView(iidt);
		
		var itemId = new android.widget.EditText(ctx);
		itemId.setText(id+"");
		itemId.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		layout.addView(itemId);
		
		var idmgt = new android.widget.TextView(ctx);
		idmgt.setTextSize(14);
		idmgt.setText("Item Daño:");
		idmgt.setLayoutParams(textParams2);
		layout.addView(idmgt);
		
		var itemDmg = new android.widget.EditText(ctx);
		itemDmg.setText(damage+"");
		itemDmg.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		layout.addView(itemDmg);
		
		var ict = new android.widget.TextView(ctx);
		ict.setTextSize(14);
		ict.setText("Item cantidad:");
		ict.setLayoutParams(textParams2);
		layout.addView(ict);
		
		var itemCount = new android.widget.EditText(ctx);
		itemCount.setText("1");
		itemCount.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		layout.addView(itemCount);
		
		var fullstack = new android.widget.Button(ctx);
		fullstack.setText("Full stack");
		fullstack.setOnClickListener(new android.view.View.OnClickListener({
			onClick: function(viewarg) {
				itemCount.setText("64");
			}
		}));
		layout.addView(fullstack);
		
		var addBtnParams = new android.widget.LinearLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.FILL_PARENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
		addBtnParams.setMargins(0, dip2px(ctx, 10), 0, 0);
		
		var add = new android.widget.Button(ctx);
		add.setText("Agregar");
		add.setLayoutParams(addBtnParams);
		add.setOnClickListener(new android.view.View.OnClickListener({
			onClick: function(viewarg) {
				addToInventory = true;
				addId = parseInt(itemId.getText());
				addDmg = parseInt(itemDmg.getText());
				addCount = parseInt(itemCount.getText());
			}
		}));
		layout.addView(add);
		
		var menu = new android.widget.PopupWindow(layout, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
		var mlayout = makeMenu(ctx, menu, layout);
		menu.setContentView(mlayout);
		//menu = new android.widget.PopupWindow(mlayout, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
		menu.setFocusable(true);
		infoMenu = menu;
		//menu.setContentView(mlayout);
		//btnWindow.setWidth(100);
		//menu.setWidth(ctx.getWindowManager().getDefaultDisplay().getWidth()/2);
		//menu.setHeight(ctx.getWindowManager().getDefaultDisplay().getHeight());
		menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK));
		menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
	}catch(err){
		print("No se pudo abrir el menú, ya que: "+err+".");
	}
}

function addMenuItem(ctx, layout, text, id, data){
	var button = new android.widget.Button(ctx);
	button.setText(text);
	//button.setWidth(100);
	//button.setHeight(100);
	button.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
		    if(Level.getGameMode() == 1){
		        Entity.setCarriedItem(getPlayerEnt(), id, 1, data);
		    }else{
			    openInfoDialogMenu(ctx, id, data);
		    }
		}
	}));
	layout.addView(button);
}

function openSubMenu(ctx, cname, cat){
	try{
		//var menu = new android.widget.PopupWindow();
		//menu.setFocusable(true);
		//subMenu = menu;
		
		var layout = new android.widget.LinearLayout(ctx);
		layout.setOrientation(1);
		
		var textParams = new android.widget.LinearLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
		textParams.setMargins(dip2px(ctx, 5), 0, 0, 0);
		var title = new android.widget.TextView(ctx);
		title.setTextSize(24);
		title.setText("Too Many Items v0.9.0");
		title.setLayoutParams(textParams);
		layout.addView(title);
		var stitle = new android.widget.TextView(ctx);
		stitle.setTextSize(14);
		stitle.setText(cname);
		stitle.setLayoutParams(textParams);
		layout.addView(stitle);
		for(var i=0;i<cat.length;i++)
			addMenuItem(ctx, layout, cat[i].name, cat[i].id, cat[i].data);
		
		var menu = new android.widget.PopupWindow(layout, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
		var mlayout = makeMenu(ctx, menu, layout);
		menu.setContentView(mlayout);
		menu.setFocusable(true);
		subMenu = menu;
		//btnWindow.setWidth(100);
		//menu.setWidth(ctx.getWindowManager().getDefaultDisplay().getWidth()/2);
		//menu.setHeight(ctx.getWindowManager().getDefaultDisplay().getHeight());
		menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK));
		menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
	}catch(err){
		print("No se pudo abrir el menú, ya que: "+err+".");
	}
}

function addMenuCategory(ctx, layout, text, catid){
	var button = new android.widget.Button(ctx);
	button.setText(text);
	//button.setWidth(100);
	//button.setHeight(100);
	button.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
			if(catid == null){
				openInfoDialogMenu(ctx, 1, 0);
			}else{
				openSubMenu(ctx, text, catid);
			}
		}
	}));
	layout.addView(button);
}

function makeMenu(ctx, menu, layout, main){
	var mlayout = new android.widget.RelativeLayout(ctx); // main layout
	var xbutton = new android.widget.Button(ctx);
	xbutton.setText("x");
	var btnParams = new android.widget.RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
	btnParams.addRule(android.widget.RelativeLayout.ALIGN_PARENT_RIGHT);
	btnParams.addRule(android.widget.RelativeLayout.ALIGN_PARENT_TOP);
	xbutton.setLayoutParams(btnParams);
	xbutton.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
		    if(menu != null){
			    menu.dismiss();
			    menu = null;
		    }
			if(main && btnMenu != null){
			    btnMenu.dismiss();
			    btnMenu = null;
			}
		}
	}));
	
	var svParams = new android.widget.RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.FILL_PARENT, android.widget.RelativeLayout.LayoutParams.FILL_PARENT);
	var scrollview = new android.widget.ScrollView(ctx);
	var pad = dip2px(ctx, 5);
	scrollview.setPadding(pad, pad, pad, pad);
	scrollview.setLayoutParams(svParams);
	
	scrollview.addView(layout);
	mlayout.addView(scrollview);
	mlayout.addView(xbutton);
	return mlayout;
}

function showButtons(ctx){
    function updateTime(){
        if(currSurvival){
            var ltime = Level.getTime()-Math.floor(Level.getTime()/19200)*19200;
            day = ltime < (19200/2);
            time.setText(day?"Noche":"Dia");
        }else{
            time.setText("Noche");
            day = true;
        }
    }
    //var menu = new android.widget.PopupWindow();
	//btnMenu = menu;
	
	var layout = new android.widget.LinearLayout(ctx);
	layout.setOrientation(0);
	
	var heal = new android.widget.Button(ctx);
	heal.setText("Vida");
	heal.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
			Player.setHealth(20);
		}
	}));
	layout.addView(heal);
	
	var gamemode = new android.widget.Button(ctx);
	var currSurvival = Level.getGameMode()==0;
	gamemode.setText(currSurvival?"Creativo":"Survival");
	gamemode.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
			currSurvival = !currSurvival;
			Level.setGameMode(currSurvival?0:1);
			updateTime();
			gamemode.setText(currSurvival?"Creativo":"Survival");
		}
	}));
	layout.addView(gamemode);
	
	var day = true;
	var time = new android.widget.Button(ctx);
	time.setText("Dia");
	time.setOnClickListener(new android.view.View.OnClickListener({
        onClick: function(viewarg) {
            try{
                day = !day;
                //var ti = Math.floor(Level.getTime()/19200)*19200;
                var newTime = day?0:8280;
                Level.setTime(newTime);
                updateTime();
            }catch(e){
                print("Here is the error: "+e);
            }
		}
	}));
	updateTime();
	layout.addView(time);
	
	var more = new android.widget.Button(ctx);
	more.setText("...");
	more.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
			openMore(ctx, more.getLeft(), more.getTop()+more.getHeight());
		}
	}));
	layout.addView(more);
	
	var menu = new android.widget.PopupWindow(layout, -2, -2);
	btnMenu = menu;
	//menu.setContentView(layout);
	//menu.setWidth(-2);
	//menu.setHeight(-2);
	menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 0, 0);
}

function addToArray(arr, sindex, entries){
    for(var i=0;i<entries.length;i++)
        arr[sindex+i] = entries[i];
}

function name2id(name){
    if(name == "Chicken") return 10;
    if(name == "Cow") return 11;
    if(name == "Pig") return 12;
    if(name == "Sheep") return 13;
    
    if(name == "Zombie") return 32;
    if(name == "Creeper") return 33;
    if(name == "Skeleton") return 34;
    if(name == "Spider") return 35;
    if(name == "Zombie Pigman") return 36;
    
    if(name == "Dropped item") return 64;
    if(name == "Primed TNT") return 65;
    
    if(name == "Arrow") return 80;
    if(name == "Snowball") return 81;
    if(name == "Egg") return 82;
    if(name == "Painting") return 83;
    
    return -1;
}

function openMore(ctx, x, y){
    //var menu = new android.widget.PopupWindow();
    //menu.setFocusable(true);
	//btnMenuSub = menu;
	
	var scroll = new android.widget.ScrollView(ctx);
	var layout = new android.widget.LinearLayout(ctx);
	layout.setOrientation(1);
	
	var killBtn = new android.widget.Button(ctx);
	killBtn.setText("Suicidio");
    killBtn.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
		    Player.setHealth(0);
		}
	}));
	layout.addView(killBtn);
	
	var spawnBtn = new android.widget.Button(ctx);
	spawnBtn.setText("Cambiar Spawn");
	spawnBtn.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
		    Level.setSpawn(Player.getX(), Player.getY(), Player.getZ());
		    android.widget.Toast.makeText(ctx, "Su Spawn se ha ajustado en la posición actual.", 0).show();
		}
	}));
	layout.addView(spawnBtn);
	
	var rideBtn = new android.widget.Button(ctx);
	rideBtn.setText("Montar Animal");
	rideBtn.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
		    ride = true;
		    android.widget.Toast.makeText(ctx, "Toque en el animal que desea montar.", 0).show();
		}
	}));
	layout.addView(rideBtn);
	
	var entBtn = new android.widget.Button(ctx);
	entBtn.setText("gestor de entidades");
	entBtn.setOnClickListener(new android.view.View.OnClickListener({
        onClick: function(viewarg) {
            try{
                var arr = java.lang.reflect.Array.newInstance(java.lang.CharSequence, 6);
                arr[0] = "Entidades de Spawn de tipo ...";
                arr[1] = "Edad todos los animales de tipo ...";
                arr[2] = "Establecer todas las entidades al fuego de tipo ...";
                arr[3] = "Retire todas las entidades del tipo ...";
                arr[4] = "Hacer mobs débiles de tipo ...";
                arr[5] = "Hacer turbas ultra fuerte de tipo ...";
                
                var builder = new android.app.AlertDialog.Builder(ctx);
                builder.setTitle("gestor de entidades");
                builder.setItems(arr, new android.content.DialogInterface.OnClickListener({
                    onClick: function(dialog, which) {
                        atotal = 4;
                        if(which == 0){
                            atotal = 13;
                        }else if(which == 2){
                            atotal = 10;
                        }else if(which == 3){
                            atotal = 16;
                        }else if(which == 4 || which == 5){
                            atotal = 9;
                        }
                        var arre = java.lang.reflect.Array.newInstance(java.lang.CharSequence, atotal);
                        var currAdded = 4;
                        addToArray(arre, 0, ["Chicken", "Cow", "Pig", "Sheep"]);
                        
                        if(which == 0 || which == 2 || which == 3 || which == 4 || which == 5) {
                            addToArray(arre, currAdded, ["Zombie", "Creeper", "Skeleton", "Spider", "Zombie Pigman"]);
                            currAdded += 5;
                        }
                        
                        if(which == 2 || which == 3) {
                            addToArray(arre, currAdded, ["Dropped item"]);
                            currAdded += 1;
                        }
                        
                        if(which == 0){
                            addToArray(arre, currAdded, ["Primed TNT", "Arrow", "Snowball", "Egg"]);
                            currAdded += 4;
                        }
                        
                        if(which == 3) {
                            addToArray(arre, currAdded, ["Primed TNT", "Falling block", "Arrow", "Snowball", "Egg", "Painting"]);
                            currAdded += 6;
                        }
                        
                        var builder2 = new android.app.AlertDialog.Builder(ctx);
                        builder2.setTitle("Seleccione el tipo de entidad...");
                        builder2.setItems(arre, new android.content.DialogInterface.OnClickListener({
                            onClick: function(dialog2, which2) {
                                var eId = name2id(arre[which2]);
                                if(which == 0){
                                    spawnOnTap = eId;
                                    clientMessage("Toque en los bloques para desovar entidades. Para dejar de tocar el botón principal.");
                                }else if(which == 1){
                                    var aarr = java.lang.reflect.Array.newInstance(java.lang.CharSequence, 2);
                                    aarr[0] = "Baby";
                                    aarr[1] = "Full-grown";
                                    
                                    var builder3 = new android.app.AlertDialog.Builder(ctx);
                                    builder3.setTitle("Age");
                                    builder3.setItems(aarr, new android.content.DialogInterface.OnClickListener({
                                        onClick: function(dialog3, which3) {
                                            ageAll(eId, which3==0?-24000:0);
                                        }
                                    }));
                                    builder3.show();
                                }else if(which == 2){
                                    fireAll(eId, 10);
                                }else if(which == 3){
                                    killAll(eId);
                                }else if(which == 4){
                                    healAll(eId, 1);
                                }else if(which == 5){
                                    healAll(eId, 50);
                                }
                            }
                        }));
                        builder2.show();
                    }
                }));
                builder.show();
		    }catch(err){
		        print("e/"+err);
		    }
		}
	}));
	layout.addView(entBtn);
	
	var placeBtn = new android.widget.Button(ctx);
	placeBtn.setText("Select button position");
	placeBtn.setOnClickListener(new android.view.View.OnClickListener({
		onClick: function(viewarg) {
		    try{
			var arr = java.lang.reflect.Array.newInstance(java.lang.CharSequence, 4);
			arr[0] = "Top-left corner, below heart bar";
			arr[1] = "Top-right corner, after chat button";
			arr[2] = "Bottom-left corner";
			arr[3] = "Bottom-right corner";
			
			var builder = new android.app.AlertDialog.Builder(ctx);
			builder.setTitle("Button position");
			builder.setItems(arr, new android.content.DialogInterface.OnClickListener({
                onClick: function(dialog, which) {
                    ModPE.saveData("btnPos", which);
                    android.widget.Toast.makeText(ctx, "Reload the world to apply.", 0).show();
                }
            }));
            builder.show();
		    }catch(err){
		        print("e/"+err);
		    }
		}
	}));
	layout.addView(placeBtn);
	scroll.addView(layout);
	
	var menu = new android.widget.PopupWindow(scroll, dip2px(ctx,150), dip2px(ctx,150));
    menu.setFocusable(true);
	btnMenuSub = menu;
	//menu.setContentView(layout);
	//menu.setWidth(dip2px(ctx,150));
	//menu.setHeight(dip2px(ctx,250));
	menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.GRAY));
	menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, x, y);
}

function openMenu(){
	var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
	try{
	    showButtons(ctx);
		//var menu = new android.widget.PopupWindow();
		//menu.setFocusable(true);
		//mainMenu = menu;
		
		var layout = new android.widget.LinearLayout(ctx);
		layout.setOrientation(1);
		
		
		var textParams = new android.widget.LinearLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
		textParams.setMargins(dip2px(ctx, 5), 0, 0, 0);
		var title = new android.widget.TextView(ctx);
		title.setTextSize(24);
		title.setText("Too Many Items");
		title.setLayoutParams(textParams);
		layout.addView(title);
		var stitle = new android.widget.TextView(ctx);
		stitle.setTextSize(14);
		stitle.setText("V. Mxmod by:Elcoshiloco");
		stitle.setLayoutParams(textParams);
		layout.addView(stitle);
		addMenuCategory(ctx, layout, "Kit de Inicio", CAT_STARTER_KIT_ITEMS);
		addMenuCategory(ctx, layout, "Bloques de Construcción", CAT_BUILDING_ITEMS);
		addMenuCategory(ctx, layout, "Bloques de Decoración", CAT_DECORATION_ITEMS);
		addMenuCategory(ctx, layout, "Armadura", CAT_ARMOUR_ITEMS);
		addMenuCategory(ctx, layout, "Instrumentos", CAT_TOOLS_ITEMS);
		addMenuCategory(ctx, layout, "Comida", CAT_FOOD_ITEMS);
		addMenuCategory(ctx, layout, "Colorantes", CAT_DYES_ITEMS);
		addMenuCategory(ctx, layout, "Minerales y Artículos", CAT_ITEMS_ITEMS);
	addMenuCategory(ctx, layout,"Spawn Monstruos", CAT_MONSTER_ITEMS);
		addMenuCategory(ctx, layout,
 "Huevos de Spawn", CAT_SPAWN_ITEMS);
		addMenuCategory(ctx, layout, "Diverso", CAT_MISCELLANEOUS_ITEMS);
		addMenuCategory(ctx, layout, "Mx mod",
CAT_MX_MOD_ITEMS);
		addMenuCategory(ctx, layout, "Perzonalizado", null);
		
		var menu = new android.widget.PopupWindow(layout, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
		var mlayout = makeMenu(ctx, menu, layout, true);
		menu.setContentView(mlayout);
		//menu.setFocusable(true); <-- I can't find better solution
		mainMenu = menu;
		//menu.setContentView(mlayout);
		//btnWindow.setWidth(100);
		//menu.setWidth(ctx.getWindowManager().getDefaultDisplay().getWidth()/2);
		//menu.setHeight(ctx.getWindowManager().getDefaultDisplay().getHeight());
		menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK));
		menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
	}catch(err){
		print("No se pudo abrir el menú, ya que: "+err+".");
	}
}

function leaveGame(){
	var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
	ctx.runOnUiThread(new java.lang.Runnable({ run: function() {
		if(btnWindow != null){
			btnWindow.dismiss();
			btnWindow = null;
		}
		if(mainMenu != null){
			mainMenu.dismiss();
			mainMenu = null;
		}
		if(btnMenu != null){
			btnMenu.dismiss();
			btnMenu = null;
		}
		if(subMenu != null){
			subMenu.dismiss();
			subMenu = null;
		}
		if(infoMenu != null){
			infoMenu.dismiss();
			infoMenu = null;
		}
	}}));
	riding = false;
}

function modTick(){
	if(addToInventory){
		addItemInventory(addId, addCount, addDmg);
		addToInventory = false;
	}
	
	if(riding){
        // thanks to 500ISE
        
        var playerYaw = getYaw();
        var playerPitch = getPitch();
        //setRot(ridingAnimal, playerYaw, 0);
        var velX = -1 * Math.sin(playerYaw / 180 * Math.PI) * 0.2;
		var velZ = Math.cos(playerYaw / 180 * Math.PI) * 0.2;
		var velY = 0;
		var jumpVel = 0.2;
		if(velX > 0){
		    if (getTile(Player.getX()+1, Math.floor(Entity.getY(ridingAnimal)), Player.getZ()) != 0)
		        velY = jumpVel;
		}else{
		    if(getTile(Player.getX()-1, Math.floor(Entity.getY(ridingAnimal)), Player.getZ()) != 0)
		        velY = jumpVel;
		}
		
		if(velZ > 0){
		    if(getTile(Player.getX(), Math.floor(Entity.getY(ridingAnimal)), Player.getZ()+1) != 0)
		        velY = jumpVel;
		}else{
		    if(getTile(Player.getX(), Math.floor(Entity.getY(ridingAnimal)), Player.getZ()-1) != 0)
		        velY = jumpVel;
		}
		
		if(velY == 0 && getTile(Player.getX(), Player.getY()-2, Player.getZ()) == 0) velY = -jumpVel;
		//clientMessage(velY);
		//var velY = Math.sin((playerPitch - 180) / 180 * Math.PI) * ANIMAL_VERTICAL_SPEED;
		setVelX(ridingAnimal, velX);
		setVelY(ridingAnimal, velY);
		setVelZ(ridingAnimal, velZ);
	}
}


// MOB MANAGER
var entities = [];
function entityAddedHook(ent){
    entities.push(ent);
}
function entityRemovedCallback(ent){
    entities.splice(entities.indexOf(ent));
}
function killAll(entType){
    for(var i=0;i<entities.length;i++){
        if(Entity.getEntityTypeId(entities[i]) == entType){
            Entity.remove(entities[i]);
        }
    }
}
function ageAll(entType, age){
    for(var i=0;i<entities.length;i++){
        if(Entity.getEntityTypeId(entities[i]) == entType){
            Entity.setAnimalAge(entities[i], age);
        }
    }
}
function fireAll(entType, time){
    for(var i=0;i<entities.length;i++){
        if(Entity.getEntityTypeId(entities[i]) == entType){
            Entity.setFireTicks(entities[i], time);
        }
    }
}
function healAll(entType, lives){
    for(var i=0;i<entities.length;i++){
        if(Entity.getEntityTypeId(entities[i]) == entType){
            Entity.setHealth(entities[i], lives);
        }
    }
}
