//Mx mod hecho por Elcoshiloco, este mod no esta completo si no se activan los otros 2 mods. No copiar mi mod...
//Disfruten.

ModPE.langEdit("item.helmetChain.name","Bigote");
ModPE.langEdit("item.chestplateChain.name","Camisa de charro");
ModPE.langEdit("item.leggingsChain.name","Pantalones de charro");
ModPE.langEdit("item.bootsChain.name","Botas de charro");

ModPE.setFoodItem(407,"blaze_powder",0,1,"Masa");
ModPE.setFoodItem(408,"boat",0,2,"Tortilla");
ModPE.setFoodItem(409,"book_writable",0,5,"Taco");
ModPE.setFoodItem(410,"book_written",0,2,"Tomate");
ModPE.setFoodItem(411,"cauldron",0,2,"Chile");
ModPE.setFoodItem(412,"comparator",0,4,"Salsa");
ModPE.setFoodItem(413,"diamond_horse_armor",0,7,"Taco con salsa");
ModPE.setFoodItem(414,"experience_bottle",0,8,"Torta");ModPE.setFoodItem(415,"fireball",0,4,"Tamal");ModPE.setFoodItem(416,"fireworks",0,8,"Tamal cocido");ModPE.setFoodItem(417,"fireworks_charge",0,6,"Coca-Cola");ModPE.setFoodItem(418,"fireworks_charge_overlay",0,6,"Cerveza");ModPE.setFoodItem(419,"fishing_rod_cast",0,6,"Tequila");ModPE.setItem(420,"fishing_rod_uncast",0,"Tarro");ModPE.setItem(421,"flower_pot",0,"Machete");ModPE.setItem(422,"ghast_tear",0,"Filero");
ModPE.setItem(424,"gold_horse_armor",0,"Botella vacia");
ModPE.setItem(425,"iron_horse_armor",0,"Lata vacía");
ModPE.setItem(426,"magma_cream",0,"Botella con agua");
ModPE.setItem(427,"map_empty",0,"Tarro con agua");
ModPE.setItem(428,"map_filled",0,"Morral");
ModPE.setFoodItem(429,"minecart_chest",0,1,"Maíz");
ModPE.setItem(430,"hopper",0,"Cebada");
ModPE.setItem(431,"minecart_furnace",0,"Agave");

Item.addCraftRecipe(351, 1, 0,[423, 4, 0, 318, 1, 0]);
Item.addCraftRecipe(303, 1, 0,[35, 1, 15, 423, 1, 0, 35, 1, 15, 264, 1, 0, 35, 1, 0, 264, 1, 0, 35, 1, 15, 35, 1, 0, 35, 1, 15]);
Item.addCraftRecipe(304, 1, 0,[35, 1, 15, 266, 1, 0, 35, 1, 15, 264, 1, 0, 423, 1, 0, 264, 1, 0, 35, 1, 15, 423, 1, 0, 35, 1, 15]);
Item.addCraftRecipe(305, 1, 0,[423, 3, 0, 35, 1, 15, 423, 1, 0, 35, 2, 15, 423, 1, 0, 35, 1, 15]);
Item.addCraftRecipe(302, 1, 0,[35, 1, 15, 423, 1, 0, 35, 4, 15]);
Item.addCraftRecipe(407, 4, 0,[423, 4, 0, 429, 1, 0]);
Item.addCraftRecipe(408, 4, 0,[407, 2, 0, 423, 1, 0, 407, 2, 0]);
Item.addCraftRecipe(409, 8, 0,[408, 4, 0, 364, 1, 0, 408, 4, 0]);
Item.addCraftRecipe(412, 1, 0,[423, 1, 0, 410, 1, 0, 423, 2, 0, 411, 1, 0, 423, 2, 0, 281, 1, 0]);
Item.addCraftRecipe(413, 8, 0,[409, 4, 0, 412, 1, 0, 409, 4, 0]);
Item.addCraftRecipe(414, 2, 0,[423, 1, 0, 297, 1, 0, 423, 2, 0, 320, 1, 0, 423, 2, 0, 297, 1, 0]);
Item.addCraftRecipe(415, 2, 0,[407, 4, 0, 320, 1, 0, 407, 4, 0]);
Item.addCraftRecipe(417, 3, 0,[423, 3, 0, 318, 3, 0, 425, 3, 0]);
Item.addCraftRecipe(418, 7, 0,[427, 1, 0, 430, 1, 0, 427, 2, 0, 430, 1, 0, 427, 4, 0]);
Item.addCraftRecipe(419, 3, 0,[423, 3, 0, 431, 3, 0, 426, 3, 0]);
Item.addCraftRecipe(420, 7, 0,[20, 1, 0, 423, 1, 0, 20, 2, 0, 423, 1, 0, 20, 4, 0]);
Item.addCraftRecipe(421, 1, 0,[423, 2, 0, 265, 1, 0, 423, 1, 0, 265, 2, 0, 280, 1, 0]);
Item.addCraftRecipe(422, 1, 0,[423, 4, 0, 266, 1, 0, 423, 1, 0, 265, 1, 0]);
Item.addCraftRecipe(424, 6, 0,[423, 1, 0, 20, 1, 0, 423, 1, 0, 20, 1, 0, 423, 1, 0, 20, 4, 0]);
Item.addCraftRecipe(425, 6, 0,[265, 2, 0, 423, 1, 0, 265, 2, 0]);
Item.addCraftRecipe(428, 1, 0,[334, 4, 0, 54, 1, 0, 334, 4, 0]);
Item.addFurnaceRecipe(415,416);

function attackHook(attacker, victim) {function hurt(health) {if(Entity.getHealth(victim) > health) Entity.setHealth(victim, Entity.getHealth(victim) - health);
else {
Entity.setHealth(victim, 1);
}
}
var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(attacker == Player.getEntity()) switch(Player.getCarriedItem()) {
case 421:
hurt(9);
break;
}
var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(attacker == Player.getEntity()) switch(Player.getCarriedItem()) {
case 422:
hurt(6);
break;
}
}


var zombiemariachi;
var zombiemariachi; 
var randomspawn=false;
var ticks=20;
var sp=true;
var ticks2=40;

var startGame = 0;


function deathHook(murderer, victim)
{
if(victim==zombiemariachi){
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 410, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 411, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 429, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 430, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 431, 1, 0);
}
} 
var alea;
var unstuck=-1
var time;
var zombiemariachi;
var pitch;
var yaw;
var orX;
var orY;

function modTick()
{
alea=Math.floor((Math.random()*650)+1);
time = Level.getTime()-Math.floor(Level.getTime()/19200)*19200;
if(time<(19200/2))
{
}
else
{
if(alea==1)
{
pitch = ((Entity.getPitch(getPlayerEnt()) + 90) * Math.PI)/180;
yaw = ((Entity.getYaw(getPlayerEnt()) + 90) * Math.PI)/180;
orX = Math.sin(pitch) * Math.cos(yaw);
orZ = Math.sin(pitch) * Math.sin(yaw);
zombiemariachi = Level.spawnMob(getPlayerX()-(20*orX), getPlayerY(), getPlayerZ()-(20*orZ), 32, "mob/zombiemariachi.png");//Change the texture :D
unstuck=20;
}
}
if(unstuck>=1)
{
unstuck--;
if(getTile(Entity.getX(zombiemariachi),Entity.getY(zombiemariachi), Entity.getZ(zombiemariachi))!=0)
{
setPosition(Entity.getX(zombiemariachi),Entity.getY(zombiemariachi)+1,Entity.getZ(zombiemariachi))
}
}
if(unstuck==0)
{
unstuck=-1;
}
}


function useItem(x, y, z, itemId, blockId) {

if (itemId==420) {
if(getTile(x, y+1, z) == 8 || getTile (x, y+1, z) == 9) {
	preventDefault();
	var random3 = Math.floor((Math.random()*5)+1);
	addItemInventory(420, -1);
	addItemInventory(427, 1);
	}
	}
if (itemId==424) {
if(getTile(x, y+1, z) == 8 || getTile (x, y+1, z) == 9) {
	preventDefault();
	var random3 = Math.floor((Math.random()*5)+1);
	addItemInventory(424, -1);
	addItemInventory(426, 1);
}
}
} 