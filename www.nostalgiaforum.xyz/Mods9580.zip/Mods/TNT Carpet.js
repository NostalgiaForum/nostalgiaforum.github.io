﻿//TNT Carpet TBPM® No copy Coppyright
 
function newLevel()
{ 
Block.setShape(46,0,0,0,1,1/10,1) //Block.defineBlock(430,"beta block",[[1,3],[1,3],[1,3],[1,3],[1,3],[1,3]],430,false,0) 
}
