//Plsss Read The Readme.txt for Info
var firepunch = 0;
var throwpunch = 0;
var killpunch = 0;
var explodingpunch = 0;
var regeneratingpunch = 0;
var destroyblockpunch = 0;
var ridepunch = 0;
var hardpunch = 0;
var webpunch = 0;
var waterpunch = 0;
var lavapunch = 0;
var diamondpunch = 0;
var extraweb = 0;

function useItem(x, y, z, itemId, blockId, side)
{
if(destroyblockpunch == 1)
Level.destroyBlock (x, y, z, true)

}

function procCmd(cmd){
if (cmd=="fire punch"){
firepunch = 1;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Fire Punch Selected");}
else if (cmd=="throw punch"){
firepunch = 0;
throwpunch = 1;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Throw Punch Selected");}
else if (cmd=="kill punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 1;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Kill Punch Selected");}
else if (cmd=="exploding punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 1;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Exploding Punch Selected");}
else if (cmd=="restart"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Powerfull Fists Has Restart Punches");}
else if (cmd=="regenerating punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 1;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Regenerating Punch Selected");}
else if (cmd=="fun punch"){
firepunch = 1;
throwpunch = 1;
killpunch = 1;
explodingpunch = 1;
regeneratingpunch = 1;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("You Are Now Using The Fun Punch So Every Type Of Punch Are Selected");}
else if (cmd=="destroy punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 1;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Destroy Block Punch Selected");}
else if (cmd=="ride punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 1;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Ride Punch Selected");}
else if (cmd=="hard punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 1;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Hard Punch Selected");}
else if (cmd=="help punch"){
clientMessage("List Of Punches");
clientMessage(" /fire punch");
clientMessage(" /throw punch");
clientMessage(" /exploding punch");
clientMessage(" /diamond punch");
clientMessage(" /regenerating punch");}
else if (cmd=="help punch 2"){
clientMessage(" /fun punch");
clientMessage(" /destroy punch");
clientMessage(" /ride punch");
clientMessage(" /hard punch");
clientMessage(" /water punch");
clientMessage(" /lava punch");
clientMessagr(" /web punch");}
else if (cmd=="web punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 1;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 0;
extraweb = 1;
clientMessage("Web Punch Selected");}
else if (cmd=="water punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 1;
lavapunch = 0;
diamondpunch = 0;
extraweb = 0;
clientMessage("Water Punch Selected");}
else if (cmd=="lava punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 1;
diamondpunch = 0;
extraweb = 0;
clientMessage("Lava Punch Selected");}
else if (cmd=="diamond punch"){
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
destroyblockpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lavapunch = 0;
diamondpunch = 1;
extraweb = 0;
clientMessage("Diamond Punch Selected");
}
}

function attackHook(attacker, victim)
{
var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);

if(firepunch == 1)
{
Entity.setFireTicks(victim,2000);
}

{
if(throwpunch == 1)
preventDefault();
Entity.setVelY(victim,10);
}

{
if(killpunch == 1)
Entity.setHealth(victim, 1);
}

{
if(explodingpunch == 1)
Level.explode(x, y, z, 1);
}

{
if(regeneratingpunch == 1)
Entity.setHealth(attacker, 20);
}

{
if(ridepunch == 1)
rideAnimal(attacker, victim);
}

{
if(hardpunch == 1)
Entity.setHealth(victim, 20);
}

{
if(webpunch == 1)
setTile(x,y,z, 30);
}

{
if(waterpunch == 1)
setTile(x,y,z, 9);
}

{
if(lavapunch == 1)
setTile(x,y,z, 11);
}

{
if(diamondpunch == 1)
Level.dropItem(x,y,z,0,264,1);
}

{
if(extraweb == 1)
setTile(x,y+1,z, 30);
}

}

function leaveGame() {
firepunch = 0;
throwpunch = 0;
killpunch = 0;
explodingpunch = 0;
regeneratingpunch = 0;
ridepunch = 0;
hardpunch = 0;
webpunch = 0;
waterpunch = 0;
lava punch = 0;
extraweb = 0;
}