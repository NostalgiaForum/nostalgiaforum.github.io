/*
If anyone share you need to put forum link or the link of my channel of Youtube <http://www.youtube.com/theendermengamer>
EnderGamer Script (C) GNC copyright
Copyright (C) <2014>  <EnderGamer>

This work is licensed under the Creative Commons Attribution- NonCommercial 4.0 International License. To view a copy
of this license, visit http://creativecommons.org/licenses/by-nc/4.0/ or send a letter to Creative Commons, 444 Castro
Street, Suite 900, Mountain View, California, 94041, USA.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/* ******* More Sword Mod By TheEndermenGamer ******* */

//Creative

Player.addItemCreativeInv(476,1,0);

Player.addItemCreativeInv(478,1,0);

Player.addItemCreativeInv(475,1,0);

Player.addItemCreativeInv(335,1,0);

Player.addItemCreativeInv(479,1,0);

Player.addItemCreativeInv(380,1,0);

Player.addItemCreativeInv(350,1,0);

Player.addItemCreativeInv(410,1,0);

//Other

var ores_sword = 350;

var oreIds = [21, 14, 16, 15, 56];

var oreNames = ["Lapis Lazuli", "Gold", "Coal", "Iron", "Diamond"];

//Items

ModPE.setItem(476,"spider_eye",0,"Explosive Sword",1);

ModPE.setItem(410,"record_11",0,"Bouncing Sword",1);

ModPE.setItem(478,"iron_horse_armor",0,"Flamme Sword",1);

ModPE.setItem(475,"diamond_horse_armor",0,"Life Sword",1);

ModPE.setItem(335,"spider_eye_fermented",0,"Lava Sword",1);

ModPE.setItem(479,"lead",0,"Water Sword",1);

ModPE.setItem(380,"cauldron",0,"Master Sword",1);

ModPE.setItem(350,"record_cat",0,"Ore Sword",1);

//Crafts

Item.addCraftRecipe(414, 1, 0, [ 700, 1, 0,287, 1, 0, 700, 1, 0, 700, 1, 0,287, 1, 0, 700, 1, 0, 700, 1, 0,280, 1, 0, 700, 1, 0]);

Item.addCraftRecipe(476, 1, 0, [ 700, 1, 0,46, 1, 0, 700, 1, 0, 700, 1, 0,46, 1, 0, 700, 1, 0, 700, 1, 0,280, 1, 0, 700, 1, 0]);

Item.addCraftRecipe(478, 1, 0, [ 700, 1, 0,259, 1, 0, 700, 1, 0, 700, 1, 0,259, 1, 0, 700, 1, 0, 700, 1, 0,280, 1, 0, 700, 1, 0]);

Item.addCraftRecipe(475, 1, 0, [ 700, 1, 0,260, 1, 0, 700, 1, 0, 700, 1, 0,260, 1, 0, 700, 1, 0, 700, 1, 0,280, 1, 0, 700, 1, 0]);

Item.addCraftRecipe(335, 1, 0, [ 700, 1, 0,325, 1, 10, 700, 1, 0, 700, 1, 0,325, 1, 10, 700, 1, 0, 700, 1, 0,280, 1, 0, 700, 1, 0]);

Item.addCraftRecipe(479, 1, 0, [ 700, 1, 0,325, 1, 8, 700, 1, 0, 700, 1, 0,325, 1, 8, 700, 1, 0, 700, 1, 0,280, 1, 0, 700, 1, 0]);

Item.addCraftRecipe(380, 1, 0, [ 700, 1, 0,49, 1, 0, 700, 1, 0, 700, 1, 0,49, 1, 0, 700, 1, 0, 700, 1, 0,280, 1, 0, 700, 1, 0]);

Item.addCraftRecipe(350, 1, 0, [ 700, 1, 0,265, 1, 0, 700, 1, 0, 700, 1, 0,265, 1, 0, 700, 1, 0, 700, 1, 0,280, 1, 0, 700, 1, 0]);
//Code

function useItem(x,y,z,itemId,blockId,side) 
{
if(itemId == ores_sword) 
{
bestValue = -1;
for(var i = 0;i <= y;i++)
{
var bestXYZ;
var tile = getTile(x, i, z);
if (tile == oreIds[0]) 
{
if (bestValue < 0)
{
bestValue = 0;
bestXYZ = ("X: " + x + " Y: " + i + " Z: " + z);
}
} 
else if (tile == oreIds[1]) 
{
if (bestValue < 1) 
{
bestValue = 1;
bestXYZ = ("X: " + x + " Y: " + i + " Z: " + z);
}
}
else if (tile == oreIds[2]) 
{
if (bestValue < 2) 
{
bestValue = 2;
bestXYZ = ("X: " + x + " Y: " + i + " Z: " + z);
}
} 
else if (tile == oreIds[3]) 
{
if (bestValue < 3) 
{
bestValue = 3;
bestXYZ = ("X: " + x + " Y: " + i + " Z: " + z);
}
} 
else if (tile == oreIds[4]) {;
bestValue = 4;
bestXYZ = ("X: " + x + " Y: " + i + " Z: " + z);
break;
}
}
if(bestValue == -1)
{
clientMessage(ChatColor.RED + "No ores found");
} 
else 
{
clientMessage(ChatColor.GREEN + "Found " + oreNames[bestValue] + " " + bestXYZ);
}
}
}
function newLevel()
{
clientMessage(ChatColor.GREEN + "Mo'Swords Mod !");
clientMessage(ChatColor.WHITE + "Mod make by " + ChatColor.LIGHT_PURPLE + "@GamerEndermen");
}
function attackHook(attacker,victim)
{
if(getCarriedItem()==476)//Explosive Sword
{
explode(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 5);
Player.setHealth(20);
}
if(getCarriedItem()==478)//Flammes Sword
{
Entity.setFireTicks(victim,10);
}
if(getCarriedItem()==475&&Entity.getHealth(Player.getEntity()) <= 19)//Heal Sword
{
Player.setHealth(Entity.getHealth(Player.getEntity())+1);
}
if (getCarriedItem()==335) //Lava Sword
{
setTile(Entity.getX(victim),Entity.getY(victim)+1,Entity.getZ(victim),10);
}
if (getCarriedItem()==479) //Water Sword
{
setTile(Entity.getX(victim),Entity.getY(victim)+1,Entity.getZ(victim),8);
}
if (getCarriedItem()==380) //Master Sword
{
Entity.setHealth(victim,1);
}
if(Player.getCarriedItem()==410)
{
preventDefault();
Entity.setVelY(victim,3);
setTile(Entity.getX(victim),Entity.getY(victim)+1,Entity.getZ(victim),155,0);
Level.destroyBlock(Entity.getX(victim),Entity.getY(victim)+1,Entity.getZ(victim),false);
}
}
function procCmd(cmd)
{
var command = cmd.split(" ");
  
if(command[0] == "swords")
{
addItemInventory(476,1);
addItemInventory(478,1);
addItemInventory(475,1);
addItemInventory(335,1);
addItemInventory(479,1);
addItemInventory(350,1);
addItemInventory(380,1);
addItemInventory(410,1);
}
}