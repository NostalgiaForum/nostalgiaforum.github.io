var countdown = 500;
var steve;
var stevem = 0;
var stevef = 0;
var feel = Math.floor((Math.random() * 5) + 1);

function useItem(x,y,z,itemId,blockId)
{
if(itemId==280)
{
stevem = 1;
steve = Level.spawnMob(x, y + 1, z, 11, "mob/char.png");
Entity.setRenderType(steve, 3);
Entity.setHealth(steve, 20);
clientMessage("<server> Steve Joined The Game");
}
}

function attackHook(attacker,victim)
{
if(victim==steve&&getCarriedItem()!=266&&getCarriedItem()!=38)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
}
else if(victim==steve&&stevef==0&&getCarriedItem()==266)
{
stevef = 1;
clientMessage("<Steve> Give Me That!");
preventDefault();
}
else if(victim==steve&&getCarriedItem()==38&&feel==1)
{
preventDefault();
clientMessage("Steve Is Feeling Happy!");
feel = Math.floor((Math.random() * 5) + 1);
}
else if(victim==steve&&getCarriedItem()==38&&feel==2)
{
preventDefault();
clientMessage("Steve Is Feeling Scared!");
feel = Math.floor((Math.random() * 5) + 1);
}
else if(victim==steve&&getCarriedItem()==38&&feel==3)
{
preventDefault();
clientMessage("Steve Is Feeling Angry!");
feel = Math.floor((Math.random() * 5) + 1);
}
else if(victim==steve&&getCarriedItem()==38&&feel==4)
{
preventDefault();
clientMessage("Steve Is Feeling Sad!");
feel = Math.floor((Math.random() * 5) + 1);
}
else if(victim==steve&&getCarriedItem()==38&&feel==5)
{
preventDefault();
clientMessage("Steve Is Neutral!");
feel = Math.floor((Math.random() * 5) + 1);
}
else if(victim==steve&&getCarriedItem()==266&&stevef==1)
{
stevef = 0;
clientMessage("<Steve> I Don't want that anymore!");
preventDefault();
}
}

function modTick()
{
if(stevem==1)
{
countdown--;
var fws = Math.floor ((Math.random() * 20) + 1);
{
if(countdown==0&&fws==1)
{
clientMessage("<Steve> Hello");
countdown = 500;
}
else if(countdown==0&&fws==2)
{
clientMessage("<Steve> I Have A Diamond");
countdown = 500;
}
else if(countdown==0&&fws==3)
{
clientMessage("<Steve> I Am Bored");
countdown = 500;
}
else if(countdown==0&&fws==4)
{
clientMessage("<Steve> Can I Have Your House?");
countdown = 500;
}
else if(countdown==0&&fws==5)
{
clientMessage("<Steve> I Have 2 Hearts!");
countdown = 500;
}
else if(countdown==0&&fws==6)
{
clientMessage("<Steve> I Went Mining And Got Coal");
countdown = 500;
}
else if(countdown==0&&fws==7)
{
clientMessage("<Steve> I Don't Have A House!");
countdown = 500;
}
else if(countdown==0&&fws==8)
{
clientMessage("<Steve> Wood Tools Rule!");
countdown = 500;
}
else if(countdown==0&&fws==9)
{
clientMessage("<Steve> Minecraft Is Stupid!");
countdown = 500;
}
else if(countdown==0&&fws==10)
{
clientMessage("<Steve> YOLOSWAG");
countdown = 500;
}
else if(countdown==0&&fws==11)
{
clientMessage("<Steve> Do You Have Food?");
countdown = 500;
}
else if(countdown==0&&fws==12)
{
clientMessage("<Steve> Want To Start A Clan With Me?");
countdown = 500;
}
else if(countdown==0&&fws==13)
{
clientMessage("<Steve> I Am A Boss At Minecraft!");
countdown = 500;
}
else if(countdown==0&&fws==14)
{
clientMessage("<Steve> Diamond Tools Suck!");
countdown = 500;
}
else if(countdown==0&&fws==15)
{
clientMessage("<Steve> I Don't Know How To Build");
countdown = 500;
}
else if(countdown==0&&fws==16)
{
clientMessage("<Steve> I Saw A Villager");
countdown = 500;
}
else if(countdown==0&&fws==17)
{
clientMessage("<Steve> THIS IS SPARTA!");
countdown = 500;
}
else if(countdown==0&&fws==18)
{
clientMessage("<Steve> I Like Terraria");
countdown = 500;
}
else if(countdown==0&&fws==19)
{
clientMessage("<Steve> I Wish I Had Milk...");
countdown = 500;
}
else if(countdown==0&&fws==20)
{
clientMessage("<Steve> I Need A Mushroom");
countdown = 500;
}
}
}
else if(stevem == 0) return;
if (stevef == 1)
{
if (Math.sqrt(Math.pow(Player.getX() - Entity.getX(steve), 2) +  Math.pow(Player.getZ() - Entity.getZ(steve), 2)) < 5) return;
var angle = Math.atan2((Player.getZ() - Entity.getZ(steve)), (Player.getX() - Entity.getX(steve)));
Entity.setVelX(steve,(Math.cos(angle) * 0.2));
Entity.setVelZ(steve,(Math.sin(angle) * 0.2));
Entity.setRot(steve, (((angle * 180) / Math.PI) - 90), Entity.getPitch(steve));
} 
}

function deathHook(attacker, victim)
{
if(victim==steve)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 3, 37, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 270, 1, 15);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 263, 19, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 290, 1, 31);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 264, 1, 0);
stevef = 0;
stevem = 0;
clientMessage("<server> Steve Left The Game");
}
}


