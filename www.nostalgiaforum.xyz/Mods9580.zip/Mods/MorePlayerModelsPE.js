function procCmd(cmd)
{
    var cmd = cmd.split(" ");
{
   if(cmd[0]=="be"&&cmd[1]=="chicken")
  {
    Entity.setRenderType(getPlayerEnt(),6);
    Entity.setMobSkin(getPlayerEnt(), "mob/chicken.png");
  }else if(cmd[0]=="be"&&cmd[1]=="cow")
{
    Entity.setRenderType(getPlayerEnt(),7);
    Entity.setMobSkin(getPlayerEnt(), "mob/cow.png");
}else if(cmd[0]=="be"&&cmd[1]=="pig")
  {
    Entity.setRenderType(getPlayerEnt(),8);
    Entity.setMobSkin(getPlayerEnt(), "mob/pig.png");
  }else if(cmd[0]=="be"&&cmd[1]=="sheep")
{
    Entity.setRenderType(getPlayerEnt(),9);
    Entity.setMobSkin(getPlayerEnt(), "mob/sheep.png");
}else if(cmd[0]=="be"&&cmd[1]=="zombie")
{
    Entity.setRenderType(getPlayerEnt(),11);
    Entity.setMobSkin(getPlayerEnt(), "mob/zombie.png");
}else if(cmd[0]=="be"&&cmd[1]=="skeleton")
{
    Entity.setRenderType(getPlayerEnt(),12);
    Entity.setMobSkin(getPlayerEnt(), "mob/skeleton.png");
}else if(cmd[0]=="be"&&cmd[1]=="spider")
{
    Entity.setRenderType(getPlayerEnt(),13);
    Entity.setMobSkin(getPlayerEnt(), "mob/spider.png");
}else if(cmd[0]=="be"&&cmd[1]=="creeper")
{
    Entity.setRenderType(getPlayerEnt(),14);
    Entity.setMobSkin(getPlayerEnt(), "mob/creeper.png");
}else if(cmd[0]=="be"&&cmd[1]=="player")
{
    Entity.setRenderType(getPlayerEnt(),3);
    Entity.setMobSkin(getPlayerEnt(), "mob/player.png");
}else if(cmd[0]=="be"&&cmd[1]=="zombiepigmen")
{
    Entity.setRenderType(getPlayerEnt(),11);
    Entity.setMobSkin(getPlayerEnt(), "mob/zombiepig.png");
}
}
}