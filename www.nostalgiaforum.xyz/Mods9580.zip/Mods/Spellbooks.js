/*Spellbooks Mod */

ModPE.setItem(451, "book_enchanted", 0, "§4Dragon Flames");
ModPE.setItem(452, "book_enchanted", 0, "§eRising Sun");
ModPE.setItem(453, "book_enchanted", 0, "§3Hands of Death");
ModPE.setItem(454, "book_enchanted", 0, "§5Dusk of Night");
ModPE.setItem(455, "book_enchanted", 0, "§bBlessing of Angels");
ModPE.setItem(456, "book_enchanted", 0, "§aNature's Gift");
ModPE.setItem(457, "book_enchanted", 0, "§7Necronomicon");
ModPE.setItem(458, "book_enchanted", 0, "§6Potato Rain");
ModPE.setItem(459, "book_enchanted", 0, "§2Dynamic Toss");
ModPE.setItem(460, "book_enchanted", 0, "§cExplosive Wrath");
ModPE.setItem(461, "book_enchanted", 0, "§9Water Splash");
ModPE.setItem(462, "book_enchanted", 0, "§eBlock Destroyer");

function attackHook(attacker, victim){

if(getCarriedItem()==451){

Entity.setFireTicks (victim, 60)

}else if(getCarriedItem()==453){

Entity.setHealth(victim, 0)

}else if(getCarriedItem()==459){

setPositionRelative(victim, 0, 50, 0) 

}else if(getCarriedItem()==460){

explode(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 5)

}else if(getCarriedItem()==461){

setTile(Entity.getX(victim),Entity.getY(victim)+1,Entity.getZ(victim),8)

}

}

function useItem (x, y, z, item, block, side){

if(item == 452){

Level.setTime(0)
clientMessage("§eThe rising sun compells the darkness...")
 
}else if(getCarriedItem()==454){

Level.setTime(14000)
clientMessage("§7The darkness is coming...")

}else if(getCarriedItem()==455){

Player.setHealth(20)
clientMessage("§bAll of your wounds have been healed..")

}else if(getCarriedItem()==456){

setTile(x, y, z, 17, 0)

}else if(getCarriedItem()==462){

setTile(x, y, z, 0, 0)

}else if(getCarriedItem()==457){

Level.spawnMob(x, y, z, 32, 'zombie.png')
Entity.setMobSkin(32, 'zombie.png')

}else if(getCarriedItem()==458){
		preventDefault();
		Level.dropItem(x,y+5,z,0,392,10);
		Level.dropItem(x-1,y+5,z,0,392,5);
		Level.dropItem(x-1,y+5,z+1,0,392,5);
		Level.dropItem(x,y+5,z-1,0,392,5);
		Level.dropItem(x,y+5,z+1,0,392,5);
		Level.dropItem(x-1,y+5,z-1,0,392,5);
		Level.dropItem(x+1,y+5,z+1,0,392,5);
		Level.dropItem(x+1,y+5,z,0,392,5);
		Level.dropItem(x+1,y+5,z+1,0,392,5); 
		
		}
		
}

function newLevel(){

clientMessage("§4Spellbooks Mod")
clientMessage("§bBy The Blue Bomber")

}

function procCmd(cmd){

var command = cmd.split(" ");

if(command[0] == "spellbooks"){

addItemInventory(451, 1);
addItemInventory(452, 1);
addItemInventory(453, 1);
addItemInventory(454, 1);
addItemInventory(455, 1);
addItemInventory(456, 1);
addItemInventory(457, 1);
addItemInventory(458, 1);
addItemInventory(459, 1);
addItemInventory(460, 1);
addItemInventory(461, 1);
addItemInventory(462, 1);
clientMessage("§dYou got all of the spellbooks!")

}

}