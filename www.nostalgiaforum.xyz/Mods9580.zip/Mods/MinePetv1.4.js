/*MinePet v1*/

pet = false;
sound = false;
count = 0;
timer = false;
digcount = 0;
digtimer = false;
attacktimer = false;
attackcount = 0;

function entityAddetHook (e){
  if(Entity.getEntityTypeId(e)==80){
  }
   arrow = e;
}


function useItem(x, y, z, itemId, blockId, side)
{
if (pet==true){
if (itemId==0){
digtimer = true;
dx = x;
dy = y;
dz = z;
Level.playSound(dx, dy, dz,"random.bow", 30, 1);
sound = true;
}
}

}

function attackHook(attacker, victim)
{
if (getCarriedItem ()==0){
if (victim==guard){
if (pet==true){
   pet = false;
   guard = null;
   clientMessage ("<Pet> Im waiting here 4 u!");
}
}
}
if (pet==true){
if(Entity.getEntityTypeId(victim) != id) {
enemy = victim;
vx = Entity.getX (enemy);
vy = Entity.getY (enemy);
vz = Entity.getZ (enemy);
attacktimer = true;
timer = false;
count = 0;
}
} else if (pet==false){
   if (getCarriedItem()==352){
   guard = victim;
   id = Entity.getEntityTypeId ( guard);
   clientMessage ("<Pet> Ur my new Master!");
    Level.playSound ( getPlayerX (), getPlayerY (), getPlayerZ (),"random.burp", 30, 1);
   pet = true;
}
}

}

function modTick()
{

if (count==60){

Entity.setPosition (guard,   getPlayerX()-3,  getPlayerY()-1.6, getPlayerZ()-1);
Entity.setHealth ( guard, 1000);
count = 0; 
}
if (timer==true){
   count ++;
}
if (digtimer==true){
     timer = false;
     count = 0;
     digcount ++;
     
     Entity.setPosition (guard, dx, dy+1, dz);
     if (sound==true){
     Level.playSound ( dx, dy, dz,"step.stone", 30, 1);
}
        }
     if (digcount==30){
      sound = false;
   }
     if (digcount==32){
      Level.destroyBlock (dx, dy, dz, true);

      }
     if (digcount==40){
      timer = true;
      count = 0;
     digcount = 0;
      digtimer = false;
     }
if (attacktimer==true){
    Entity.setPosition ( guard, Entity.getX (enemy), Entity.getY (enemy),Entity.getZ (enemy));
    attackcount ++;
     timer = false;
     count = 0;
}
if (attackcount==1){
 Level.playSound ( vx, vy, vz,"mob.bow", 30, 1);
}
if (attackcount==30){
Entity.setHealth (enemy, 0);
Level.playSound ( vx, vy, vz,"random.hurt", 30, 1);
}
if (attackcount==40){
    attacktimer = false;
    attackcount = 0;
    timer = true;
    count = 0;
}

}

function procCmd(command)
{
var cmd = command.split(" ");
if(cmd[0] == "tamer")
{
addItemInventory(352, 1);
clientMessage ("Tamer got!");
}

}

function newLevel()
{
pet = false;
guard = null;
timer = true;

}

function leaveGame()
{
count = 0;
timer = false;

}

