function newLevel()
{
clientMessage(ChatColor.YELLOW+"More Glass Panes"+ChatColor.BLUE+"by aid")
}
Block.defineBlock(126,"Redstone Glasspane",[
["redstone_block",0],
 ["redstone_block",0],
  ["redstone_block",0] ,
  ["redstone_block",0],
   ["redstone_block",0], 
   ["redstone_block",0]],1,1,18);
Block.setDestroyTime(126,0.01)

Block.defineBlock(121,"Lapiz Lazul Glasspane",[
["lapis_block",0],
 ["lapis_block",0],
  ["lapis_block",0] ,
  ["lapis_block",0],
   ["lapis_block",0], 
   ["lapis_block",0]],1,1,18);
Block.setDestroyTime(121,0.01)

Block.defineBlock(122,"Gold Glasspane",[
["gold_block",0],
 ["gold_block",0],
  ["gold_block",0] ,
  ["gold_block",0],
   ["gold_block",0], 
   ["gold_block",0]],1,1,18);
Block.setDestroyTime(122,0.01)


Block.defineBlock(123,"Emerald Glasspane",[
["emerald_block",0],
 ["emerald_block",0],
  ["emerald_block",0] ,
  ["emerald_block",0],
   ["emerald_block",0], 
   ["emerald_block",0]],1,1,18);
Block.setDestroyTime(123,0.01)

Block.defineBlock(124,"Black Glasspane",[
["coal_block",0],
 ["coal_block",0],
  ["coal_block",0] ,
  ["coal_block",0],
   ["coal_block",0], 
   ["coal_block",0]],1,1,18);
Block.setDestroyTime(124,0.01)

Block.defineBlock(125,"Red Mushroom Glasspane",["mushroom_block_skin_red",0],true,5,18);
Block.setDestroyTime(125,0.01);


Block.defineBlock(127,"Nether Reactor Core Glasspane 1",["reactor_core_stage_x",1],true,5,18);
Block.setDestroyTime(127,0.01)

Block.defineBlock(128,"Diamond Glasspane",[
["diamond_block",0],
 ["diamond_block",0],
  ["diamond_block",0] ,
  ["diamond_block",0],
   ["diamond_block",0], 
   ["diamond_block",0]],1,1,18);
Block.setDestroyTime(128,0.01)

Block.defineBlock(121,"Sticky Piston Glasspane",[["piston_top_sticky",0],["piston_side",0],["piston_inner",0],["piston_bottom",0]],true,5,18);
Block.setDestroyTime(121,0.01);

Block.defineBlock(129,"Iron Glasspane",[
["iron_block",0],
 ["iron_block",0],
  ["iron_block",0] ,
  ["iron_block",0],
   ["iron_block",0], 
   ["iron_block",0]],1,1,18);
Block.setDestroyTime(129,0.01)

Block.defineBlock(130,"End Portal Glasspane",[["endframe_side",0],["endframe_top",0]],true,5,18);
Block.setDestroyTime(130,0.01);

Block.defineBlock(131,"Soul Sand Glasspane",["soul_sand",0],true,5,18);
Block.setDestroyTime(131,0.01);

Block.defineBlock(132,"Monster Spawner Glasspane",["mob_spawner",0],true,5,18);
Block.setDestroyTime(132,0.01);

Block.defineBlock(133,"Jukebox Glasspane",[["jukebox_side",0],["jukebox_top",0]],true,5,18);
Block.setDestroyTime(133,0.01);

Block.defineBlock(134,"Nether Reactor Core Glasspane 2",["reactor_core_stage_x",2],true,5,18);
Block.setDestroyTime(134,0.01);

Block.defineBlock(135,"End Stone Glasspane",["end_stone",0],true,5,18);
Block.setDestroyTime(135,0.01);

Block.defineBlock(136,"Leaves Glasspane",[
["leaves",0],
 ["leaves",0],
  ["leaves",0] ,
  ["leaves",0],
   ["leaves",0], 
   ["leaves",0]],1,1,18);
Block.setDestroyTime(136,0.01)

Block.defineBlock(137,"Fire Glasspane",[
["fire",0],
 ["fire",0],
  ["fire",0] ,
  ["fire",0],
   ["fire",0], 
   ["fire",0]],1,1,18);
Block.setDestroyTime(137,0.01)
Block.setLightLevel(137,15)

Block.defineBlock(138,"Glowstone Glasspane",[
["glowstone",0],
 ["glowstone",0],
  ["glowstone",0] ,
  ["glowstone",0],
   ["glowstone",0], 
   ["glowstone",0]],1,1,18);
Block.setDestroyTime(138,0.01)
Block.setLightLevel(138,15)

Block.defineBlock(139,"Ice Glasspane",[
["ice",0],
 ["ice",0],
  ["ice",0] ,
  ["ice",0],
   ["ice",0], 
   ["ice",0]],1,1,18);
Block.setDestroyTime(139,0.01)

Block.defineBlock(140,"Snow Glasspane",[
["snow",0],
 ["snow",0],
  ["snow",0] ,
  ["snow",0],
   ["snow",0], 
   ["snow_block",0]],1,1,18);
Block.setDestroyTime(140,0.01)

Block.defineBlock(141,"Glowing obsidian Glasspane",[
["glowing_obsidian",0],
 [ "glowing_obsidian" ,0],
  [ "glowing_obsidian" ,0] ,
  [ "glowing_obsidian" ,0],
   [ "glowing_obsidian" ,0], 
   [ "glowing_obsidian" ,0]],1,1,18);
Block.setDestroyTime(141,0.01)
Block.setLightLevel(141,15)

Block.defineBlock(142,"Cactus Glasspane",[
["cactus",0],
 ["cactus",0],
  ["cactus",0] ,
  ["cactus",0],
   ["cactus",0], 
   ["cactus",0]],1,1,18);
Block.setDestroyTime(142,0.01)

Block.defineBlock(143,"Bedrock Glasspane",[
["bedrock",0],
 ["bedrock",0],
  ["bedrock",0] ,
  ["bedrock",0],
   ["bedrock",0], 
   ["bedrock",0]],1,1,18);
Block.setDestroyTime(143,0.01)

Block.defineBlock(144,"Sponge Glasspane",[
["sponge",0],
 ["sponge",0],
  ["sponge",0] ,
  ["sponge",0],
   ["sponge",0], 
   ["sponge",0]],1,1,18);
Block.setDestroyTime(144,0.01)

Block.defineBlock(145,"Netherrack Glasspane",[
["netherrack",0],
 ["netherrack",0],
  ["netherrack",0] ,
  ["netherrack",0],
   ["netherrack",0], 
   ["netherrack",0]],1,1,18);
Block.setDestroyTime(145,0.01)

Block.defineBlock(146,"Water Glasspane",[
["still_water",0],
 ["still_water",0],
  ["still_water",0] ,
  ["still_water",0],
   ["still_water",0], 
   ["still_water",0]],1,1,18);
Block.setDestroyTime(146,0.01)

Block.defineBlock(147,"Lava Glasspane",[
["still_lava",0],
 ["still_lava",0],
  ["still_lava",0] ,
  ["still_lava",0],
   ["still_lava",0], 
   ["still_lava",0]],1,1,18);
Block.setDestroyTime(147,0.01)
Block.setLightLevel(147,15)

Block.defineBlock(148,"Redstone lamp Glasspane",[
["redstone_lamp_on",0],
 ["redstone_lamp_on",0],
  ["redstone_lamp_on",0] ,
  ["redstone_lamp_on",0],
   ["redstone_lamp_on",0], 
   ["redstone_lamp_on",0]],1,1,18);
Block.setDestroyTime(148,0.01)
Block.setLightLevel(148,15)

function procCmd(c)
 {
	var p = c.split(" ");
	var command = p[0];
	switch(command)

{
case 'items':
{
clientMessage(ChatColor.BLUE + "Given all items")
Player.addItemInventory(121,30)
Player.addItemInventory(122,30)
Player.addItemInventory(123,30)
Player.addItemInventory(124,30)
Player.addItemInventory(125,30)
Player.addItemInventory(126,30)
Player.addItemInventory(127,30)
Player.addItemInventory(128,30)
Player.addItemInventory(129,30)
Player.addItemInventory(130,30)
Player.addItemInventory(131,30)
Player.addItemInventory(132,30)
Player.addItemInventory(133,30)
Player.addItemInventory(134,30)
Player.addItemInventory(135,30)
Player.addItemInventory(136,30)
Player.addItemInventory(137,30)
Player.addItemInventory(138,30)
Player.addItemInventory(139,30)
Player.addItemInventory(140,30)
Player.addItemInventory(141,30)
Player.addItemInventory(142,30)
Player.addItemInventory(143,30)
Player.addItemInventory(144,30)
Player.addItemInventory(145,30)
Player.addItemInventory(146,30)
Player.addItemInventory(147,30)
Player.addItemInventory(148,30)
}
break;
}
}
