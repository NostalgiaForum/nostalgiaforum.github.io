ModPE.overrideTexture("images/items-opaque.png","http://i.imgur.com/XBj4b3Q.png");

ModPE.langEdit("item.chestplateChain.name"," BackPack");
ModPE.overrideTexture("images/armor/chain_1.png","http://i.imgur.com/v6CLzjE.png");

Item.addCraftRecipe(303,1,0,[334,4,0, 287,2,0, 54,1,0]);


var slots = [];
var switchback = 0;
var chestX, chestY, chestZ, yaw, pitch, pY, pX, pZ, health, id, damage, selectedSlot;

function useItem(x, y, z, itemId, blockId, side, itemDamage, blockDamage) {
    function g(sX, sZ) {
        function c(id) {
            return Level.getTile(x, y, z) != id;
        }
        return c(54) && c(61) && c(62) && c(247) && Level.getTile(x - sX, y, z - sZ) != 54;
    }
    if(itemId == 303 && g(1, 0) && g(0, 1) && g(-1, 0) && g(0, -1) && Level.getTile(x, y + 1, z) == 0) {
        if(switchback) switchBack(false);
        switchback = 1;
        Level.setTile(x, y, z, 54, 0);
        chestX = x;
        chestY = y;
        chestZ = z;
        pX = Player.getX();
        pY = Player.getY();
        pZ = Player.getZ();
        health = Entity.getHealth(Player.getEntity());
        yaw = Entity.getYaw(Player.getEntity());
        pitch = Entity.getPitch(Player.getEntity());
        selectedSlot = Player.getSelectedSlotId();
        id = blockId;
        damage = blockDamage;
        for(var i in slots) Level.setChestSlot(x, y, z, i, slots[i][0], slots[i][2], slots[i][1]);
    } else {
        if(itemId == 303) clientMessage("The backpack cannot be opened in that\narea.");
    }
}

function modTick() {
    switchBack(true);
    if(switchback && (Entity.getPitch(Player.getEntity()) != pitch || Entity.getYaw(Player.getEntity()) != yaw || Player.getX() != pX || Player.getY() != pY || Player.getZ() != pZ || Entity.getHealth(Player.getEntity()) != health || Player.getSelectedSlotId() != selectedSlot)) switchBack(false);
}

function newLevel() {
    var line, string = "";
    var file = new java.io.File(android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/games/com.mojang/minecraftworlds/" + Level.getWorldDir() + "/", "storage.dat");
    if(!file.exists()) return;
    var buffer = new java.io.BufferedReader(new java.io.FileReader(file));
    while((line = buffer.readLine()) != null) {
        var t = line + java.lang.System.getProperty("line.seperator");
        string += t.substring(0, t.length - 4);
        var t2 = line;
        if((line = buffer.readLine()) != null) string += "\n";
        line = t2;
    }
    var oldSlots = string.split("|");
    for(var i in oldSlots) {
        var slotData = oldSlots[i].split("~");
        if(slotData.length < 1) continue;
        slots[i] = [slotData[0], slotData[1], slotData[2]];
    }
}

function leaveGame() {
    slots = [];
}

function switchBack(just) {
    function saveChest() {
        var file = new java.io.File(android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/games/com.mojang/minecraftworlds/" + Level.getWorldDir() + "/", "storage.dat");
        file.createNewFile();
        var outWrite = new java.io.OutputStreamWriter(new java.io.FileOutputStream(file));
        var string = "";
        for(var i in slots) if(slots[i][0] !== undefined && slots[i][1] !== undefined && slots[i][2] !== undefined) string += slots[i][0].toString() + "~" + slots[i][1].toString() + "~" + slots[i][2].toString() + "|";
        outWrite.append(string);
        outWrite.close();
    }
    if(just) {
        saveChest();
        return;
    }
    switchback = 0;
    for(var i = 0; i < 27; i++) {
        slots[i] = [Level.getChestSlot(chestX, chestY, chestZ, i), Level.getChestSlotCount(chestX, chestY, chestZ, i), Level.getChestSlotData(chestX, chestY, chestZ, i)];
        Level.setChestSlot(chestX, chestY, chestZ, i, 0, 0, 0);
    }
    saveChest();
    Level.setTile(chestX, chestY, chestZ, id, damage);
}
