//More Creatures Mod by Quinton Mostert copyright © ® 2014 
var entities = [];
var orespider = Math.floor(Math.random()*9);
var roost= [0];
var cow= [0];
var spawnX= Math.floor(Math.random()*257);
var spawnZ= Math.floor(Math.random()*257);
var cowspiders = [];
var obsidianSpiders = []; 
var diamondSpiders = []; 
var emeraldSpiders = [];
var ironSpiders = [];
var goldSpiders = [];
var coalSpiders = [];
var netherSpiders = [];
var lapisSpiders = [];
var redstoneSpiders = []; 
var duk = [];
var boar =[];
var caveSpider = [];
var applescow = [];
var creepercow = [];
var buffalo = [];
var bedrockcreeper = [];
var birthdaycow = [];
var cookiecreeper = [];
var darkcreeper = [];
var friendlycreeper = [];
var endercow = [];
var pinkcreeper = [];
var pigman = [];
var redCows = [];
var candycow = [];
var cowsalted = [];
var santacow =[];
var icecreamcow = [];
var bluecow  = [];
var snowcow  = [];
var nethercow  = [];

var watercreeper = [];


function entityRemovedCallback(ent){
    entities.splice(entities.indexOf(ent));
}
function killAll(entType){
    for(var i=0;i<entities.length;i++){
        if(Entity.getEntityTypeId(entities[i]) == entType){
            Entity.remove(entities[i]);
        }
    }
}















function BULL(x, y, z, skin) {
 this.entity = Level.spawnMob(x, y+1, z, 35, skin);
 Entity.setRenderType(this.entity,7);
 }
 
 function Cows(x, y, z, skin) {
 this.entity = Level.spawnCow(x, y+1, z, skin);
 
            Entity.remove(cowspiders);
        
 
 }
 
 
//friendly creepa function
function fCreepers(x, y, z, skin) {
 this.entity = Level.spawnMob(x, y+1, z, 11, skin);
 Entity.setRenderType(this.entity,14);
 }

//more creepas function
function Pigs(x, y, z, skin) {
 this.entity = Level.spawnMob(x, y+1, z, 12, skin);
 }

function Creepers(x, y, z, skin) {
 this.entity = Level.spawnMob(x, y+1, z, 33, skin);
 }

function DUCK(x, y, z, skin) {
 this.entity = Level.spawnChicken(x, y+1, z,"mobs/duck.png");
 
 } 
 
function Spider(x, y, z, skin, health, allowDamage, noKnockback) {
 this.entity = Level.spawnMob(x, y+1, z, 35, skin);
 this.health = health;
 Entity.setHealth(this.entity, health);
 this.takeDamage = false; /* only if allowDamage is false and it will be set to true when player attacks the spider (for fire resistance)*/
 this.damage = function() {
  // damage anyways
  this.takeDamage = true;
 };
 this.update = function() {
  if(!allowDamage){
   var h = Entity.getHealth(this.entity);
   if(this.takeDamage) {
    this.health = h;
    if(noKnockback) {
     Entity.setVelX(this.entity, 0);
     Entity.setVelY(this.entity, 0);
     Entity.setVelZ(this.entity, 0);
    }
    this.takeDamage = false;
   }
   else if(h != this.health) {
    Entity.setHealth(this.entity, this.health);
   }
  }
 };
}

function newLevel() { 
clientMessage('Enjoy more creatures ver 0.2 by Quinton Mostert');







 cowspiders = [];
 obsidianSpiders = []; 
 diamondSpiders = []; 
 goldSpiders = []; 
 lapisSpiders = []; 
 redstoneSpiders = []; 
 ironSpiders = []; 
 coalSpiders = [];
 duk = []; 
 boar =[];
caveSpider = [];
applescow = [];
creepercow = [];
buffalo = [];
bedrockcreeper = [];
birthdaycow = [];
cookiecreeper = [];
darkcreeper = [];
freindlycreeper = [];
endercow = [];
pinkcreeper = [];
pigman = [];
redCows = [];
candycow = [];
cowsalted = [];
santacow =[];
icecreamcow = [];
bluecow  = [];
snowcow  = [];
nethercow  = [];
supercow  = [];
watercreeper = [];


} 

// e is entity and a is array 
function indexOf(e, a) {
 for(var i = a.length-1; i >= 0; i--) { 
  if(a[i].entity == e) { return i; } 
 } 
 return -1;
} 

function getArray(e, a){
 var i = indexOf(e, a);
 if(i != -1) return a[i];
 return null;
}


//New Items


ModPE.setItem(388,"emerald", 0, "Emerald"); 
ModPE.setFoodItem(356,"cookie",0,0,"cookie",2);
ModPE.setFoodItem(349,"hopper",3,0,"fish",0);

ModPE.setFoodItem(399,"name_tag",3,0,"Sweets",0);
ModPE.setFoodItem(357,"cauldron",0,0,"duck",5);
ModPE.setItem(491,"skull_skeleton", 0, "Spawn Obsidian Spider"); 
ModPE.setItem(492,"slimeball", 0, "Spawn Diamond Spider");
ModPE.setItem(493,"skull_steve", 0,"Spawn Emerald Spider");
ModPE.setItem(494,"spider_eye", 0, "Spawn Iron Spider"); 
ModPE.setItem(495,"skull_zombie", 0,"Spawn Gold Spider");
ModPE.setItem(496,"ender_eye", 0, "Spawn Coal Spider"); 
ModPE.setItem(497,"nether_star", 0,"Spawn Nether Quartz Spider"); 
ModPE.setItem(498,"skull_creeper", 0,"Spawn Lapis Spider"); 
ModPE.setItem(499,"skull_wither", 0, "Spawn Redstone spider"); 

ModPE.setItem(358,"ruby", 0, "More Creatures Summoner"); 



function check(e, a) {
 var i = indexOf(e, a);
 if(i == -1) return false;
 a.splice(i, 1);
 return true;
}





function useItem(x,y,z,itemId,block,side){

if(block == 58 && itemId == 358){


addItemInventory (358, -1);

setTile (x, y, z, 4);

clientMessage ("More Creatures were summoned! This is a Demo only 5 creatures avalible buy full version on playstore when its out!!");


  var spider = new Spider(  x+30, y+10 , z+8," mob/coalSpider.png", 18, true, false);
  coalSpiders.push(spider); 
  
  

   var creepa = new Creepers(x+20, y+10, z+6, "mob/watercreeper.png", 33, true, false);
   watercreeper.push(creepa);  
   

var bull = new BULL( x+20,y+5,z+10, "mobs/bull.png");
cowspiders.push(bull); 
clientMessage('thanks MrARM and expir3dcow for ore spiders full credit given!! This is in both full version and demo as it is made by other moders! ' );


}

}
  
function deathHook(a,v){




      

  if( Entity.getEntityTypeId(v) == 33){
 
 
            
        
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1,358, 1, 0);
   
    
}












//cows
//if bull dies spawn red cow
if(check(v, cowspiders)) { 

   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 356, 2, 0); 
  
   var cows = new Cows(  Entity.getX(v), Entity.getY(v), spawnZ, "mob/redcow.png");
   redCows.push(cows); 

      
           
        
    

// redcow dies spawn  applecow
 
  }else if(check(v, redCows)) { 
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 40, 3, 0); 
  
 
 
   var cows = new Cows( Entity.getX(v)+10, Entity.getY(v), spawnZ, "mob/applescow.png");
   applescow.push(cows);  
 
            Entity.remove('cowspiders');
        
    
 
 //if applecow dies spawn icecream cow
 
 }else if(check(v, applescow)) { 
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 250, 1, 0); 
  
   clientMessage("This is all for the cows in the demo version get the full version!!!");

 
            
        
    
 
 //if 
}
  if(check(v, watercreeper)) { 
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 9, 1, 0); 
  
  
  
   var creepa = new Creepers( Entity.getX(v)+20, Entity.getY(v), Entity.getZ(v), "mob/cookiecreeper.png", 11, true, false);
   cookiecreeper.push(creepa);  


 //MORE CREEPAS HERE!!!
  
  

 }else if(check(v, cookiecreeper)) { 
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 356, 6, 0); 
  
  
  
   
 clientMessage("This is all for the demo for more creepers get full version when its out!!");



  }else if( Entity.getEntityTypeId(v) == 12 ){
 
 

var pig = new Pigs( Entity.getX(v)-10, Entity.getY(v) , Entity.getZ(v)+15 ,"mobs/boar.png");

boar.push(pig); 

  
  if(check(v, boar)) { 
 clientMessage('for fish drops buy full version on playstore when its out!!');
  }

//duck

  }else if( Entity.getEntityTypeId(v) == 10 ){
 
 

var duck = new DUCK( Entity.getX(v)-10, Entity.getY(v) , Entity.getZ(v)+15 ,"mobs/duck.png");
clientMessage("Ducks drop duck lol demo buy full version for more creatures");
duk.push(duck); 

  
  if(check(v, duk)) { 
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1,357, 1, 0);
   
  }
  
  // if it's a spider... (it can be a normal one too) 
  // check is it a obsidian spider 
   
  
 }else if(Entity.getEntityTypeId(v) == 35) { 
  // if it's a spider... (it can be a normal one too) 
  
   
  
  // check is it a obsidian spider 
  if(check(v, obsidianSpiders)) { 
  
  
   Level.dropItem(Entity.getX(v)-15
   
, Entity.getY(v), Entity.getZ(v)+20, 1, 49, 1, 0); 
  }else if(check(v, diamondSpiders)) { 
  
  
  
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 264, 1, 0); 
  }else if(check(v, emeraldSpiders)) { 
  
  var spider = new Spider( spawnX, Entity.getY(v), Entity.getZ(v), "mob/diamondSpider.png", 60, true, false);
  diamondSpiders.push(spider); 
  
  
  
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 388, Math.random()*3, 0); 
  }else if(check(v, ironSpiders)) { 
  
  
  var spider = new Spider( spawnX , Entity.getY(v) , Entity.getZ(v)+20," mob/goldSpider.png", 18, true, false);
  goldSpiders.push(spider); 
  
  
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 265, Math.random()*3, 0); 
  }else if(check(v, goldSpiders)) { 
  
  var spider = new Spider( spawnX, Entity.getY(v) , Entity.getZ(v)+30 ," mob/emeraldSpider.png", 30, true, false);
  emeraldSpiders.push(spider); 
  
  
  
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 266, Math.random()*3, 0); 
   
   
  }else if(check(v, coalSpiders)) {
  
  
  var spider = new Spider( spawnX, Entity.getY(v) , Entity.getZ(v)+10," mob/lapisSpider.png", 18, true, false);
  lapisSpiders.push(spider); 
  
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 263, Math.random()*10, 0); 
 
 
 
            Entity.remove('coalSpiders');
        
  
 
  }else if(check(v, netherSpiders)) { 
  
  var spider = new Spider( spawnX, Entity.getY(v) , Entity.getZ(v)+20 ," mob/iornSpider.png", 18, true, false);
  iornSpiders.push(spider); 
  
  
  
 
            Entity.remove('coalSpiders');
        
  
  
  
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 406, Math.random()*5, 0); 
  }else if(check(v, lapisSpiders)) { 
  
  var spider = new Spider( spawnX, Entity.getY(v) , Entity.getZ(v)+10," mob/redstoneSpider.png", 18, true, false);
  redstoneSpiders.push(spider); 
  
  
  
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 351, Math.random()*10, 4); 
   
   
 
            Entity.remove(coalSpiders);
        
  
   
  }else if(check(v, redstoneSpiders)) { 
  
   var spider = new Spider(spawnX, Entity.getY(v) , Entity.getZ(v), "mob/ironSpider.png", 40, true, false); 
 ironSpiders.push(spider); 
  
  
 
            Entity.remove(coalSpiders);
        
  
  
   Level.dropItem(Entity.getX(v), Entity.getY(v), Entity.getZ(v), 1, 331, Math.random()*10, 0); 
  }
  
  }
  }
  
  

//eggs

function procCmd(cmd) { 

 if(cmd == "eggs") { 
  addItemInventory(491,1); 
  addItemInventory(492,1); 
  addItemInventory(493,1); 
  addItemInventory(494,1); 
  addItemInventory(495,1); 
  addItemInventory(496,1); 
  addItemInventory(497,1); 
  addItemInventory(498,1); 
  addItemInventory(499,1); 
 } 
}

function updateAll(a){
 for(var i = a.length-1; i >= 0; i--) { 
  a[i].update();
 }
}

function modTick() {
 updateAll(obsidianSpiders);
 updateAll(redstoneSpiders);

 
}