function useItem(x, y, z, itemId, blockId, side)
{
if(itemId==86)
{
var stve = Level.spawnMob( x, y+1, z, 33, "40.png");
Entity.setRenderType(stve, 3);
Entity.setHealth(stve, 20);
cow=Entity.spawnMob(x, y+1, z, 11);
rideAnimal(stve, cow);
{
    clientMessage("Наездник заспавнен, подойди к нему :D");


}
}
}