//Asgards Shields 

ModPE.setItem(460,"skull_creeper",0,"Big Wooden Sword");
Item.addShapedRecipe(460,1,0,[" mm","mmm","pm "],["m",5,0,"p",280,0]);
Item.setMaxDamage(460,78);

ModPE.setItem(461,"skull_skeleton",0,"Big Stone Sword");
Item.addShapedRecipe(461,1,0,[" pp","ppp","sp "],["p",4,0,"s",280,0,]);
Item.setMaxDamage(461,88);

ModPE.setItem(462,"skull_steve",0,"Big Iron Sword");
Item.addShapedRecipe(462,1,0,[" ii","iii","pi "],["i",265,0,"p",280,0]);
Item.setMaxDamage(462,162);

ModPE.setItem(463,"skull_wither",0,"Big Gold Sword");
Item.addShapedRecipe(463,1,0,[" oo","ooo","po "],["o",266,0,"p",280,0]);
Item.setMaxDamage(463,42);

ModPE.setItem(464,"skull_zombie",0,"Big Diamond Sword");
Item.addShapedRecipe(464,1,0,[" dd","ddd","pd "],["d",264,0,"p",280,0]);
Item.setMaxDamage(464,1628);


var sword = 0
function attackHook(attacker, victim) {
function hurt(health) { if(Entity.getHealth(victim) > health) Entity.setHealth(victim, Entity.getHealth(victim) - health);
else {
Entity.setHealth(victim, 1);
}
}
var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(attacker == Player.getEntity()) switch(Player.getCarriedItem()) {
case 460:
sword--;
hurt(14);
toolUse(78,460);
break;
}

var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(attacker == Player.getEntity()) switch(Player.getCarriedItem()) {
case 461:
sword--;
hurt(7);
toolUse(81,461);
break;
}

var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(attacker == Player.getEntity()) switch(Player.getCarriedItem()) {
case 462:
sword--;
hurt(8);
toolUse(162,462);
break;
}

var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(attacker == Player.getEntity()) switch(Player.getCarriedItem()) {
case 463:
sword--;
hurt(6);
toolUse(42,463);
break;
}

var x = Entity.getX(victim);
var y = Entity.getY(victim);
var z = Entity.getZ(victim);
if(attacker == Player.getEntity()) switch(Player.getCarriedItem()) {
case 464:
sword--;
hurt(9);
toolUse(1628,464);
break;
}
}

function toolUse(maxDamage,id) {
var pcid=Player.getCarriedItemData();
if(pcid!==maxDamage){
Entity.setCarriedItem(getPlayerEnt(),id,1,pcid+1);
}else if(pcid==maxDamage) {
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
}
}