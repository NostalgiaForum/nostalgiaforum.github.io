//modscript ENDERDRAGON v2.0 - By wartave

ModPE.overrideTexture("images/mob/black.png", "http://i.imgur.com/FmbKU7q.png");
ModPE.overrideTexture("images/mob/bola.png", "http://i.imgur.com/kGOg3Rl.png");

//var A1path = android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/Tommy82/PEDimensions/Worlds/aether";
//var A2path = android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/Tommy82/PEDimensions/Worlds/aether_2";
//var n1path = android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/Tommy82/PEDimensions/Worlds/nether";
//var n2path = android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/Tommy82/PEDimensions/Worlds/nether_2";
//var e1path = android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/Tommy82/PEDimensions/Worlds/end";
//var e2path = android.os.Environment.getExternalStorageDirectory().getAbsolutePath()+"/games/Tommy82/PEDimensions/Worlds/end_2";
//var aparticles = 0;
//var nparticles = 0;
//var eparticles = 0;
var world;
var aether = false;
var nether = false; 
var end = false;
var alink = 0;
var nlink = 0;
var elink = 0;
var player = getPlayerEnt();
var slot;
var m = 0;
var c = 0;
var k = 0;
var aa1 = 0;
var aa2 = 0;
var aa3 = 0;
var aa4 = 0;
var aa5 = 0;
var aa6 = 0;
var aa7 = 0;
var aa8 = 0;
var aa9 = 0;
var aa10 = 0;
var na1 = 0;
var na2 = 0;
var ea1 = 0;
var ea2 = 0;
var wbx;
var wby;
var wbz;
var setaltar = false;
var setfreezer = false;
var gci;
var gcc;
var gcd;
var gis;
var gic;
var gid;
var gas;
var gad;
var gh;
var currentActivity = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var count=-1;
var fire=-1;
var recurrent=19;
var recurrent2=80;
var height=4;
var prueba;
var countdown=-1;
var ball=-1;
var x;
var y;
var z;
var a;
var b;
var c;
var pruebaRenderer = Renderer.createHumanoidRenderer();
addPruebaRenderType(pruebaRenderer);
var ballRenderer = Renderer.createHumanoidRenderer();
addBallToRenderer(ballRenderer);
ModPE.setItem(475, "book_enchanted", 0, "enderdragon informacion");
Item.addCraftRecipe(475, 1, 0, [17, 1, 0]);
Block.defineBlock(163, "End Portal",
[["anvil_top_damaged_x", 3]],57);
Block.setDestroyTime(163,1000);
Block.setShape(163, 0, 0, 0, 1, 13/16, 1);
Block.setLightLevel(163,11);

Block.defineBlock(164, "End Frame",
[["end_stone", 0], ["endframe_top", 0], ["endframe_side", 0], ["endframe_side", 0], ["endframe_side", 0], ["endframe_side", 0]],1);
Block.setDestroyTime(164,1000);
Block.setShape(164, 0, 0, 0, 1, 13/16, 1);

Block.defineBlock(165, "End Frame (eye)",
[["end_stone", 0], ["endframe_eye", 0], ["endframe_side", 0], ["endframe_side", 0], ["endframe_side", 0], ["endframe_side", 0]],1);
Block.setDestroyTime(165,1000);
Block.setShape(165, 0, 0, 0, 1, 13/16, 1);

Block.defineBlock(166, "End Stone",
[["end_stone", 0]],1);
Block.setDestroyTime(166,1.5);
Block.defineBlock(129, "ender block", [["glowing_obsidian" , 0],
["glowing_obsidian"  , 0],
["glowing_obsidian"  , 0],
["glowing_obsidian"  , 0],
["glowing_obsidian"  , 0],
["glowing_obsidian"  , 0]], 6, true, 0);
Block.setDestroyTime(129, 1.6);
ModPE.setItem(486, "ender_eye", 0, "Eye of Ender");
ModPE.setItem(150,"nether_star",0,"Nether Star") ;
Item.addCraftRecipe(129,1,0,[49,9,0]);
Item.addCraftRecipe(486,1,0,[6,3,0,18,3,0]);
Item.addCraftRecipe(486,1,0,[6,3,0,18,3,0]);
Item.addCraftRecipe(165,1,0,[6,3,0,18,3,0,24,1,0]);

function addPruebaRenderType(renderer) 
{

var model = renderer.getModel();
var var2 = 0;

var head = model.getPart("head").clear();
var body = model.getPart("body").clear();
var rArm = model.getPart("rightArm").clear();
var lArm = model.getPart("leftArm").clear();
var rLeg = model.getPart("rightLeg").clear();
var lLeg = model.getPart("leftLeg").clear();

head.clear();
head.setTextureOffset(0, 0, true);
head.addBox(-3.5, 4, 1, 3, 4, 3, var2);
head.addBox(3.5, 4, 1, 3, 4, 3, var2);

body.clear();
body.setTextureOffset(0, 7, true);
body.addBox(13, -14, -72, 4, 8, 8, var2);
body.addBox(7, -14, -72, 4, 8, 8, var2);
body.addBox(7, -2, -92, 12, 8, 20, var2);
body.addBox(5, -10, -76, 16, 18, 16, var2);
body.addBox(-5, -16, -14, 30, 30, 70, var2);
body.addBox(8, -4, 46, 10, 10, 100, var2);
body.addBox(8, -4, -60, 10, 10, 100, var2);
body.addBox(10, -12, 60, 2, 10, 10, var2);
body.addBox(10, -12, 76, 2, 10, 10, var2);
body.addBox(10, -10, 92, 2, 10, 10, var2);
body.addBox(10, -8, 108, 2, 10, 10, var2);
body.addBox(10, -6, 124, 2, 10, 10, var2);
body.addBox(10, -4, 140, 2, 10, 10, var2);
body.addBox(8, -14, -6, 60, 8, 8, var2);
body.addBox(8, -14, -6, 68, 2, 50, var2);
body.addBox(-40, -14, -6, 60, 8, 8, var2);
body.addBox(-40, -14, -6, 68, 2, 50, var2);
body.addBox(10, -24, -14, 2, 8, 16, var2);
body.addBox(10, -24, 8, 2, 8, 16, var2);
body.addBox(10, -24, 32, 2, 8, 16, var2);

body.addBox(-70, -14, -6, 30, 2, 66, var2);
body.addBox(-90, -14, -6, 50, 2, 66, var2);

body.addBox(70, -14, -6, 30, 2, 66, var2);
body.addBox(70, -14, -6, 50, 2, 66, var2);

rArm.clear();
rArm.setTextureOffset(36, 10, true);
rArm.addBox(-70, -14, -6, 30, 2, 66, var2);
rArm.addBox(-90, -14, -6, 50, 2, 66, var2);
rArm.addBox(-90, -14, -6, 50, 2, 66, var2);
rArm.addBox(-130, -14, -6, 50, 2, 48, var2);
rArm.addBox(-70, -14, -6, 15, 2, 78, var2);
rArm.addBox(-70, -14, -14, 15, 2, 78, var2);

lArm.clear();
lArm.setTextureOffset(36, 10, true);
lArm.addBox(70, -14, -6, 30, 2, 66, var2);
lArm.addBox(70, -14, -6, 50, 2, 66, var2);
lArm.addBox(110, -14, -6, 50, 2, 56, var2);
lArm.addBox(120, -14, -6, 50, 2, 48, var2);
lArm.addBox(86, -14, -6, 15, 2, 78, var2);
lArm.addBox(86, -14, -14, 15, 2, 78, var2);


rLeg.clear();
rLeg.setTextureOffset(0, 28, true);
rLeg.addBox(0, 2, -4, 8, 28, 8, var2);
rLeg.addBox(0, 2, 40, 8, 28, 8, var2);

lLeg.clear();
lLeg.setTextureOffset(0, 28, true);
lLeg.addBox(12, 2, -4, 8, 28, 8, var2);
lLeg.addBox(12, 2, 40, 8, 28, 8, var2);

}
 
var pruebaRenderType = Renderer.createHumanoidRenderer();
addPruebaRenderType(pruebaRenderType);


function useItem(x,y,z,itemId,block,side)
{
if(itemId==260)
{
prueba= Level.spawnMob(x,y+1,z,35,"mob/black.png");
Entity.setRenderType(prueba,pruebaRenderType.renderType);   
}
}

function procCmd(c)
{
var cmd = c.split(" ");
if(cmd[0]=="lol")
{
Player.addItemInventory(260,1);
clientMessage("Fap");
}
}



function addBallToRenderer(renderer)
{
var model2 = renderer.getModel();
var var2 = 0;

var body = model2.getPart("body").clear().setTextureOffset(32, 16);

body.addBox(-20, 0, 0, 10, 10, 10, var2);
body.addBox(1, 1, 1, 10, 10, 10, var2);
body.addBox(-1, -1, -20, 10, 10, 10, var2);
body.addBox(4, -5, 1, 10, 10, 10, var2);
body.addBox(15, -15, 1, 10, 10, 10, var2);

model2.getPart("rightArm").clear()
model2.getPart("leftArm").clear()
model2.getPart("leftLeg").clear()
model2.getPart("rightLeg").clear()




}
function spawnprueba()
{
countdown=200;
prueba = Level.spawnMob(a,b+1,c, 35, "mob/black.png");
Entity.setRenderType(prueba, pruebaRenderer.renderType);
wX=Entity.getX(prueba);
wY=Entity.getY(prueba);
wZ=Entity.getZ(prueba);
clientMessage("§5calgnado....");
}
function modTick()
{
if(y-Entity.getY(ball)>=0)
{
setVelY(ball,0.3);
}
else if(y-Entity.getY(ball)<=0)
{
setVelY(ball,-0.25);
}
if(x-Entity.getX(ball)>=0)
{
setVelX(ball,0.32);
}
else if(x-Entity.getX(ball)<=0)
{
setVelX(ball,-0.32);
}
if(z-Entity.getZ(ball)>=0)
{
setVelZ(ball,0.32);
}
else if(z-Entity.getZ(ball)<=0)
{
setVelZ(ball,-0.32);
}
if(countdown==-1)
{
if(getPlayerY()-Entity.getY(prueba)<=-10)
{
setVelY(prueba,-10);
}
if(getPlayerX()-Entity.getX(prueba)<=-20)
{
setVelX(prueba,-0.4);
}
else if(getPlayerX()-Entity.getX(prueba)>=20)
{
setVelX(prueba, 0.4);
}
if(getPlayerZ()-Entity.getZ(prueba)<=-20)
{
setVelZ(prueba,-0.4)
}
else if(getPlayerZ()-Entity.getZ(prueba)>=20)
{
setVelZ(prueba,0.4)
}
if(getTile(Entity.getX(prueba),Entity.getY(prueba)-height,Entity.getZ(prueba))==0)
{
if(recurrent2>=60)
{
setVelY(prueba,-1)
}
else
{
setVelY(prueba,0.3)
}
}
else
{
setVelY(prueba, 1)
}
}
if(fire>=1)
{
fire=fire-1;
}
if(fire==0)
{
fire=70;
if(ball==-1)
{
ball=Level.spawnMob(Entity.getX(prueba),Entity.getY(prueba)+1,Entity.getZ(prueba),12, "mob/bola.png");
x=Player.getX();
y=Player.getY()-2;
z=Player.getZ();
count=42;
Entity.setHealth(ball,100);
Entity.setRenderType(ball, ballRenderer.renderType);
}
}
if(count>=1)
{
count=count-1;
}
if(count==0)
{
count=-1;
Level.explode(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3)
Entity.setFireTicks(Player.getEntity(), 1);(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3);
Entity.remove(ball);
ball=-1
}
if(countdown>=1)
{
countdown=countdown-1;
setVelX(prueba,0);
setVelY(prueba,0.01);
setVelZ(prueba,0);
Entity.setHealth(prueba,10);
}
if(countdown==0)
{
clientMessage("§0cargando.");
countdown=-1;
Entity.setHealth(prueba,200);
Level.explode(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3)
Entity.setFireTicks(Player.getEntity(), 1);(Entity.getX(prueba),Entity.getY(prueba),Entity.getZ(prueba),6);
Entity.remove(prueba);
prueba = Level.spawnMob(wX, wY, wZ, 35, "mob/black.png");
Entity.setRenderType(prueba, pruebaRenderer.renderType);
Entity.setHealth(prueba,3000);
fire=70;
}
if(getTile(Entity.getX(ball),Entity.getY(ball)-1,Entity.getZ(ball))==0)
{
}
else
{
Level.explode(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3)
Entity.setFireTicks(Player.getEntity(), 1);(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3);
Entity.remove(ball);
ball=-1;
count=-1;
}
if(recurrent>=1)
{
recurrent=recurrent-1;
}
if(recurrent==0)
{
recurrent=5;
if(getTile(Player.getX(),Player.getY()-2,Player.getZ())==129)
{
setVelX(getPlayerEnt(),0);
setVelZ(getPlayerEnt(),0);
}
}
if(recurrent2>=1)
{
recurrent2=recurrent2-1;
}
if(recurrent2==0)
{
recurrent2=80;
height=Math.floor((Math.random()*3)+1);
height=height+1
}
}
function useItem(x, y, z, itemId, blockId, side, itemDamage)
{
a=x;
b=y;
c=z;
if(itemId==86&&getTile(x,y,z)==129&&getTile(x,y-1,z)==129&&getTile(x+1,y,z)==129&&getTile(x-1,y,z)==129)
{
addItemInventory(86,-1);
Level.destroyBlock(x,y,z);
Level.destroyBlock(x,y-1,z);
Level.destroyBlock(x+1,y,z);
Level.destroyBlock(x-1,y,z);
spawnprueba()
}
if(itemId==86&&getTile(x,y,z)==129&&getTile(x,y-1,z)==129&&getTile(x,y,z+1)==129&&getTile(x,y,z-1)==129)
{
addItemInventory(86,-1);
Level.destroyBlock(x,y,z);
Level.destroyBlock(x,y-1,z);
Level.destroyBlock(x,y,z+1);
Level.destroyBlock(x,y,z-1);
spawnprueba()
}
if(itemId==150)
{
Level.dropItem(Player.getX(), Player.getY(),Player.getZ(),1,264,1,0);
clientMessage(credits);
}
{
if(itemId == 475)
		informationsForPortalGUI();
}		
function informationsForPortalGUI()
{
	currentActivity.runOnUiThread(new java.lang.Runnable()
	{
		run: function()
		{
			try
			{
				var layoutInfo = new android.widget.LinearLayout(currentActivity);
				layoutInfo.setOrientation(android.widget.LinearLayout.VERTICAL);

				var scrollInfo = new android.widget.ScrollView(currentActivity);
				scrollInfo.addView(layoutInfo);
			
				var popupInfo = new android.app.Dialog(currentActivity); 
				popupInfo.setContentView(scrollInfo);
				popupInfo.setTitle("EnderDragon modscript by wartave");

				var infoText = new android.widget.TextView(currentActivity);
				infoText.setText("Bienvenidos al EnderDragon mod by Wartave" +
					"\n\ninformacion:" +
					"\nMod v2.0: -aumento del tama=o,mas movimiento,portal The End" +
					"\nProcimas actualizaciones:" +
					"\nMod v3.0: -Huevo del EnderDragon y almadura especial," +
					"\nNOTA : este mod fue creado por Wartave"  );
				layoutInfo.addView(infoText);

				var threadButton = new android.widget.Button(currentActivity); 
				threadButton.setText("comprobar actualizacion"); 
				threadButton.setOnClickListener(new android.view.View.OnClickListener()
				{ 
					onClick: function()
					{ 
						popupInfo.dismiss();
						visitThread();
					}
				}); 
				layoutInfo.addView(threadButton); 

				var exitInfoButton = new android.widget.Button(currentActivity); 
				exitInfoButton.setText("Close"); 
				exitInfoButton.setOnClickListener(new android.view.View.OnClickListener()
				{ 
					onClick: function()
					{ 
						popupInfo.dismiss();
					}
				}); 
				layoutInfo.addView(exitInfoButton); 
				

				popupInfo.show();
			
			}catch (err)
			{
				clientMessage("Error: " + err);
				clientMessage("Maybe GUI is not supported for your device. Report this error in the official minecraftforum.net thread, please.");
			}
		}
	});
}
if(end == false)
{
if(blockId == 163)
{
world = Level.getWorldName()
ModPE.selectLevel("The End")
print("Teleporting")
if(ea1 == 0)
{
ea1 = 1
clientMessage(ChatColor.GOLD + "Achievement: " + ChatColor.DARK_PURPLE + "The End?");
}
}
}
if(itemId == 486)
{
if(blockId == 165)
{
m = x
c = y
k = z
if(getTile(m, c, k)+getTile(m-1, c, k+1)+getTile(m-1, c, k+2)+getTile(m-1, c, k+3)+getTile(m, c, k+4)+getTile(m+1, c, k+4)+getTile(m+2, c, k+4)+getTile(m+3, c, k+3)+getTile(m+3, c, k+2)+getTile(m+3, c, k+1)+getTile(m+2, c, k)+getTile(m+1, c, k) == 1980)
{
setTile(m, c, k+1, 163);
setTile(m, c, k+2, 163);
setTile(m, c, k+3, 163);
setTile(m+1, c, k+1, 163);
setTile(m+1, c, k+2, 163);
setTile(m+1, c, k+3, 163);
setTile(m+2, c, k+1, 163);
setTile(m+2, c, k+2, 163);
setTile(m+2, c, k+3, 163);
}
}
}
if("The End")
{
end = true
if(blockId == 163)
{
ModPE.selectLevel(world)
if(ea2 == 0)
{
ea2 = 1
clientMessage(ChatColor.GOLD + "Achievement: " + ChatColor.DARK_PURPLE + "The End.");
}
}
}
if(world)
{
if(blockId == 163)
{
world = Level.getWorldName()
ModPE.selectLevel("The End")
print("Teleporting")
}
}
}

function procCmd(cmd)
{
var c = cmd.split(" ");
if(c[0] == "help")
{
clientMessage("> no jodas tio.\n> Create a basic golem pattern.\n> Hit the middle top block with a pumpkin.\n§4> Run.")
}
}
function entityRemovedHook(entity)
{
if(entity==prueba)
{
Level.dropItem(Entity.getX(entity),Entity.getY(entity),Entity.getZ(entity),1,49,1,0);
fire=-1;
}
}

function visitThread()
{
	currentActivity.runOnUiThread(new java.lang.Runnable()
	{
		run: function()
		{
			try
			{
				var intentBrowser = new android.content.Intent(currentActivity);
				intentBrowser.setAction(android.content.Intent.ACTION_VIEW);
				intentBrowser.setData(android.net.Uri.parse("http://mcpeuniverse.com"));
				currentActivity.startActivity(intentBrowser);
			}catch (err)
			{
				clientMessage("Error: " + err);
				clientMessage("Maybe GUI is not supported for your device. Report this error in the official minecraftforum.net thread, please.");
			}
		}
	});
}
