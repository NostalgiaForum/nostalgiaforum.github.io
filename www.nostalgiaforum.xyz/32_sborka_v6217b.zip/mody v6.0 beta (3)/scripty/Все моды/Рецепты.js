//created 
//by Fack

ModPE.addFurnaceRecipe(22, 505, 264); //Кристалл

ModPE.addCraftRecipe(500, 1, 18, [42, 1, 42, 1, 42, 1, 264, 1, 264, 1]); //Молот

ModPE.addCraftRecipe(506, 1, 1, [505, 1, 74, 1, 264, 1, 266, 1, 265, 1, 507, 1]); //Kvant Dimond Energrletic

ModPE.addCraftRecipe(507, 1, 1, [265, 1, 265, 1, 265, 1, 74, 1, 74, 1, 505, 1, 265, 1, 265, 1, 265, 1]); //Kvant CPU

ModPE.addCraftRecipe(508, 1, 1, [276, 10, 74, 1, 507, 1, 74, 1, 264, 1, 266, 1, 265, 1, 265, 1, 507, 1]);

ModPE.addCraftRecipe(302, 1, 1, [42, 1, 42, 1, 42, 1, 42, 1, 310, 1, 506, 1]);

ModPE.addCraftRecipe(303, 1, 1, [42, 1, 42, 1, 42, 1, 42, 1, 42, 1, 42, 1, 311, 1, 507, 1, 506, 1]);

ModPE.addCraftRecipe(304, 1, 1, [42, 1, 42, 1, 42, 1, 42, 1, 42, 1, 42, 1, 312, 1, 507, 1, 506, 1]);

ModPE.addCraftRecipe(305, 1, 1, [42, 1, 42, 1, 42, 1, 42, 1, 313, 1, 506, 1, 507, 1]);


