/*----[От автора]----*/
/*
Для профессионалов наверное покажется что скрипт нубский или вы скажете "такой есть", но все же... 
А для новичков трудным, если что учите JavaScript. Себе тоже желаю его полностью выучить. 

Скрипт писал: Дмитрий Вашурин (vk.com/dimav243)
Прошу не изменять!!! 
*/
/*-------------[Переменные]-------------*/
var rub = 0;
var job = 0;
var admin = false;
var cop = 0;
var tn = 1;
var mg = 0;
var jump = 0;
/*-------------[З/П для работ]----------*/
function destroyBlock(x, y, z, side)
{
 if(job == 1)
 {
  itemId = Player.getCarriedItem();
  blockId = getTile(x,y,z);
  if(itemId == 257 || itemId == 270 || itemId == 274 || itemId == 278 || itemId == 285)
  {
   if(blockId == 1 || blockId == 4 || blockId == 24 || blockId == 112 || blockId == 14 || blockId == 15 || blockId == 16 || blockId == 73 || blockId == 74 || blockId == 49 || blockId == 48 || blockId == 21 || blockId == 56 || blockId == 52 || blockId == 129 || blockId == 153)
   { 
    cop = parseInt(cop)+20;
    //clientMessage("3");
   }
   }
  }
 if(job == 2)
 {
  itemId = Player.getCarriedItem();
  blockId=getTile (x, y, z);
  if(itemId == 258 || itemId == 271 || itemId == 275 || itemId == 279 || itemId == 286)
  {
   if(blockId == 17)
   {
    //clientMessage("j2");
    cop = parseInt(cop)+40;
   }
  }
 }
}
/*--------------[З/П для работ 2]------------*/
function deathHook(murderer, victim)
{
 if(job == 3)
 {
  itemId = Player.getCarriedItem();
  if(itemId == 268 || itemId == 283 || itemId == 276 || itemId == 272 || itemId == 267 || itemId == 261)
  {
   cop = parseInt(cop)+45;
   //clientMessage("j3");
  }
 }
}
/*--------------[Проверка копеек]-------------*/
function modTick()
{
 if(tn==1)
 {
  tn = tn + 1;
 }
 else if(tn==20)
 {
  tn=1;
  //clientMessage("500");
  {
   if(cop<3000)
   {
    if(cop>100)
    {
    cop = parseInt(cop)-100;
    rub = parseInt(rub)+1;
    }
   }
  }
 }
 if(tn!=1)
 {
  tn = tn + 1;
 }
}
/*--------------[Командная система]---------*/
function procCmd(cmd) {
var p = cmd.split(" ");
var command = p[0];
switch(command) {
 case 'job': {
 if(job == 0) {
  if(p[1] == 'miner') {
   clientMessage("Вы устроились на работу -шахтер-");
   job = 1;
   break; }         
  if(p[1] == 'woodcutter') {
   clientMessage("Вы устроились на работу -лесоруб-");
   job = 2;
   break; } }
  if(p[1] == 'hunter') {
   clientMessage("Вы устроились на работу -охотник-");
   job = 3;   
   break; }
  if(p[1] == 'list') {
   clientMessage("Работы:\n /miner (шахтер)\n /woodcutter (дровосек)\n /hunter (охотник)");
   break; }
  if(p[1] == 'status') {
   clientMessage("Вы работаете на -" +job+ "- \n 0. Без работы\n 1. шахтер\n 2. лесоруб\n 3. охотник");
   break; }
  if(p[1] == 'bay') {
   clientMessage("Вы уволены");
   job = 0;
   break; }
   break; }
 case 'money': {
  clientMessage(+rub+ " руб. " +cop+ " коп.");
  break; }
 case 'rs': {
   clientMessage(ChatColor.RED+"Всё сброшено");
   rub = 0;
   admin = true;
   job = 0;
   cop = 0;
   mg = 0;
   jump = 0;
   ModPE.removeData("rub");
   ModPE.removeData("jobs");
   ModPE.removeData("cop");
   ModPE.removeData("mg");
   ModPE.removeData("jump");
   break; }
 case 'help': {
  if(p[1] == 'economics') {
   clientMessage("Команды связанные с экономикой:\n /money-Узнать баланс\n /buy <номер товара>\n /shop-Магазин");
   break; }
  if(p[1] == 'job') {
   clientMessage("Команды связанные с работой:\n /job list-Список работ\n /job status-о работе\n /job bay уволиться\n /job название работы");
   break; }
   clientMessage("help <economics,job>");
   break; }
 case 'ZiP': {
  if(admin == true) {
   if(p[1] == 'rub') {
    rub = 2737;
    break; }
   if(p[1] == 'cop') {
    cop = 101;
    break; } } }
 case 'shop': {
  if(mg == 4) {
   clientMessage("Магазин:\n Супер прыжок " +ChatColor.RED+ "-1-" +ChatColor.WHITE+ "1000руб\n Пополнить жизни " +ChatColor.RED+ "-2-" +ChatColor.WHITE+ "10руб\n Х-5 (В пять раз больше жизней) " +ChatColor.RED+ "-3-" +ChatColor.WHITE+ "40руб");
   break; } }
 case 'buy': {
  if(mg == 4) {
  if(p[1] == '1') {
   if(rub<10000000) {
    if(rub>1000) {
     clientMessage("Супер прыжок -куплен-\n Для прыжка тапните стрелой");
     jump = 1;
     rub = parseInt(rub)-1000;
     break; } } } 
    if(p[1] == '2') {
    if(rub<10000000) {
    if(rub>5) {
     clientMessage("Жизни +20");
     rub = parseInt(rub)-5;
     Player.setHealth(20);
     break; } } } 
    if(p[1] == '3') {
    if(rub<100000000) {
    if(rub>40) {
     clientMessage("Жизни Х-5");
     rub = parseInt(rub)-40;
     Player.setHealth(100);
     break; } } } 
     }
     }
}
}

/*--[Постройка магазина(нубский вириант)]--*/
function useItem(x, y, z, itemId, blockId, side)
{
 if(mg == 0)
 {
  if(itemId == 5 && blockId == 57)
  {
   mg = 1;
   clientMessage("На постройку деньги могут уйти в минус");
   setTile(x,y,z,5);
   setTile(x,y+1,z,57);
   addItemInventory(5,-1);
  }
 }
 if(itemId == 17 && blockId == 57)
 {
  if(mg == 1)
  {
   rub = parseInt(rub)-70;
   setTile(x-1,y-1,z-1,17);
   setTile(x+1,y-1,z-1,17);
   setTile(x-1,y-1,z+1,17);
   setTile(x+1,y-1,z+1,17);
   setTile(x,y-1,z-1,0);
   setTile(x-1,y-1,z,0);
   setTile(x,y-1,z+1,0);
   setTile(x+1,y-1,z,0);
   setTile(x-1,y,z-1,17);
   setTile(x+1,y,z-1,17);
   setTile(x-1,y,z+1,17);
   setTile(x+1,y,z+1,17);
   setTile(x,y,z-1,0);
   setTile(x-1,y,z,0);
   setTile(x,y,z+1,0);
   setTile(x+1,y,z,0);
   setTile(x-1,y+1,z-1,17);
   setTile(x+1,y+1,z-1,17);
   setTile(x-1,y+1,z+1,17);
   setTile(x+1,y+1,z+1,17);
   setTile(x,y+1,z-1,17);
   setTile(x-1,y+1,z,17);
   setTile(x,y+1,z+1,17);
   setTile(x+1,y+1,z,17);
   setTile(x,y+1,z,17);
   clientMessage("Построено" +ChatColor.RED+ "\n Не советую разбирать");
   addItemInventory(17,-1);
   mg = 2;
  }
 }
 if(itemId == 280 && blockId == 57)
 {
  if(mg == 2);
  {
   if(getTile(x-1,y-1,z-1,17) && getTile(x+1,y-1,z-1,17) && getTile(x-1,y-1,z+1,17) && getTile(x+1,y-1,z+1,17) && getTile(x-1,y,z-1,17) && getTile(x+1,y,z-1,17) && getTile(x-1,y,z+1,17) && getTile(x+1,y,z+1,17) && getTile(x-1,y+1,z-1,17) && getTile(x+1,y+1,z-1,17) && getTile(x-1,y+1,z+1,17) && getTile(x+1,y+1,z+1,17) && getTile(x,y+1,z-1,17) && getTile(x-1,y+1,z,17) && getTile(x,y+1,z+1,17) && getTile(x+1,y+1,z,17) && getTile(x,y+1,z,17) && getTile(x,y-1,z,5))  
   {
    mg = 4;
    clientMessage("Магазин активирован\n Команды /shop,/buy доступны");
    
   }
  }
 }
if(jump == 1)
{
if(itemId == 262)
 {
  setVelY(Player.getEntity(),1);
 }
}
}
/*[Система сохранение достижений(прогресса)]*/
function leaveGame()
{
  ModPE.saveData("rub", rub);
  ModPE.saveData("jobs", job);
  ModPE.saveData("cop", cop);
  ModPE.saveData("mg", mg);
  ModPE.saveData("jump", jump);
}
function newLevel()
{
  rub = ModPE.readData("rub");
  job = ModPE.readData("jobs");
  cop = ModPE.readData("cop");
  mg = ModPE.readData("mg");
  jump = ModPE.readData("jump");
  clientMessage(ChatColor.WHITE+"[ZiP]" +ChatColor.RED+" by ZordanIP");
  clientMessage(ChatColor.WHITE+"[ZiP]" +ChatColor.RED+" To help-> /help");
}
/*---------------[……]---------------*/





