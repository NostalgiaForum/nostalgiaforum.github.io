//Created
//by Fack

ModPE.setItem(505, "ender_eye", 1, "Kvant Dimond")
ModPE.setItem(506, "ender_pearl", 2, "Kvant Dimond Energetic")
ModPE.setItem(507, "item_frame", 3, "Kvant CPU")
ModPE.setItem(508, "fireworks", 4, "Kvant Sword

function attackHook(attacker, victim)
{
  if(getCarriedItem()==508)
  {
var hit = Entity.getHealth(victim) -20;
}
}