//bagfix
//created by Fack

function useItem(x,y,z,itemId,blockId)
{
if(itemId==500&&blockId==95)
{
setTile(x,y,z,0)
addItemInventory(95,1)
}
}