// Achievements by @SCARY_ENDERMAN
// V1.1 RUS
//Перевод делал nekkit_o

var a1 = 1;
var a2 = 1;
var a3 = 1;
var a4 = 1;
var a5 = 1;
var a6 = 1;
var a7 = 1;
var a8 = 1;
var a9 = 1;
var a10 = 1;
var a11 = 1;
var a12 = 1;
var a13 = 1;
var a14 = 1;
var a15 = 1;


function attackHook (attacker, victim) {

if (a1 == 1) {
if (Entity.getEntityTypeId(victim) == 32 || Entity.getEntityTypeId(victim) == 33 || Entity.getEntityTypeId(victim) == 34 || Entity.getEntityTypeId(victim) == 35 || Entity.getEntityTypeId(victim) == 36/* && a1 == 1*/) {
a1 = 2;
clientMessage("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Охотник На Монстров");
}
}

if (a2 == 1) {
if (Entity.getEntityTypeId(victim) == 11) {
a2 = 2;
clientMessage("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Мясник");
}
}

if (a3 == 1) {
if (Entity.getEntityTypeId(victim) == 34 && getCarriedItem() == 261) {
a3 = 2;
clientMessage("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Снайперская Дуэль");
}
}

}


function procCmd(cmd) {
   var command = cmd.split(" ");
  
 	if(command[0] == "сохранить") {
ModPE.saveData("a1", a1);
ModPE.saveData("a2", a2);
ModPE.saveData("a3", a3);
ModPE.saveData("a4", a4);
ModPE.saveData("a5", a5);
ModPE.saveData("a6", a6);
ModPE.saveData("a7", a7);
ModPE.saveData("a8", a8);
ModPE.saveData("a9", a19);
ModPE.saveData("a10", a10);
ModPE.saveData("a11", a11);
ModPE.saveData("a12", a12);
ModPE.saveData("a13", a13);
ModPE.saveData("a14", a14);
ModPE.saveData("a15", a15);
clientMessage("Прогресс Сохранен!!!");
 }
 
 	if(command[0] == "загрузить") {
a1 = ModPE.readData("a1");
a2 = ModPE.readData("a2");
a3 = ModPE.readData("a3");
a4 = ModPE.readData("a4");
a5 = ModPE.readData("a5");
a6 = ModPE.readData("a6");
a7 = ModPE.readData("a7");
a8 = ModPE.readData("a8");
a9 = ModPE.readData("a9");
a10 = ModPE.readData("a10");
a11 = ModPE.readData("a11");
a12 = ModPE.readData("a12");
a13 = ModPE.readData("a13");
a14 = ModPE.readData("a14");
a15 = ModPE.readData("a15");
clientMessage("Прогресс Загружен");
 }
 
 }

 
function destroyBlock(x, y, z, side) {

if (a4 == 1) {
if(getTile(x, y, z) == 17) {
a4 = 2;
clientMessage("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Нарубить дров");
}
}

if (a5 == 1) {
if(getTile(x, y, z) == 56 && getCarriedItem() == 257) {
a5 = 2;
clientMessage("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] АЛМАЗЫ !");
}
}

}
 
 
function leaveGame() {
ModPE.saveData("a1", a1);
ModPE.saveData("a2", a2);
ModPE.saveData("a3", a3);
ModPE.saveData("a4", a4);
ModPE.saveData("a5", a5);
ModPE.saveData("a6", a6);
ModPE.saveData("a7", a7);
ModPE.saveData("a8", a8);
ModPE.saveData("a9", a19);
ModPE.saveData("a10", a10);
ModPE.saveData("a11", a11);
ModPE.saveData("a12", a12);
ModPE.saveData("a13", a13);
ModPE.saveData("a14", a14);
ModPE.saveData("a15", a15);
}


function useItem(x, y, z, itemId, blockId) {

if (a6 == 1) {
if (itemId == 58) {
a6 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Рабочий стол");
}
}

if (a7 == 1) {
if (itemId == 61) {
a7 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Горячая штучка");
}
}

if (a8 == 1) {
if (itemId == 270) {
a8 = 2;
clientMessage ("[ACHIEVEMENT GET] Пора в шахту !");
}
}

if (a9 == 1) {
if (itemId == 265) {
a9 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Куй железо пока...");
}
}

if (a10 == 1) {
if (itemId == 290) {
a10 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Время для фермы !");
}
}

if (a11 == 1) {
if (itemId == 297) {
a11 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Хлеб насущный");
}
}

if (a12 == 1) {
if (itemId == 354) {
a12 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Это Ложь");
}
}

if (a13 == 1) {
if (itemId == 274 || itemId == 257 || itemId == 285 || itemId == 278) {
a13 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Обновка !");
}
}

if (a14 == 1) {
if (itemId == 268) {
a14 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] К бою готов !");
}
}

if (a15 == 1) {
if (itemId == 47) {
a15 = 2;
clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] Библиотекарь");
}
}

}