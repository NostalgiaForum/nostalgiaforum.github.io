/* Автор tocaunt */

/* Внимание: некоторые функции отключил. Можете не пробовать включать их, или получите ошибки/баги */

/*
© tocaunt, 2013-2014, ModPE script
Каждый имеет право воспроизводить, распространять и/или вносить изменения в
настоящий Документ в соответствии с условиями GNU Free Documentation License,
Версией 1.2 или любой более поздней версией, опубликованной Free Software
Foundation;
данный Документ не содержит Неизменяемых разделов, не содержит
Текста, помещаемого на первой странице обложки и не содежит Текста,
помещаемого на последней страницы обложки.
Копия лицензионного соглашения включена в секцию, озаглавленную "GNU
Free Documentation License".
*/

/*
Version 1.2
Copyright (C) 2013-2014 ModPE script,
Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.
*/

/*---Создаём переменные в которых будут распологатся координаты шахт---*/
var ex;
var ey;
var ez;
var bridgeX;
var bridgeZ;
var acrossBridgeX;
var acrossBrigeZ;
/*---Создаём переменные в которых будут распологатся координаты шахт---*/

/*---Создаём массивы в которых будут распологатся значения, от которых зависит генерация шахты---*/
var mine = new Array;
mine[0] = 255;
mine[1] = false;
/*---Создаём массивы в которых будут распологатся значения, от которых зависит генерация шахты---*/

/*---Работаем с чатом---*/
function newLevel() 
{
var c=cmd.split(" ");
if(c[0]==mine)
{
clientMessage("[MINE] please use .mine help .");
}
if(c[0]=="mine" && c[1]=="generate");
{
   if(mine[1]==false)
      {
      clientMessage("Generating...");
      for(var i = 0;i<mine[0];i++)
         {
/*---Начинаем генерацию---*/
         generate();
/*---Начинаем генерацию---*/
         }
      }
    if(mine[1]==true)
      {
/*---Отказываемся генерировать---*/
      clientMessage("[MINE] шахты уже сгенерированы!");
/*---Отказываемся генерировать---*/
      }
}
if(c[0]=="mine" && c[1]=="help")
{
clientMessage("---[MINE]---");
clientMessage("mine generate - генерация шахт");
}
}
/*---Работаем с чатом---*/

/*---Генерируем шахты---*/
function generate()
{
/*---Создаем рандомные координаты шахт---*/
ex = random(16,240);
ey = random(11,27);
ez = random(16,240);
/*---Создаем рандомные координаты шахт---*/

for(var i = 0;i<random(10,40);i++) //генерируем одну шахту 30 блоков подряд
   {
      if(checkMine()!=0)
	  {
      clearArea(i); //очищяем территорию
      acrossclearArea(i); //очищаем территорию паралельно
      Ornamentation(i); //ставим заборы, факелы, доски
      acrossOrnamentation(i); //ставим заборы, факелы, доски для паралельных шахт
	  }
   }
}
/*---Генерируем шахты---*/

function bridge(x,y,z)
{
if(getTile(x,y,z)==0)
   {
   setTile(x,y,z,5);
   }
}

/*---Оформляем шахты---*/
function Ornamentation(m)
{
setTile(ex+random(-1,1),ey+1,ez+m,1);
if(random(1,6)==1)
   {
   setTile(ex+1,ey,ez+m,85);
   setTile(ex+1,ey-1,ez+m,85);
   setTile(ex-1,ey,ez+m,85);
   setTile(ex-1,ey-1,ez+m,85);
   setTile(ex+1,ey+1,ez+m,5);
   setTile(ex-1,ey+1,ez+m,5);
   random(1,5)==0?setTile(ex,ey+1,ez-1+m,50):false;
   random(1,3==1)?setTile(ex,ey+1,ez+m,5):false;
   random(1,30)==1?setTile(ex+2,ey-1,ez+random(1,10),10 ):false;
   random(1,5)==1?setTile(ex+random(-1,1),ey+1,ez+random(1,7),30):false;
   random(1,1)==1?setTile(ex+random(-1,1),ey+1,ez+m+random(1,2),1):false;
   }
}

function acrossOrnamentation(m)
{
setTile(ex+m,ey+1,ez+random(-1,1),1);
if(random(1,6)==1 && checkMine != 0)
   {
   getTile(ex+m,ey-1,ez+1)==0?setTile(ex+m,ey-1,ez+1,85):false;
   getTile(ex+m,ey,ez-1)==0?setTile(ex+m,ey,ez-1,85):false;
   getTile(ex+m,ey-1,ez-1)==0?setTile(ex+m,ey-1,ez-1,85):false;
   getTile(ex+m,ey,ez+1)==0?setTile(ex+m,ey,ez+1,85):false;
   getTile(ex+m,ey+1,ez+1)==0?setTile(ex+m,ey+1,ez+1,5):false;
   getTile(ex+m,ey+1,ez)==0?setTile(ex+m,ey+1,ez,5):false;
   getTile(ex+m,ey+1,ez-1)==0?setTile(ex+m,ey+1,ez-1,5):false;
   getTile(ex+m,ey+1,ez)==0?setTile(ex-1+m,ey+1,ez,50):false;
   random(1,3==1)?setTile(ex+m,ey+1,ez,5):false;
   random(1,25)==10?setTile(ex+m+random(2,4),ey-1,ez+random(-1,1),10):false;
   random(1,3)==1?setTile(ex+random(-1,1),ey+1,ez+m,30):false;
   }
}
/*---Оформляем шахты---*/

/*---Очищяем территорию---*/
function acrossclearArea(m)
{
if(checkMine != 0)
   {
   setTile(ex+m,ey,ez,0);
   setTile(ex+m,ey,ez+1,0);
   setTile(ex+m,ey+1,ez+1,0);
   setTile(ex+m,ey+1,ez,0);
   setTile(ex+m,ey+1,ez-1,0);
   setTile(ex+m,ey,ez-1,0);
   setTile(ex+m,ey-1,ez-1,0);
   setTile(ex+m,ey-1,ez,0);
   setTile(ex+m,ey-1,ez+1,0);
   }
}

function clearArea(m)
{
if(checkMine != 0)
   {
   setTile(ex,ey,ez+m,0);
   setTile(ex+1,ey,ez+m,0);
   setTile(ex+1,ey+1,ez+m,0);
   setTile(ex,ey+1,ez+m,0);
   setTile(ex-1,ey+1,ez+m,0);
   setTile(ex-1,ey,ez+m,0);
   setTile(ex-1,ey-1,ez+m,0);
   setTile(ex,ey-1,ez+m,0);
   setTile(ex+1,ey-1,ez+m,0);
   }
}
/*---Очищяем территорию---*/

/*---Проверяем есть ли рядом шахта---*/
function checkMine()
{
for(var i = 0;i<15;i++)
   {
   getTile(ex+i,ey+i,ez+i)
   }
}
/*---Проверяем есть ли рядом шахта---*/

/*---Проверяем есть ли пол. Если нет, то ставим доски---*/
function checkBridge(x,y,z)
{
if(getTile(x,y,z)!=0)
   {
   setTile(x,y,z,5)
   }
}
/*---Проверяем, есть ли пол. Если нет, то ставим доски---*/

/*---Простой рандом---*/
function random(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}
/*---Простой рандом---*/

/*
Спасибо за прочтение скрипта ;)
Надеюсь вам понравится
Генерация занимает около одной минуты на очень слабых устройствах...
*/