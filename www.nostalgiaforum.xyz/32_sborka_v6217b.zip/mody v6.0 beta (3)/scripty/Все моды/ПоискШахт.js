//ModBagFix
//by Fack

function useItem(x,y,z,itemId,blockId)
{
if(itemId==500&&blockId==7)
{
setTile(x,y,z,0)
addItemInventory(95,1)
}
}


