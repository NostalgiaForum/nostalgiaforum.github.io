/*Взял скрипты на мобов и обьеденил ZordanIP



Сохранение авторства:
----------
Ендермен-(mutant_ender
By 
Created using ModPECreator by Arjay07)
----------
Солдат-(TBPM В© 2013 
IT IS BY TBPM TEAM)
----------
Остальные не указали себя в скрипте.

Работоспособность проверена!
*/







ModPE.setFoodItem(357, "Risk cookie", 0, 10, "Herobrine Spawner");
ModPE.setItem(357, "cookie", 0, 10, "Herobrine Spawner");

var atpms = 357;
var zipu = 0;

var cdown = 357;
var syjfd = 0;
var cicofr = 500;
var eifrh = 0;
var gygygyrwk = 500;
var evets = 0;

function newLevel()
{
clientMessage("Взял скрипты на мобов и обьеденил: " +ChatColor.RED+ "ZordanIP");
}

function useItem(x, y, z, itemId, blockId, side)
{
 if(itemId==289 && blockId == 22)
 {
 var zip = Level.spawnMob(x,y+1,z,35,"mob/creeper.png")
 var kiu = Level.spawnMob(x+1,y+1,z,33,"mob/minion.png")
  Entity.setRenderType(zip,14)
  Entity.setHealth(zip,250)
  Entity.setHealth(kiu,5)
 }
 if(itemId==265)
 {
  Level.spawnMob(x,y+1,z,33,"mob/minion.png")
 }
 if(itemId==344)
 {
  skelly=Level.spawnMob(x, y+1, z, 34);
  spider=Level.spawnMob(x, y+1, z,35);
  rideAnimal(skelly, spider);
 }
 if(itemId==288)
 {
  var qwe = Level.spawnMob(x, y+1, z, 32, "mob/char.png");
Entity.setRenderType(qwe, 3);
Entity.setHealth(qwe, 20);
wrq=Entity.spawnMob(x, y+1, z, 11);

rideAnimal(qwe, wrq);
 }
 if(itemId==357)
 {
  var ewq = Level.spawnMob(x, y + 1, z, 32, "mob/Herobrine.png");
Entity.setRenderType(ewq, 3);
Entity.setHealth(ewq,200);
syjfd = 1;
clientMessage("Herobrine Joined The Game");
 }
 if(itemId==266)
 {
  var stve = Level.spawnMob(x, y + 1, z, 11, "mob/downloadnew.png");
Entity.setRenderType(stve, 3);
Entity.setHealth(stve, 20);
eifrh = 1;
clientMessage(ChatColor.BLUE + "JackFrostMod Create for " + ChatColor.GREEN + "IzaelOsuna");
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Привет, друг !");
 }
 if(itemId==259 && blockId==87)
 {
  var evts = Level.spawnMob(x, y + 1, z, 11, "mob/Girl.png");
Entity.setRenderType(evts, 3);
Entity.setHealth(evts,100);
evets = 1;
clientMessage("Милый,я в игре!");
 }
 if(itemId == 264)
 {
verx = Level.spawnMob(x,y+1,z,32,"mob/верх.png")
niz = Level.spawnMob(x,y+1,z,32,"mob/низ.png")
rideAnimal(verx,niz);
Level.setTime(9600)
Entity.setHealth(verx,150)
Entity.setHealth(niz,150)
 }
 if(itemId==351)
 {
  var zyt = Level.spawnMob(x, y + 1, z, 32, "mob/Enderbrine.png");
Entity.setRenderType(zyt, 3);
Entity.setHealth(zyt,100);
zipu = 1;
clientMessage("Я слуга Херобрина!Ты умрёшь!");
 }
}

function modTick()
{
if(syjfd==1)
{
cdown--;
var fws = Math.floor ((Math.random() * 10) + 1);
{
if(cdown==0&&fws==1)
{
clientMessage("< Herobrine > Чао");
cdown = 500;
}
else if(cdown==0&&fws==2)
{
clientMessage("< Herobrine > У меня есть Обсидиан");
cdown = 500;
}
else if(cdown==0&&fws==3)
{
clientMessage("< Herobrine > Мне скучно");
cdown = 500;
}
else if(cdown==0&&fws==4)
{
clientMessage("< Herobrine>Я гриферю твой дом");
cdown = 500;
}
else if(cdown==0&&fws==5)
{
clientMessage("< Herobrine > У меня 200 ХП!");
cdown = 500;
}
else if(cdown==0&&fws==6)
{
clientMessage("< Herobrine > Я пошёл убивать");
cdown = 500;
}
else if(cdown==0&&fws==7)
{
clientMessage("< Herobrine > У меня нет головы Нотча!");
cdown = 500;
}
else if(cdown==0&&fws==8)
{
clientMessage("< Herobrine > Я крут,а ты нуб!");
cdown = 500;
}
else if(cdown==0&&fws==9)
{
clientMessage("< Herobrine > Нотч тупица!");
cdown = 500;
}
else if(cdown==0&&fws==10)
{
clientMessage("< Herobrine > YOLOSWAG");
cdown = 500;
}
}
}
if(eifrh==1)
{
cicofr--;
var swr = Math.floor ((Math.random() * 21) + 12);
{
if(cicofr==0&&swr==12)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Дай алмазов !");
cicofr = 500;
}
else if(cicofr==0&&swr==13)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Люблю играть в MCPE !");
cicofr = 500;
}
else if(cicofr==0&&swr==14)
{
 clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "У меня есть канал на Ютубе");
cicofr = 500;
}
else if(cicofr==0&&swr==15)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "У меня 19 алмазов и 12 железа, но я не дам, яж скрипт лол");
cicofr = 500;
}
else if(cicofr==0&&swr==16)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Го в шахту");
cicofr = 500;
}
else if(cicofr==0&&swr==17)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Дай мне броню");
cicofr = 500;
}
else if(cicofr==0&&swr==18)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Давай снимем лп");
cicofr = 500;
}
else if(cicofr==0&&swr==19)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Я видел ХЕРОБРИНА!");
cicofr = 500;
}
else if(cicofr==0&&swr==20)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Я люблю MCPE :D ");
cicofr = 500;
}
else if(cicofr==0&&swr==21)
{
clientMessage(ChatColor.GOLD + "<JackFrostMiner> " + ChatColor.AQUA + "Ты смотришь Лололошку?");
cicofr = 500;
}
}
}
if(evets==1)
{
gygygyrwk--;
var syt = Math.floor ((Math.random() * 31) + 22);
{
if(gygygyrwk==0&&syt==22)
{
clientMessage("< Аня > Пойдём погуляем?");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==23)
{
clientMessage("< Аня > Моё сердце принадлежит тебе!");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==24)
{
clientMessage("< Аня > Мне скучно!");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==25)
{
clientMessage("< Аня >Я готовлю тебе обед!");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==26)
{
clientMessage("< Аня > У меня сердце болит!!");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==27)
{
clientMessage("< Аня > Я пошла готовить.");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==28)
{
clientMessage("< Аня > У меня нет маникюра!!");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==29)
{
clientMessage("< Аня > Ты такой крутой!!");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==30)
{
clientMessage("< Аня > Херобрин тупица,а Нотч няшка!!");
gygygyrwk = 500;
}
else if(gygygyrwk==0&&syt==31)
{
clientMessage("< Аня > Хихихихихи!");
gygygyrwk = 500;
}
}
}
}






function attackHook(attacker,victim)
{
if(Entity.getEntityTypeId(victim)==32&&syjfd==1)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
}
if(Entity.getEntityTypeId(victim)==11&&eifrh==1)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
}
if(Entity.getEntityTypeId(victim)==11&&evets==1)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
}
if(Entity.getEntityTypeId(victim)==32&&zipu==1)
{
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "random.hurt", 100, 30);
}
}

function deathHook(attacker, victim)
{
if(Entity.getEntityTypeId(victim)==32&&syjfd==1)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 268, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 213, 1, 15);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 8, 19, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 265, 55, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 276, 1, 0);
syjfd = 0;
clientMessage("Herobrine Disconnected From The Game");
}
if(Entity.getEntityTypeId(victim)==11&&eifrh==1)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 456, 37, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 391, 1, 15);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 266, 19, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 261, 1, 31);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 314, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 264, 80, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 313, 2, 31);
eifrh = 0;
clientMessage(ChatColor.AQUA + "Ну за чтооо");
}
if(Entity.getEntityTypeId(victim)==11&&evets==1)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 268, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 213, 1, 15);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 8, 19, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 265, 55, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 501, 1, 0);
evets = 0;
clientMessage("Прощай милый!");
}
if(Entity.getEntityTypeId(victim)==32&&zipu==1)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 357, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 357, 1, 15);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 357, 19, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 357, 55, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 357, 1, 0);
zipu = 0;
clientMessage("Хозяин убьёт тебя!");
}
}
