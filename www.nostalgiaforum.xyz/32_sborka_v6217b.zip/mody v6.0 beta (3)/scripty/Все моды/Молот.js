ModPE.setItem(500, "hopper", 0, "Молот")


function attackHook(attacker, victim)
{
  if(getCarriedItem()==500)
  {
var hit = Entity.getHealth(victim) -18;
Entity.setHealth(victim, hit);
Entity.setFireTicks(victim,12)
}
}

function useItem(x,y,z,itemId,blockId,side)  
}      
if(itemId==500&&blockId==3)
{
explode(x,y,z,2.0)
}
if(itemId==500&&blockId==2)
{
explode(x,y,z,2.0)
}
if(itemId==500&&blockId==1)
{
explode(x,y,z,3.0)
} 
if(itemId==500&&blockId==17)
{
        setTile(x, y, z, 0);       
	    Level.dropItem(x,y,z,1,5, 4);
       }
if(itemId==500&&blockId==12)
{
explode(x,y,z,2.0)
} 
if(itemId==500&&blockId==24)
{
explode(x,y,z,2.0)
}
if(itemId==500&&blockId==57)
{       
       Player.setArmorSlot(0 ,310, 1)
       Player.setArmorSlot(2 ,312, 1)
       Player.setArmorSlot(1 ,311, 1)
       Player.setArmorSlot(3 ,313, 1)
       Player.setHealth(32767);
                 clientMessage("Вы властелин молота!")
}
}