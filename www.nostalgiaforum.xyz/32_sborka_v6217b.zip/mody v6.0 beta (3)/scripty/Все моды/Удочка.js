ModPE.setFoodItem (502, "fish", 6, 1, "Fish"); 
ModPE.setFoodItem (503, "fish_cooked", 7, 5, "Cooked fish"); 
ModPE.setItem (504, "fishing_rod_uncast", 5, "Fishing"); 

ModPE.addCraftRecipe(504, 1, 1, [280, 1, 280, 1, 287, 1, 287, 1]);
ModPE.addFurnaceRecipe(502, 503, 0);

function useItem (x, y, z, itemId, blockId)
{
if (itemId==504&&blockId==8)
{
addItemInventory (502, 1)
}
}