var sound=0;
var active=0;
var js=0;
var ticks = 0;
ModPE.setItem(402,3,6,"equal trade");
function useItem(x,y,z,itemId,blockId,side){
var spawn = 0;
var der = 0;
if(itemId==0){
addItemInventory(402,1,0);
addItemInventory(3,64);
}
}



function procCmd(cmd){
 var cmd = cmd.split(" "); 

 if(cmd[0]=="chicken"){ 
Entity.setRenderType(getPlayerEnt(),6);
Entity.setMobSkin(getPlayerEnt(),"mob/chicken.png")
 
}

if(cmd[0]=="sheep"){
Entity.setRenderType(getPlayerEnt(),9);
Entity.setMobSkin(getPlayerEnt(),"mob/sheep.png")

}
if(cmd[0]=="pig"){ 
Entity.setRenderType(getPlayerEnt(),8);
Entity.setMobSkin(getPlayerEnt(),"mob/pig.png")
}
if(cmd[0]=="cow"){ 
Entity.setRenderType(getPlayerEnt(),7);
Entity.setMobSkin(getPlayerEnt(),"mob/cow.png")
}
if(cmd[0]=="mob"){ 
Entity.setRenderType(getPlayerEnt(),parseInt(cmd[1]));
Entity.setMobSkin(getPlayerEnt(),"gui/terrain.png")
 }
if(cmd[0]=="skeleton"){ 
Entity.setRenderType(getPlayerEnt(),12);
Entity.setMobSkin(getPlayerEnt(),"mob/skeleton.png")
}
if(cmd[0]=="spider"){ 
Entity.setRenderType(getPlayerEnt(),13);
Entity.setMobSkin(getPlayerEnt(),"mob/spider.png")
}
if(cmd[0]=="play"){
switch(cmd[1]){
case 'zombie':{
sound='mob.zombie';
break;
}
case 'spider':{
sound='mob.spider';
break;
}
case 'sheep':{
sound='mob.sheep';
break;
}
case 'cow':{
sound='mob.cow';
break;
}
case 'skeleton':{
sound='mob.skeleton';
break;
}
case 'chicken':{
sound='mob.chicken';
break;
}
case 'spider':{
sound='mob.spider';
break;
} 
}
ticks=parseInt(cmd[2]);
}
if(cmd[0]=="zombie"){ 
Entity.setRenderType(getPlayerEnt(),3
);
Entity.setMobSkin(getPlayerEnt(),"mob/zombie.png")
} 
if(cmd[0]=="player"){ 
Entity.setRenderType(getPlayerEnt(),3
);
Entity.setMobSkin(getPlayerEnt(),"mob/char.png")
}
if(cmd[0]=="zombiepigmen"){ 
Entity.setRenderType(getPlayerEnt(),11
);
Entity.setMobSkin(getPlayerEnt(),"mob/zombiepig.png")
clientMessage("bugs hard");
} 
if(cmd[0]=="tnt"){ 
Entity.setRenderType(getPlayerEnt(),2
);
Entity.setMobSkin(getPlayerEnt(),"mob/zombie.png")
} 
 if(cmd[0]=="block"){ 
Entity.setRenderType(getPlayerEnt(),20
);
Entity.setMobSkin(getPlayerEnt(),"mob/zombie.png")
} 
 if(cmd[0]=="arrow"){ 
Entity.setRenderType(getPlayerEnt(),15
);
Entity.setMobSkin(getPlayerEnt(),"mob/zombie.png")
} 
 if(cmd[0]=="creeper"){ 
Entity.setRenderType(getPlayerEnt(),14
);
Entity.setMobSkin(getPlayerEnt(),"mob/creeper.png")
}
if(cmd[0]=="break"){
ticks=0;
} 
}
 
function destroyBlock(x,y,z,side){

}

function modTick(){
if(ticks=!0&&js=!ticks){
js=js+1;
}
if(ticks==js&&ticks!=0){
Level.playSound(getPlayerX(),getPlayerY(),getPlayerZ(),sound, 150, 0); 
js=0;
}
}
