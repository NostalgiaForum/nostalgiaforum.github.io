ModPE.setFoodItem (502, 92, 7, 1, "Fish");  
ModPE.setItem (504, "fishing_rod_uncast", 6, "Fishing");

function useItem (x, y, z, itemId, blockId)
{
if (itemId==504&&blockId==79)
{
addItemInventory (502, 1)
}
if (itemId==280&&blockId==35)
{
setTile (x, y, z, 0)
addItemInventory (504, 1)
}
}