
ModPE.setItem(505, "ender_eye", 1, "Kvant Dimond")
ModPE.setItem(506, "ender_pearl", 2, "Kvant Dimond Energetic")
ModPE.setItem(507, "item_frame", 3, "Kvant CPU")
ModPE.setItem(508, "fireworks", 4, "Kvant Sword")

ModPE.addCraftRecipe(506, 1, 1, [505, 1, 74, 1, 264, 1, 266, 1, 265, 1, 507, 1]); 

ModPE.addCraftRecipe(507, 1, 1, [265, 1, 265, 1, 265, 1, 74, 1, 74, 1, 505, 1, 265, 1, 265, 1, 265, 1]);

ModPE.addCraftRecipe(508, 1, 1, [276, 10, 74, 1, 507, 1, 74, 1, 264, 1, 266, 1, 265, 1, 265, 1, 507, 1]);

ModPE.addFCraftRecipe(505, 1, 1 [264, 1, 351, 1]);

ModPE.addCraftRecipe(302, 1, 1, [42, 1, 42, 1, 42, 1, 42, 1, 310, 1, 506, 1]);

ModPE.addCraftRecipe(303, 1, 1, [42, 1, 42, 1, 42, 1, 42, 1, 42, 1, 42, 1, 311, 1, 507, 1, 506, 1]);

ModPE.addCraftRecipe(304, 1, 1, [42, 1, 42, 1, 42, 1, 42, 1, 42, 1, 42, 1, 312, 1, 507, 1, 506, 1]);

ModPE.addCraftRecipe(305, 1, 1, [42, 1, 42, 1, 42, 1, 42, 1, 313, 1, 506, 1, 507, 1]);

ModPE.addCraftRecipe(504, 1, 1, [280, 1, 280, 1, 287, 1, 287, 1]);

ModPE.addFurnaceRecipe(502, 1, 1)