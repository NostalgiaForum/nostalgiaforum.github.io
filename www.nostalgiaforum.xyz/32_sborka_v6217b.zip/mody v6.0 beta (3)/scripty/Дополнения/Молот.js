ModPE.setItem(500, "hopper", 0, "Молот")

var Ypos=0;
var i=1;
var Ydiff=0;

function attackHook(attacker, victim)
{
  if(getCarriedItem()==500)
  {
var hit = Entity.getHealth(victim) -18;
Entity.setHealth(victim, hit);
Entity.setFireTicks(victim,12)
}
function modTick()
{
  if(getCarriedItem()==500)
  {
      if(i==1)
      {
        Ypos=getPlayerY();
        
        i = i + 1;
      }
      else if(i==3)
      {
        i=1;
        
        Ydiff=getPlayerY()-Ypos;
        setVelY(getPlayerEnt(),Ydiff);        
        Ydiff=0;
        
      }
  if(i!=1)
  {
  i = i + 1;
  }
}
}

}

function useItem(x,y,z,itemId,blockId,side)  
{      
if(itemId==500&&blockId==3)
{
explode(x,y,z,2.0)
}
if(itemId==500&&blockId==2)
{
explode(x,y,z,2.0)
}
if(itemId==500&&blockId==1)
{
explode(x,y,z,2.0)
} 
if(itemId==500&&blockId==17)
{
        setTile(x, y, z, 0);       
	    Level.dropItem(x,y,z,1,5, 4);
       }
if(itemId==500&&blockId==12)
{
explode(x,y,z,2.0)
} 
if(itemId==500&&blockId==24)
{
explode(x,y,z,2.0)
}
if (itemId==500&&blockId==7)
{
setTile (x, y, z, 0)
addItemInventory (7, 1)
}
if (itemId==500&&blockId==95)
{
setTile (x, y, z, 0)
addItemInventory (95, 1)
}
if(itemId==500&&blockId==57)
{   
       Player.setArmorSlot(0 ,310, 1)
       Player.setArmorSlot(2 ,312, 1)
       Player.setArmorSlot(1 ,311, 1)
       Player.setArmorSlot(3 ,313, 1)
       Player.setHealth(32767);
                 clientMessage("Вы властелин молота!")
}
if(itemId==500&&blockId==78)
{
explode(x,y,z,2.0)
}
if(itemId==500&&blockId==4)
{
explode(x,y,z,2.0)
}
if(itemId==500&&blockId==13)
{
explode(x,y,z,2.0)
}
}