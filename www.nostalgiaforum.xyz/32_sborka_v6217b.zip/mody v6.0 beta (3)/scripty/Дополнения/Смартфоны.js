//created
//by Fack

ModPE.setItem (510, "comparator", 8, "iPhone 6")
ModPE.setItem (511, "carrot_golden", 9, "Samsung Galaxy LOPATA")

function useItem (x, y, z, itemId, blockId)
{
if (itemId==511&&blockId==2)
{
addItemInventory (3, 1)
setTile (x, y, z, 0)
  }
  if (itemId==511&&blockId==3)
  {
  addItemInventory (3, 1)
  setTile (x, y, z, 0)
    }
    if (itemId==511&&blockId==12)
    {
    addItemInventory (12, 1)
    setTile (x, y, z, 0)
      }
      if (itemId==511&&blockId==13)
      {
      addItemInventory (13, 1)
      setTile (x, y, z, 0)
        }
        if (itemId==260&&blockId==41)
        {
        clientMessage ("[ДОСТИЖЕНИЕ ПОЛУЧЕНО] МАЖОР")
            setTile (x, y, z, 0)
            addItemInventory (510, 1)
            }
            if (itemId==277&&blockId==102)
            {
            setTile (x, y, z, 0)
            addItemInventory (511, 1)
              }
              if (itemId==511&&blockId==78)
              {
              setTile (x, y, z, 0)
              addItemInventory (332, 1)
                }
                if (itemId==511&&blockId==80)
                {
                setTile (x, y, z, 0)
                addItemInventory (332, 4)
                }
}

