//Fack's
//Prodaction

var armor302 = false;
var armor303 = false;
var armor304 = false;
var armor305 = false;
var Xpos=0;
var Ypos=0;
var Zpos=0;
var i=1;
var u=1;
var Xdiff=0;
var Ydiff=0;
var Zdiff=0;

ModPE.setItem(505, "ender_eye", 1, "Kvant Dimond")
ModPE.setItem(506, "ender_pearl", 2, "Kvant Dimond Energetic")
ModPE.setItem(507, "item_frame", 3, "Kvant CPU")
ModPE.setItem(508, "fireworks", 4, "Kvant Sword")
ModPE.setItem(509, "experience_bottle", 5, "Kvant Bur")

function deathHook(attacker, victim)
{
if(Entity.getEntityTypeId(victim)==32&&steve==1)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 268, 1, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 331, 1, 15);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 305, 19, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 265, 10, 0);
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 508, 1, 0);
steve = 0;
clientMessage("Herobrine Disconnected From The Game");
}
}

function useItem (x, y, z, itemId, blockId)
{
if (itemId==505&&blockId==249)
{
setTile (x, y, z, 0)
addItemInventory (506, 1)
addItemInventory (505, -1)
}
if (itemId==505&&blockId==42)
{
setTile(x, y, z, 249);
}
if (itemId==506&&blockId==249)
{
setTile (x, y, z, 0)
addItemInventory (507, 1)
addItemInventory (506, -1)
}
if (itemId==276&&blockId==249)
{
setTile (x, y, z, 0)
addItemInventory (508, 1)
}
if (itemId==331&&blockId==42)
{
setTile (x, y, z, 0)
var stve = Level.spawnMob(x, y + 1, z, 32, "mob/Robot.png");
Entity.setRenderType(stve, 3);
Entity.setHealth(stve,200);
steve = 1;
clientMessage("Robot: Вжиииик-вжиииик motherfucker");
}
if (itemId==310&&blockId==249)
{
setTile (x, y, z, 0)
addItemInventory (302, 1)
addItemInventory (310, -1)
}
if (itemId==311&&blockId==249)
{
setTile (x, y, z, 0)
addItemInventory (303, 1)
addItemInventory (311, -1)
}
if (itemId==312&&blockId==249)
{
setTile (x, y, z, 0)
addItemInventory (304, 1)
addItemInventory (312, -1)
}
if (itemId==313&&blockId==249)
{
setTile (x, y, z, 0)
addItemInventory (305, 1)
addItemInventory (313, -1)
}
if (itemId==278&&blockId==249)
{
setTile (x, y, z, 0)
addItemInventory (509, 1)
}
if (itemId==509&&blockId==1)
{
setTile (x, y, z, 0)
addItemInventory (4, 1)
}
if (itemId==509&&blockId==2)
{
setTile (x, y, z, 0)
addItemInventory (3, 1)
}
if (itemId==509&&blockId==3)
{
setTile (x, y, z, 0)
addItemInventory (3, 1)
}
if (itemId==509&&blockId==4)
{
setTile (x, y, z, 0)
addItemInventory (4, 1)
}
if (itemId==509&&blockId==5)
{
setTile (x, y, z, 0)
addItemInventory (5, 1)
}
if (itemId==509&&blockId==12)
{
setTile (x, y, z, 0)
addItemInventory (12, 1)
}
if (itemId==509&&blockId==13)
{
setTile (x, y, z, 0)
addItemInventory (13, 1)
}
if (itemId==509&&blockId==14)
{
setTile (x, y, z, 0)
addItemInventory (14, 1)
}
if (itemId==509&&blockId==15)
{
setTile (x, y, z, 0)
addItemInventory (15, 1)
}
if (itemId==509&&blockId==16)
{
setTile (x, y, z, 0)
addItemInventory (263, 1)
}
if (itemId==509&&blockId==17)
{
setTile (x, y, z, 0)
addItemInventory (17, 1)
}
if (itemId==509&&blockId==20)
{
setTile (x, y, z, 0)
addItemInventory (20, 1)
}
if (itemId==509&&blockId==21)
{
setTile (x, y, z, 0)
addItemInventory (21, 1)
}
if (itemId==509&&blockId==22)
{
setTile (x, y, z, 0)
addItemInventory (22, 1)
}
if (itemId==509&&blockId==24)
{
setTile (x, y, z, 0)
addItemInventory (24, 1)
}
if (itemId==509&&blockId==35)
{
setTile (x, y, z, 0)
addItemInventory (35, 1)
}
if (itemId==509&&blockId==41)
{
setTile (x, y, z, 0)
addItemInventory (41, 1)
}
if (itemId==509&&blockId==42)
{
setTile (x, y, z, 0)
addItemInventory (42, 1)
}
if (itemId==509&&blockId==43)
{
setTile (x, y, z, 0)
addItemInventory (43, 1)
}
if (itemId==509&&blockId==44)
{
setTile (x, y, z, 0)
addItemInventory (44, 1)
}
if (itemId==509&&blockId==45)
{
setTile (x, y, z, 0)
addItemInventory (45, 1)
}
if (itemId==509&&blockId==46)
{
setTile (x, y, z, 0)
addItemInventory (46, 1)
}
if (itemId==509&&blockId==47)
{
setTile (x, y, z, 0)
addItemInventory (47, 1)
}
if (itemId==509&&blockId==48)
{
setTile (x, y, z, 0)
addItemInventory (48, 1)
}
if (itemId==509&&blockId==49)
{
setTile (x, y, z, 0)
addItemInventory (49, 1)
}
if (itemId==509&&blockId==56)
{
setTile (x, y, z, 0)
addItemInventory (264, 1)
}
if (itemId==509&&blockId==57)
{
setTile (x, y, z, 0)
addItemInventory (57, 1)
}
if (itemId==509&&blockId==61)
{
setTile (x, y, z, 0)
addItemInventory (61, 1)
}
if (itemId==509&&blockId==62)
{
setTile (x, y, z, 0)
addItemInventory (62, 1)
}
if (itemId==509&&blockId==67)
{
setTile (x, y, z, 0)
addItemInventory (67, 1)
}
if (itemId==509&&blockId==3)
{
setTile (x, y, z, 0)
addItemInventory (3, 1)
}
if (itemId==509&&blockId==73)
{
setTile (x, y, z, 0)
addItemInventory (331, 5)
}
if (itemId==509&&blockId==74)
{
setTile (x, y, z, 0)
addItemInventory (331, 5)
}
}

function checkArmor() 
{ 
if(Player.getArmorSlot(0) == 302) 
{ 
armor302 = true; 
} 
if(Player.getArmorSlot(1) == 303) 
{ 
armor303 = true; 
} 
if(Player.getArmorSlot(2) == 304) 
{ 
armor304 = true; 
} 
if(Player.getArmorSlot(3) == 305) 
{ 
armor305 = true; 
} 
if(Player.getArmorSlot(0) !== 302) 
{ 
armor302 = false; 
} 
if(Player.getArmorSlot(1) !== 303) 
{ 
armor303 = false; 
} 
if(Player.getArmorSlot(2) !== 304) 
{ 
armor304 = false; 
} 
if(Player.getArmorSlot(3) !== 305)
{ 
armor305 = false; 
} 
}

function modTick()
{
 checkArmor();
  if(armor304 == true)
  {
      if(i==1)
      {
        Xpos=getPlayerX();
        Zpos=getPlayerZ();
        i = i + 1;
      }
      else if(i==3)
      {
        i=1;
        Xdiff=getPlayerX()-Xpos;
        Zdiff=getPlayerZ()-Zpos;
        setVelX(getPlayerEnt(),Xdiff);
        setVelZ(getPlayerEnt(),Zdiff);
        Xdiff=0;
        Zdiff=0;
      }
  if(i!=1)
  {
  i = i + 1;
  }
}
if(armor305 == true)
 {
  if(u==1)
   {
    Ypos=getPlayerY();
     u = u + 1;
   }
   else if(u==3)
    {
     u=1;
     Ydiff=getPlayerY()-Ypos;
     setVelY(getPlayerEnt(),Ydiff);
     Ydiff=0;
    }
   if(u!=1)
    {
    u = u +1;
    }
 }
}