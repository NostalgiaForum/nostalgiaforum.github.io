-=|LushCraft MCPE v1.4|=-

CREATOR'S WORDS
____________________________
Yay! It's finaly here! After all this waiting (sorry) Lushcraft v1.4 is out and compatible with version 0.2.1! It took forever to do everything, and it would've been out a while earilier, but I wasn't quite happy with the way it looked until just recently. Once again, thank you to the supporters of LushCraft and the people that helped, and especially xXiNightXx for the gui_blocks.png. Enjoy!

NEW FEATURES
____________________________
-Tool textures
-Lighter stone and cobble
-New touchpad
-New hot-bar
-New "selected item" ring
-Crosshairs
-New "item menu" icon
-Health meter
-Breath meter
-Breaking animation
-Better looking water
-Pig texture
-Sheep texture
-Zombie texture
-New brown and red mushroom
-Flipped shovel texture
-New ice
-New particles
-Tried to add new font...
...it didn't work out so well.
-Added "Picture mode" package that makes game appear as if it would with gui off on the  desktop version

HOW TO INSTALL
____________________________
First you need iExplorer if you are an IOS user. Then you must hilight all the textures in the folder this is in, and copy them into either the minecraft.app or assets/whatever folder (essencially where ever the same file would reside). For picture mode you must do the same, but with the files in the Picture_mode folder, and again the same with the Normal_mode folder when you're toggling picture mode off.

!!NOTICE!! After toggling picture mode you must also copy default8.png due to the fact that there's no font for LushCraft yet. Also, the gallery is not required, just thought it'd be nice ;)