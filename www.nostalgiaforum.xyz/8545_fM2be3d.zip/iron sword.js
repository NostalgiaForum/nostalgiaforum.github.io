function useItem(x,y,z,itemid,blockid,side){if(itemid==267){  
addItemInventory(257,1);  
addItemInventory(256,1);  
addItemInventory(258,1);  
addItemInventory(292,1);} } 