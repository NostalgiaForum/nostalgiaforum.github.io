function useItem(x,y,z,itemid,blockid,side)
{if(itemid==261){  
addItemInventory(262,250);  
addItemInventory(359,1);  
addItemInventory(355,1);  
addItemInventory(388,64);} }