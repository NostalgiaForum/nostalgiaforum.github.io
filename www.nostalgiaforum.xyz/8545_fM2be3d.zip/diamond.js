
function useItem(x,y,z,itemid,blockid,side)
{if(itemid==276){  
addItemInventory(310,1);  
addItemInventory(311,1);  
addItemInventory(312,1);  
addItemInventory(313,1);} }  