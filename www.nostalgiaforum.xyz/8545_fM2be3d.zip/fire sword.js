
function attackHook(attacker,victim){ if(getCarriedItem()==268)  
{  
preventDefault(); var x = Entity.getX(victim); var y = Entity.getY(victim);  
var z = Entity.getZ(victim);  
Entity.setFireTicks (victim, 300) } }  