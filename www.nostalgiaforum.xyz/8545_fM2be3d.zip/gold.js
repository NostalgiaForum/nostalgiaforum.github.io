
function useItem(x,y,z,itemid,blockid,side)
{if(itemid==283){  
addItemInventory(345,1);  
addItemInventory(347,1);  
addItemInventory(27,64);  
addItemInventory(66,64);  
addItemInventory(328,64);} }  