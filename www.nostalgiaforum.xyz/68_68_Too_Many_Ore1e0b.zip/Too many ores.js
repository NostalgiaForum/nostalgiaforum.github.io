function newLevel() {
clientMessage("welcome to  §6Too Many Ores\nmade by §dMisterPeModder44");
}


var count=0;
var dz,dy,dx,uz,uy,ux;
var totalfire=false,totaltit=false,totalice=false;
var sb=false;
var training;
var iceVic;
var hammerTime=false,HTcount=0,Hent,Hid=0,Hdat=0;
var iceCnt=0;
var pcid;
var iceMode=false;
var defaultDestroyTime = [
null, 1.5, 0.6, 0.5,
 2, 2, 0, -1,
  null, null, null, null,
0.5, 0.6, 3, 3,
 3, 2, 0.2, 0.6,
  0.3, 3, 3, null,
   0.8, null,
0.2, 0.7, null, null,
 4, 0, 0, null, null, 0.8, null,
0, 0, 0, 0, 3, 5, 2, 2, 2, 0, 1.5, 2, 50, 0, 0, null,
2, 2.5, null, 3, 5, 2.5, 0, 0.6, 3.5, 3.5, 1, 3, 0.4,
0.7, 2, 1, null, null, 5, null, 3, 3, null, null, null,
0.1, 0.5, 0.2, 0.4, 0.6, 0, null, 2, 1, 0.4, 0.3, null,
1, 0.5, null, null, -1, 3, null, 1.5, null, null, 5, 0.3,
1, 0, 0, null, 2, 2, 1.5, null, null, 2, null, 2, null, null,
null, null, null, null, null, null, null, null, null, null,
null, 0.8, null, null, null, null, null, 2, 2, 2, null, null,
2, null, 0, 0, null, null, null, null, null, null, null, null,
null, null, null, null, 0.8, 0.8, 2, 2, null, null, null, null,
null, null, null, null, null, null, null, 0.5, 0.1, 5, null, null,
null, null, null, null, null, null, null, null, null, null, null,
null, null, null, null, null, null, null, null, null, null, null,
null, null, null, null, null, null, null, null, null, null, null,
null, null, null, null, null, null, null, null, null, null, null,
null, null, null, null, null, null, null, null, null, null, null, 
null, null, null, null, null, null, null, null, null, null, null, 
null, null, 0, 3.5, 50, 5, 0.6, 0.6, null, null, null, null, null, 0
];


/////Look at VV!!!!!!////
ModPE.setItem(357,"emerald",0,"emerald ;)");
ModPE.setItem(358,"ruby",0,"fire crystal");
ModPE.setItem(322,"blaze_rod",0,"fire rod");
Item.addCraftRecipe(322,1,0,[358,2,0]);
ModPE.setItem(384,"record_strad",0,"fire helmet");
ModPE.setItem(385,"record_stal",0,"fire chestplate");
ModPE.setItem(386,"record_wait",0,"fire leggings");
ModPE.setItem(387,"record_ward",0,"fire boots");
ModPE.setItem(407,"record_13",0,"frozen helmet");
ModPE.setItem(416,"gold_nugget",0,"§4Titanium nugget");
ModPE.setItem(417,"item_frame",0,"§4Titanium bar");
Item.addCraftRecipe(417,1,0,[416,9,0]);
ModPE.setItem(408,"record_11",0,"frozen chestplate");
ModPE.setItem(409,"record_blocks",0,"frozen leggings");
ModPE.setItem(410,"record_cat",0,"frozen boots");
ModPE.setItem(411,"record_far",0,"§4Titanium Helmet");
Item.addCraftRecipe(411,1,0,[417,5,0]);
ModPE.setItem(412,"record_chirp",0,"§4Titanium Chestplate");
Item.addCraftRecipe(412,1,0,[417,8,0]);
ModPE.setItem(413,"record_mall",0,"§4Titanium Leggings");
Item.addCraftRecipe(413,1,0,[417,7,0]);
ModPE.setItem(414,"record_mellohi",0,"§4Titanium Boots");
Item.addCraftRecipe(414,1,0,[417,4,0]);
ModPE.setItem(415,"fireball",0,"ice ball");
ModPE.setItem(418,"skull_skeleton",0,"Fire pickaxe");
Item.addCraftRecipe(418,1,0,[322,2,0,358,3,0]);
ModPE.setItem(419,"skull_steve",0,"frozen pickaxe");
Item.addCraftRecipe(419,1,0,[415,3,0,352,2,0]);
ModPE.setItem(420,"skull_wither",0,"§4Titanium pickaxe");
Item.addCraftRecipe(420,1,0,[417,3,0,265,2,0,278,1,0]);
ModPE.setItem(421,"repeater",0,"Fire axe");
Item.addCraftRecipe(421,1,0,[358,3,0,322,2,0]);
ModPE.setItem(422,"rotten_flesh",0,"Frozen axe");
Item.addCraftRecipe(422,1,0,[415,3,0,352,2,0]);
ModPE.setItem(423,"skull_zombie",0,"§4Titanium axe");
Item.addCraftRecipe(423,1,0,[417,3,0,265,2,0,279,1,0]);
ModPE.setItem(424,"skull_creeper",0,"Fire shovel");
Item.addCraftRecipe(424,1,0,[358,1,0,322,2,0]);
ModPE.setItem(425,"spider_eye",0,"Frozen shovel");
Item.addCraftRecipe(425,1,0,[415,1,0,352,2,0]);
ModPE.setItem(426,"magma_cream",0,"§4Titanium shovel");
Item.addCraftRecipe(426,1,0,[417,1,0,265,2,0,277,1,0]);
ModPE.setItem(427,"lead",0,"Fire sword");
Item.setMaxDamage(427, 900);
Item.addCraftRecipe(427,1,0,[358,2,0,322,1,0]);
ModPE.setItem(428,"nether_star",0,"Frozen sword");
Item.setMaxDamage(428, 900);
Item.addCraftRecipe(428,1,0,[415,2,0,352,1,0]);
ModPE.setItem(429,"nether_wart",0,"§4Titanium sword");
Item.setMaxDamage(429, 1800);
Item.addCraftRecipe(429,1,0,[417,2,0,265,2,0,276,1,0]);
ModPE.setItem(430,"spider_eye_fermented",0,"§4Titanium hammer");//oh my GOD!!!!
Item.setMaxDamage(430, 1800);
Item.addCraftRecipe(430,1,0,[417,5,0,265,2,0,278,1,0,57,1,0]);
ModPE.setItem(431,"map_filled",0,"miners dream");
Item.addCraftRecipe(431,3,0,[417,1,0]);
ModPE.setItem(432,"experience_bottle",0,"x-ray module");
Item.addCraftRecipe(432,1,0,[89,2,0]);

Item.addCraftRecipe(384,1,0,[358,5,0]);
Item.addCraftRecipe(385,1,0,[358,8,0]);
Item.addCraftRecipe(386,1,0,[358,7,0]);
Item.addCraftRecipe(387,1,0,[358,4,0]);
Item.addCraftRecipe(407,1,0,[415,5,0]);
Item.addCraftRecipe(408,1,0,[415,8,0]);
Item.addCraftRecipe(409,1,0,[415,7,0]);
Item.addCraftRecipe(410,1,0,[415,4,0]);


Block.defineBlock(181,"Nether quartz ore",
[["quartz_ore", 1]],1, true,0);
Block.setDestroyTime(181, 0.7);

Block.defineBlock(182,"Emerald ore",
[["emerald_ore", 1]],1, true,0);
Block.setDestroyTime(182, 0.72);

Block.defineBlock(183,"ignis ore",
[["vine", 0]],1, true,0);
Block.setDestroyTime(183,0.7);
Block.setLightLevel(183,15);
Block.defineBlock(184,"Titanium ore",
[["trip_wire_source", 0]],1, true,0);
Block.setDestroyTime(184, 1);
Block.setExplosionResistance(184,1000);
Item.addCraftRecipe(416,1,0,[184,1,0]);
Item.addFurnaceRecipe(184,0,416);//still buggy...

Block.defineBlock(185,"Carbon ore",
[["flower_pot", 0]],1, true,0);
Block.setDestroyTime(185, 0.5);

Block.defineBlock(186,"Frozen ore",
[["endframe_eye", 0]],1, true,0);
Block.setDestroyTime(186, 0.7);

Block.defineBlock(187,"Ice Block",
[["trip_wire", 0]],1, true,0);
Block.setDestroyTime(187, 1);
Item.addCraftRecipe(187,1,0,[415,9,0]);
Item.addCraftRecipe(415,9,0,[187,1,0]);

Block.defineBlock(188,"Molten Block",
[["waterlily", 0]],1, true,0);
Block.setDestroyTime(188, 1);
Block.setLightLevel(188,15);
Item.addCraftRecipe(188,1,0,[358,9,0]);
Item.addCraftRecipe(358,9,0,[188,1,0]);

Block.defineBlock(189,"§4Titanium Block",
[["jukebox_side", 0]],1, true,0);
Block.setDestroyTime(189, 2);
Item.addCraftRecipe(189,1,0,[417,9,0]);
//Item.addCraftRecipe(417,9,0,[189,1,0]);

Block.defineBlock(190,"Emerald Block",
[["emerald_block", 0]],1, true,0);
Block.setDestroyTime(190, 1);
Item.addCraftRecipe(190,1,0,[357,9,0]);
Item.addCraftRecipe(357,9,0,[190,1,0]);

Block.defineBlock(191,"Redstone Block",
[["redstone_block", 0]],1, true,0);
Block.setDestroyTime(191, 1);
Item.addCraftRecipe(191,1,0,[331,9,0]);
Item.addCraftRecipe(331,9,0,[191,1,0]);

Block.defineBlock(192,"X-Ray Glass",
[["mob_spawner", 0]],20, false,0);
Block.setDestroyTime(192,0.2);
Block.setRenderLayer(192,2);
Item.addCraftRecipe(192,32,0,[20,32,0,415,1,0,432,1,0]);


function destroyBlock(x,y,z) {
var Carri=Player.getCarriedItem();
var StoneLvl=false;
var IronLvl=false;
var DiamLvl=false;

if(Carri== 274||Carri == 278||Carri == 257||Carri == 285||Carri == 420) {//stone pick level
StoneLvl=true;
}

if(Carri == 257||Carri == 278	||Carri == 420) {//iron pick level...
IronLvl=true;
}

if(Carri == 278	||Carri == 420) {//diamond pick level...and Titanium of curse!
DiamLvl=true;
}
 
	if(getTile(x,y,z) == 181&&StoneLvl==true) {
	 preventDefault();
	 Level.destroyBlock(x,y,z,false);
		Level.dropItem(x,y,z,0,406,Math.floor((Math.random()*4)+1),0);
	}
	

	if(getTile(x,y,z) == 182&&IronLvl==true) {
	 preventDefault();
	 Level.destroyBlock(x,y,z,false);	
		Level.dropItem(x,y,z,0,357,1,0);
	}
	if(getTile(x,y,z) == 183&&IronLvl==true) {
		 preventDefault();
	 Level.destroyBlock(x,y,z,false);
		Level.dropItem(x,y,z,0,358,1,0);
	}
	if(getTile(x,y,z) == 185&&IronLvl==true) {
	 preventDefault();
	 Level.destroyBlock(x,y,z,false);	
		Level.dropItem(x,y,z,0,173,1,0);
	}
	if(getTile(x,y,z) == 186&&IronLvl==true) {
	 preventDefault();
	 Level.destroyBlock(x,y,z,false);	
		Level.dropItem(x,y,z,0,415,1,0);
	}

	
	
	if(getTile(x,y,z) == 184&&DiamLvl==true) {
	 preventDefault();
	 Level.destroyBlock(x,y,z,false);	
		Level.dropItem(x,y,z,0,184,1,0);
}
}



function useItem(x,y,z,itemId,blockId,side,data) {
if(itemId==430) {
if(hammerTime==false) {
pcid=Player.getCarriedItemData();
Entity.setCarriedItem(getPlayerEnt(),430,1,1700);
toolUse(1800,430) 
hammerTime=true;
Level.playSound(x,y,z,"random.explode",2);
Level.dropItem (x+.5,y+.5,z+.5,0,1,blockId,data)
setTile (x,y,z,0)
Hid=blockId;
Hdat=data;
}
}
if(itemId==432) {
slot(432,1);
Level.setTile(getPlayerX(),getPlayerY(),getPlayerZ(),89,0);
Level.setTile(getPlayerX(),getPlayerY()-1,getPlayerZ(),89,0);
}
if(itemId==431) {
slot(431,1);
Level.playSound(x,y,z,"random.explode",2);
if(side==2) {
for(var t=-1;t<4;t++) {
for(var c=-3;c<4;c++) {
for(var i=0;i<21;i++) {
if(Level.getTile(x+c,y+t,z+i)==1||Level.getTile(x+c,y+t,z+i)==3||Level.getTile(x+c,y+t,z+i)==13) {
Level.setTile(x+c,y+t,z+i,0,0);
}
if(c==0&&i==10) {
Level.setTile(x+c,y-1,z+i,50,0);
}
}
}
}
}
if(side==3) {
for(var t=-1;t<4;t++) {
for(var c=-3;c<4;c++) {
for(var i=0;i<21;i++) {
if(Level.getTile(x+c,y+t,z-i)==1||Level.getTile(x+c,y+t,z-i)==3||Level.getTile(x+c,y+t,z-i)==13) {
Level.setTile(x+c,y+t,z-i,0,0);
}
if(c==0&&i==10) {
Level.setTile(x+c,y-1,z-i,50,0);
}
}
}
}
}
if(side==4) {
for(var t=-1;t<4;t++) {
for(var c=-3;c<4;c++) {
for(var i=0;i<21;i++) {
if(Level.getTile(x+i,y+t,z+c)==1||Level.getTile(x+i,y+t,z+c)==3||Level.getTile(x+i,y+t,z+c)==13) {
Level.setTile(x+i,y+t,z+c,0,0);
}
if(c==0&&i==10) {
Level.setTile(x+i,y-1,z+c,50,0);
}
}
}
}
}
if(side==5) {
for(var t=-1;t<4;t++) {
for(var c=-3;c<4;c++) {
for(var i=0;i<21;i++) {
if(Level.getTile(x-i,y+t,z+c)==1||Level.getTile(x-i,y+t,z+c)==3||Level.getTile(x-i,y+t,z+c)==13) {
Level.setTile(x-i,y+t,z+c,0,0);
}
if(c==0&&i==10) {
Level.setTile(x-i,y-1,z+c,50,0);
}
}
}
}
}
}
if(itemId==384) {
Entity.setMobSkin(getPlayerEnt(),"special armor/fire2.png");
Player.setArmorSlot(0,384,0);
slot(384,1);
}
if(itemId==385) {
Entity.setMobSkin(getPlayerEnt(),"special armor/fire3.png");
Player.setArmorSlot(1,385,0);
slot(385,1);
}
if(itemId==386) {
Entity.setMobSkin(getPlayerEnt(),"special armor/fire4.png");
Player.setArmorSlot(2,386,0);
slot(386,1);
}
if(itemId==387) {
Entity.setMobSkin(getPlayerEnt(),"special armor/fire5.png");
Player.setArmorSlot(3,387,0);
slot(387,1);
}
if(itemId==411) {
Entity.setMobSkin(getPlayerEnt(),"special armor/titan2.png");
Player.setArmorSlot(0,411,0);
slot(411,1);
}
if(itemId==412) {
Entity.setMobSkin(getPlayerEnt(),"special armor/titan3.png");
Player.setArmorSlot(1,412,0);
slot(412,1);
}
if(itemId==413) {
Entity.setMobSkin(getPlayerEnt(),"special armor/titan4.png");
Player.setArmorSlot(2,413,0);
slot(413,1);
}
if(itemId==414) {
Entity.setMobSkin(getPlayerEnt(),"special armor/titan5.png");
Player.setArmorSlot(3,414,0);
slot(414,1);
}
if(itemId==407) {
Entity.setMobSkin(getPlayerEnt(),"special armor/ice2.png");
Player.setArmorSlot(0,407,0);
slot(407,1);
}
if(itemId==408) {
Entity.setMobSkin(getPlayerEnt(),"special armor/ice3.png");
Player.setArmorSlot(1,408,0);
slot(408,1);
}
if(itemId==409) {
Entity.setMobSkin(getPlayerEnt(),"special armor/ice4.png");
Player.setArmorSlot(2,409,0);
slot(409,1);
}
if(itemId==410) {
Entity.setMobSkin(getPlayerEnt(),"special armor/ice5.png");
Player.setArmorSlot(3,410,0);
slot(410,1);
}
checkArmor();
}

function random(min, max){
return Math.floor((Math.random()*max)+min);
}


function entityAddedHook(ent) {
if(Entity.getEntityTypeId (ent) == 64 && hammerTime==true) {
Entity.setRenderType (ent,20)
Entity.setVelX (ent,random(-1,1));
Entity.setVelZ (ent,random(-1,1));
Entity.setPositionRelative(ent,0,2,0);
Entity.setVelY (ent,-random(30,40));
Hent=ent;
}
}



function checkArmor() {
if(Player.getArmorSlot(0)+Player.getArmorSlot(1)+Player.getArmorSlot(2)+Player.getArmorSlot(3)==1542) {
Entity.setMobSkin(getPlayerEnt(),"special armor/fire1.png");
totalfire=true;
}
else if(Player.getArmorSlot(0)+Player.getArmorSlot(1)+Player.getArmorSlot(2)+Player.getArmorSlot(3)==1634) {
Entity.setMobSkin(getPlayerEnt(),"special armor/ice1.png");
totalice=true;
}
else if(Player.getArmorSlot(0)+Player.getArmorSlot(1)+Player.getArmorSlot(2)+Player.getArmorSlot(3)==1650) {
Entity.setMobSkin(getPlayerEnt(),"special armor/titan.png");
totaltit=true;
}
else if(Player.getArmorSlot(0)+Player.getArmorSlot(1)+Player.getArmorSlot(2)+Player.getArmorSlot(3)>=0) {
Entity.setMobSkin(getPlayerEnt(),"mob/char.png");
totalfire=false;
totaltit=false;
totalice=false;
}
}

function slot(item,nb) {
var sl= Player.getSelectedSlotId()
if(sl!== -1) {
var sn= Player.getInventorySlotCount(sl)-nb;
var sd= Player.getInventorySlotData(sl);
if(sn >= nb){
Entity.setCarriedItem(getPlayerEnt(),item,sn,sd);
}else if(sn+nb == nb) {
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
}
}
}

function modTick() {
//ModPE.showTipMessage("TMO v1.1.3 ");//i've desactivated this beacause it's a spam
var pgci=Player.getCarriedItem();
if(hammerTime==true) {
HTcount++

if(HTcount==20) {
//Player.addItemInventory(430,-1,1700);
Entity.setCarriedItem(getPlayerEnt(),430,1,pcid+1);
if(pcid==1800) {
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
}
clientMessage("ready");
hammerTime=false;
Level.setTile(Entity.getX(Hent),Entity.getY(Hent),Entity.getZ(Hent),Hid,Hdat-1);
Entity.setPosition(Hent,256,0,256);
HTcount=0;
}
}
if(pgci>417&&pgci<421) {
//if(pgci == 420 && sb == false) {
fastDestroy(0.001);
sb = true;
}
/*if(pgci == 418&& sb == false) {
fastDestroy(0.2);
sb = true;
	}	
	}*/
		if(pgci !== 420 && sb == true) {
		defaultDestroy();
		sb = false;
	}

count++;
checkArmor();
if(totalice==true) {
if(Level.getTile(Player.getX(),Player.getY()-2,Player.getZ())==8||Level.getTile(Player.getX(),Player.getY()-2,Player.getZ())==9) {
Level.setTile(Player.getX(),Player.getY()-2,Player.getZ(),79);
}
}
if(totalfire==true) {
Entity.setFireTicks(getPlayerEnt(),0);
}
if(count==1) {
ux=Player.getX();
uy=Player.getY();
uz=Player.getZ();
}
if(count==5) {
}
if(count==10) {
count=0;
if(totalfire==true) {
if(Level.getTile(ux,uy-1,uz)==51){
Entity.setHealth(getPlayerEnt(),Entity.getHealth(getPlayerEnt())+1);
}
dx=Player.getX();
dy=Player.getY();
dz=Player.getZ();
if(Math.round(ux)!==Math.round(dx)||Math.round(uz)!==Math.round(dz)) {
if(Level.getTile(ux,uy-2,uz)!==0&&Level.getTile(ux,uy-1,uz)==0) {
Level.setTile(ux,uy-1,uz,51,0);
}
}
}
}
if(iceMode==true) {
iceCnt++;
Entity.setVelX(iceVic,0);
Entity.setVelY(iceVic,0); 	
Entity.setVelZ(iceVic,0);
if(iceCnt==100) {
iceCnt=0;
iceMode=false;
}
}
if(totaltit==true) {
Entity.setHealth(getPlayerEnt(),20);
} 
}

function fastDestroy(fd) {
for(var i = 0; i < 256; i++) {
Block.setDestroyTime(i, fd);
}
Block.setDestroyTime(7,-1);
}

function defaultDestroy() {
for(var i = 0; i < 256; i++){
Block.setDestroyTime(i, defaultDestroyTime[i]);
}
}

function attackHook(attacker,victim) {
if(Player.getCarriedItem()>426&&Player.getCarriedItem()<431) {
if(Player.getCarriedItem()==427) {
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"fire.ignite",2);
Entity.setFireTicks(victim,20);
toolUse(900,427);
}
else if(Player.getCarriedItem()==428) {
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
toolUse(900,428);
iceVic=victim;
iceMode=true;
}
else if(Player.getCarriedItem()==429) {
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"damage.fallbig",2);
toolUse(1800,429);
Entity.setFireTicks(victim,3);
if(Entity.getHealth(victim)>1) {
Entity.setHealth(victim,1);
}
}
else if(Player.getCarriedItem()==430) {
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.explode",2);
toolUse(1800,430);
Entity.setVelY(victim,50); 	
}
}
}


function toolUse(maxDamage,id) {
var pcid=Player.getCarriedItemData();
if(pcid!==maxDamage){
Entity.setCarriedItem(getPlayerEnt(),id,1,pcid+1);
}else if(pcid==maxDamage) {
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
}
}














































