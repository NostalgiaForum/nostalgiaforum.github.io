  /*Generated Structures by Arjay07         \
  |Uses                                     |
  |StructureJS 2.0    TMO World Generator   |
  |By Arjay07                               |         
  |thanks to him!                           |
  \————————————————————————————————————————*/

var IO = java.io;
var File = IO.File;
var FileReader = IO.FileReader;
var BufferedReader = IO.BufferedReader;
var String = java.lang.String;
var StringBuilder = java.lang.StringBuilder;

function readFile(file){

var str;
var br = new BufferedReader(new FileReader(file));
var data = new StringBuilder();

while((str = br.readLine()) != null){

data.append(str);
data.append("\n");

}

return data.toString();

}

function Vertex(x, y, z){

this.x = x;
this.y = y;
this.z = z;

}

function Structure(file){

var structure = readFile(file);
var line = structure.split("\n");
var v = [];
var id = [];
var dmg = [];

for(var i = 0; i < line.length; i++){

var param = line[i].split(":");
var coord = param[0].split("~");
var block = param[1].split(";");
var x = parseInt(coord[0]);
var y = parseInt(coord[1]);
var z = parseInt(coord[2]);
var b = parseInt(block[0]);
var d = parseInt(block[1]);

v.push(new Vertex(x, y, z));
id.push(b);
dmg.push(d==null?0:d);

}

this.positions = v;
this.blockIds = id;
this.damages = dmg;

}

function setStructure(structure, x, y, z)
{

var s = structure.positions;
var id = structure.blockIds;
var d = structure.damages;

for(var i = 0; i < s.length; i++){

var p = s[i];
var bId = id[i];
var bDmg = d[i]; 

setTile(x+p.x, y+p.y, z+p.z, bId, bDmg);

}

}

//////////////////////////////////ok!
/**********COPY TO HERE**********/
//////////////////////////////////:D

function getSurface(x, z){

var i = 0;

for(var y = 1; y <= 128; y++){

if(Level.getTile(x, y, z) == 0){

i = y;
break;

}

}

return i;

}

function random(min, max){

return Math.floor((Math.random()*max)+min);

}

var SDCARD = android.os.Environment.getExternalStorageDirectory();
var titanfile = new File(SDCARD,"tmoTitanium.xtr");
var titan = new Structure(titanfile);
var emeraldfile = new File(SDCARD,"tmoEmerald.xtr");
var emerald = new Structure(emeraldfile);
var ignisfile = new File(SDCARD,"tmoIgnis.xtr");
var ignis = new Structure(ignisfile);
var quartzfile = new File(SDCARD, "tmoQuartz.xtr");
var quartz = new Structure(quartzfile);
var carbonfile = new File(SDCARD, "tmoCarbon.xtr");
var carbon = new Structure(carbonfile);
var frozenfile = new File(SDCARD, "tmoFrozen.xtr");
var frozen = new Structure(frozenfile);

function spawnStructures(){

for(var i = 0; i <=1500 ; i++){

var x = random(0, 256);
var z = random(0, 256);

setStructure(quartz, x, getSurface(x, z) - random(20,50), z);

}
for(var i = 0; i <=350 ; i++){

var x = random(0, 256);
var z = random(0, 256);

setStructure(titan, x, getSurface(x, z) - random(50,70), z);

}
for(var i = 0; i <=214 ; i++){

var x = random(0, 256);
var z = random(0, 256);

setStructure(emerald, x, getSurface(x, z) - random(40,60), z);

}
for(var i = 0; i <=1000 ; i++){

var x = random(0, 256);
var z = random(0, 256);

setStructure(ignis, x, getSurface(x, z) - random(40,60), z);

}
for(var i = 0; i <=400 ; i++){

var x = random(0, 256);
var z = random(0, 256);

setStructure(carbon, x, getSurface(x, z) - random(10,70), z);

}
for(var i = 0; i <=1000 ; i++){

var x = random(0, 256);
var z = random(0, 256);

setStructure(frozen, x, getSurface(x, z) - random(40,60), z);

}

}


function newLevel(){

var spawned = new File(SDCARD + "/games/com.mojang/minecraftWorlds/" + Level.getWorldDir(), "TMOspawned.txt");

if(!spawned.exists()){
print("GENERATING LEVEL...PLEASE WAIT");
spawnStructures();

try{

spawned.createNewFile();

}catch(e){

print("File error"+e);

}

}





}









































































