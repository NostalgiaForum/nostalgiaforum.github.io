//Скрипт создал Марат Ибрагимов для сайта block-zone.ru
//Копирование материала допускается только при наличие источника
//Хуисосы с 0х10с только попробуйте заявить что скрипт ваш,найду,закопаю.


var mPlayer = null;
var nowplaying = null;
var jukebox = [];
var saveTick = -1;

var sdcardPath = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();

var sounds =
["Minecraft.ogg"];
 
var jukebox_sounds =
["Minecraft.ogg"];
 
var jukebox_name = ["Minecraft"];


var GUI;
var GUI2;

function newLevel(){
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
        try{
            var layou1 = new android.widget.LinearLayout(ctx);
            layou1.setOrientation(1);

            var button1 = new android.widget.Button(ctx);
            button1.setText("Включить");
			button1.setTextColor(android.graphics.Color.GREEN);
            button1.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    playSound(jukebox_sounds);
			 }
				
            }));
            layou1.addView(button1);

            GUI = new android.widget.PopupWindow(layou1, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
            GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 10, 330);
        }catch(err){
            print("An error occured: " + err);
        }
    }}));
	 var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
        try{
            var layout2 = new android.widget.LinearLayout(ctx);
            layout2.setOrientation(1);

            var button2 = new android.widget.Button(ctx);
            button2.setText("Остановить");
			button2.setTextColor(android.graphics.Color.GREEN);
            button2.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    mPlayer.pause();
			 }
				
            }));
            layout2.addView(button2);

            GUI2 = new android.widget.PopupWindow(layout2, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            GUI2.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
            GUI2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 10, 440);
        }catch(err){
            print("An error occured: " + err);
        }
    }}));
}

function leaveGame(){
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
if(GUI2 != null)
{
GUI2.dismiss();
GUI2 = null;
} 
if(GUI != null)
{
GUI.dismiss();
GUI = null;
}
    }}));
}

function selectLevelHook(){
	// 파일 체크
	var file = java.io.File(sdcardPath+"/games/com.mojang/minecraftResource/mcpe/");
	if(file.exists() == false){
		clientMessage("[에러] 리소스 폴더가 존재하지 않습니다.");
		clientMessage("[Error] Data does not exist.");
	}
	
	mPlayer = new android.media.MediaPlayer();
}
	
function playSound(sndname){
	var path = sdcardPath+"/games/com.mojang/minecraftResource/mcpe/" + sndname;
	try{
		if(mPlayer.isPlaying()) mPlayer.pause();
		
		mPlayer.reset();
		mPlayer.setDataSource(path);
		mPlayer.prepare();
		mPlayer.start();
	}catch(err){
		print("에러 발생!\n"+err);
		print("error: playsound (163 line)\n"+err);
	}
}
 
function dip2px(ctx, dips){
 return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
}