var timer=0; var look=0; var colider =0;
var showattack=false; var canAttack = 0;
var canAttack1 = 0; var pause = false;
var debug = false; var attack = false;
var x1=0;var y1=0;var z1=0; var spawn=false;
var x3 =0; var y3=0; var y3=0;
var spawnX=0; var spawnY=0; var spawnZ=0;
var xpos = 0; var ypos=0; var zpos=0;
var posx = 0; var posy=0; var posz=0;
var randx = 0; var randy=0; var randz=0;
var countx=0; var county=0; var countz=0;


function random(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

function WaitForSecond (wait){
var second = 0;
if(second!=wait*30){
second++;
}
else if(second==wait*30){
clientMessage(second.toString());
return parseInt(second/30);}
}


function useItem(x,y,z,itemId,blockId,side){
if (blockId=155){
//fireGast();
attack=true;
}
}

function attackHook(attacker,victim)
{

}

function procCmd(cmd){
clientMessage(copy);
switch(cmd){
case  "gast on" :
spawnGast();
break;
case "gast off" :
spawn=false;
break;
case "debug on":
debug = true;
break;
case "debug off":
debug=false;
break;
case "getPos":
if(debug==true){
clientMessage("Position: " + getPlayerX().toString() + " " +getPlayerY().toString() + " " +getPlayerZ().toString());
}
break;
}
}

function spawnGast(){
clientMessage("Spawn Gast");
spawn=true;
for(x1=0;x1<5;x1++){
for(y1=0;y1<5;y1++){
for(z1=0;z1<5;z1++){
spawnX= getPlayerX()-2;
spawnY= getPlayerY()+20;
spawnZ= getPlayerZ()-2;
setTile(getPlayerX()-2+x1,getPlayerY()+20+y1,getPlayerZ()-2+z1, 155);}}}
setTile(getPlayerX()-1,getPlayerY()+23,getPlayerZ()-2, 49);
setTile(getPlayerX()+1,getPlayerY()+23,getPlayerZ()-2, 49);
}

function modTick(){
if (attack==true){
pause=true;
canAttack++;
if(canAttack==30){
rotate();
showattack=true;
//fireGast();
//canAttack=0;
}
if(canAttack==40){
pause=false;
showattack=false;
canAttack=0;
attack=false;
}
}
if(spawn==true){
timer++;if(timer==25){
//moveInArray();
timer=0;
if(pause==false){moveGast();}
//rotationY();
if(debug==true){clientMessage("Collider: " + moveInArray() + " Rotation: "+ look)}}}}

function moveGast(){
//look=rotationY();
xpos = random(-1, 1); randx = random(-1, 1);
ypos = random(-1, 1);randy = random(-1, 1);
randz = random(-1, 1); zpos = random(-1, 1);
 if(moveInArray()==0){
if(randx>posx){spawnX++;countx++;}else{spawnX--;countx--;}
if(randy>posy){spawnY++;county++;}else{spawnY--;county--;}
if(randz>posz){spawnZ++;countz++;}else{spawnZ--;countz--;}
//renderGast();
rotationY();
}
else{ spawnY++;county++;
rotationY();
//renderGast();
colider=0;}
}

function moveInArray(){
if(spawnX!=0&&spawnY!=0&&spawnZ!=0){
for(x2=-1;x2<6;x2++){for(y2=-1;y2<6;y2++){for(z2=-1;z2<6;z2++){
colider += getTile(spawnX+x2, spawnY+y2,spawnZ+z2);}}}
for(x2=0;x2<5;x2++){for(y2=0;y2<5;y2++){for(z2=0;z2<5;z2++){
colider -= getTile(spawnX+x2,spawnY+y2,spawnZ+z2);}}}
return colider;}}

function rotationY(){
if (pause==false){
if(countx>=0&&countz>=0){
if(countx>=countz){look=1;}
else if(countx<countz){look=2;}}
else if(countx<0&&countz<0){
if(countx<countz){look=3;}
else if(countx>=countz){look=4}} 
else if(countx>=0&&countz<0){
if(countx>= Math.abs(countz)){look=1;}
else if(countx< Math.abs(countz)){look=2;}}
else if(countx<0&&countz>=0){
if(Math.abs(countx)>=countz){look=3;}
else if(Math.abs(countx)<countz){look=2;}}
renderGast();}}

function fireGast(){
//clientMessage("Fire attack!");
shoot(Math.abs(getPlayerX()-spawnX), getPlayerY(), Math.abs(getPlayerZ()-spawnZ), 10);
}

function rotate(){
var RotX = 0; var RotZ = 0;
RotX= getPlayerX()-(spawnX+2);
RotZ= getPlayerZ()-(spawnZ+2);
if(Math.abs(RotX)>Math.abs(RotZ)){
   if(RotX>0){ look=1;} else if(RotX<0){look=3;}}
else if(Math.abs(RotX)<Math.abs(RotZ)) {
   if(RotZ>0){ look=2;} else if(RotZ<0){look=4;}}
LookAt();
}

function LookAt(){

for(x1=0;x1<5;x1++){for(y1=0;y1<5;y1++){for(z1=0;z1<5;z1++){
setTile(spawnX+x1,spawnY+y1,spawnZ+z1, 0);}}}
for(x1=0;x1<5;x1++){for(y1=0;y1<5;y1++){for(z1=0;z1<5;z1++){
setTile(spawnX+x1,spawnY+y1,spawnZ+z1, 7);
countx=0;county=0;countz=0;}}}

switch (look){
case 1:
setTile(spawnX+4,spawnY+1, spawnZ+2,87);
setTile(spawnX+4,spawnY+3,spawnZ+1, 49);
setTile(spawnX+4,spawnY+3,spawnZ+3, 49); 
break;
case 2:
setTile(spawnX+2,spawnY+1, spawnZ+4,87);
setTile(spawnX+1,spawnY+3,spawnZ+4, 49);
setTile(spawnX+3,spawnY+3,spawnZ+4, 49); 
break;
case 3:
setTile(spawnX,spawnY+1, spawnZ+2,87);
setTile(spawnX,spawnY+3,spawnZ+1, 49);
setTile(spawnX,spawnY+3,spawnZ+3, 49); 
break;
case 4:
setTile(spawnX+2,spawnY+1, spawnZ,87);
setTile(spawnX+1,spawnY+3,spawnZ, 49);
setTile(spawnX+3,spawnY+3,spawnZ, 49); 
break;
}
fireGast();
}


function shoot(getx, gety, getz, blockid){
clientMessage("Fire!");
switch(look){

case 1: for (x3=0; x3<getx;x3++){
setTile(spawnX+5+x3, spawnY+1, spawnZ+2, blockid);
explode(spawnX+5+getx,spawnY+1,spawnZ+2,10);
if(x3!=0){
setTile(spawnX+4+x3, spawnY+1, spawnZ+2, 51);
}}break;

case 2: for (z3=0; z3<getz;z3++){
setTile(spawnX+2, spawnY+1, spawnZ+5+z3, blockid);
explode(spawnX+2,spawnY+1,spawnZ+2+getz,10);
if(z3!=0){
setTile(spawnX+2, spawnY+1, spawnZ+4+z3, 51);
}}break;

case 3: for (x3=0; x3<getx;x3++){
setTile(spawnX-1-x3, spawnY+1, spawnZ+2, blockid);
explode(spawnX-1-getx,spawnY+1,spawnZ+2,10);
if(x3!=0){
setTile(spawnX-x3, spawnY+1, spawnZ+2, 51);
}}break;

case 4: for (z3=0; z3<getz;z3++){
setTile(spawnX+2, spawnY+1, spawnZ-1-z3, blockid);
explode(spawnX+2,spawnY+1,spawnZ-1-getz,10);
if(z3!=0){
setTile(spawnX+2, spawnY+1, spawnZ-z3, 51);
}}break;
}}

function renderGast(){
for(x1=0;x1<5;x1++){for(y1=0;y1<5;y1++){for(z1=0;z1<5;z1++){
setTile(spawnX+x1-countx,spawnY+y1-county,spawnZ+z1-countz, 0);}}}
for(x1=0;x1<5;x1++){for(y1=0;y1<5;y1++){for(z1=0;z1<5;z1++){
setTile(spawnX+x1,spawnY+y1,spawnZ+z1, 155);
countx=0;county=0;countz=0;}}}
switch (look){
case 1:
if(showattack==true){setTile(spawnX+4,spawnY+1, spawnZ+2,87);}
setTile(spawnX+4,spawnY+3,spawnZ+1, 49);
setTile(spawnX+4,spawnY+3,spawnZ+3, 49); 
break;
case 2:
if(showattack==true){setTile(spawnX+2,spawnY+1, spawnZ+4,87);}
setTile(spawnX+1,spawnY+3,spawnZ+4, 49);
setTile(spawnX+3,spawnY+3,spawnZ+4, 49); 
break;
case 3:
if(showattack==true){setTile(spawnX,spawnY+1, spawnZ+2,87);}
setTile(spawnX,spawnY+3,spawnZ+1, 49);
setTile(spawnX,spawnY+3,spawnZ+3, 49); 
break;
case 4:
if(showattack==true){setTile(spawnX+2,spawnY+1, spawnZ,87);}
setTile(spawnX+1,spawnY+3,spawnZ, 49);
setTile(spawnX+3,spawnY+3,spawnZ, 49); 
break;
}
}

























































var copy = "Теперь ставим репу";