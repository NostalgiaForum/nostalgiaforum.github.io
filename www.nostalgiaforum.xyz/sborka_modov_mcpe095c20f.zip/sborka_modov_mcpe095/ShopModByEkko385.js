
/* Shop Mod by Ekko385
    Специально для 0x10c-zone.ru */



var tile;
var money=100;
function leaveGame()
{
ModPE.saveData("money");
}

function newLevel()
{
ModPE.readData("money");
clientMessage(ChatColor.GRAY+ "Shop mod by Ekko385");
clientMessage(ChatColor.BLUE+ " Commands: [/prices], [/wallet]");
clientMessage(ChatColor.RED+ "<game> " +ChatColor.BLUE+ "Welcome!");
}

function useItem(x, y, z, itemId, blockId, side)
{
if(itemId==339)
{
clientMessage(ChatColor.RED+ "<game> " +ChatColor.BLUE+ "You have set the shop. Use the ink to buy");
setTile(x+1, y+1, z, 4);
setTile(x+2, y+1, z, 4);
setTile(x+3, y+1, z, 4);
setTile(x+4, y+1, z, 4);
setTile(x+5, y+1, z, 4);
setTile(x+6, y+1, z, 4);
setTile(x-1, y+1, z, 4);
setTile(x-2, y+1, z, 4);
setTile(x-3, y+1, z, 4);
setTile(x-4, y+1, z, 4);
setTile(x-5, y+1, z, 4);
setTile(x-6, y+1, z, 4);
setTile(x-6, y+1, z-1, 4);
setTile(x-6, y+1, z-2, 4);
setTile(x-6, y+1, z-3, 4);
setTile(x-6, y+1, z-4, 4);
setTile(x-6, y+1, z-5, 4);
setTile(x-6, y+1, z-6, 4);
setTile(x-6, y+1, z-7, 4);
setTile(x-6, y+1, z-8, 4);
setTile(x-6, y+1, z-9, 4);
setTile(x-6, y+1, z-10, 4);
setTile(x-6, y+1, z-11, 4);
setTile(x-6, y+1, z-12, 4);
setTile(x+6, y+1, z-1, 4);
setTile(x+6, y+1, z-2, 4);
setTile(x+6, y+1, z-3, 4);
setTile(x+6, y+1, z-4, 4);
setTile(x+6, y+1, z-5, 4);
setTile(x+6, y+1, z-6, 4);
setTile(x+6, y+1, z-7, 4);
setTile(x+6, y+1, z-8, 4);
setTile(x+6, y+1, z-9, 4);
setTile(x+6, y+1, z-10, 4);
setTile(x+6, y+1, z-11, 4);
setTile(x+6, y+1, z-12, 4);
setTile(x+5, y+1, z-12, 4);
setTile(x+4, y+1, z-12, 4);
setTile(x+3, y+1, z-12, 4);
setTile(x+2, y+1, z-12, 4);
setTile(x+1, y+1, z-12, 4);
setTile(x, y+1, z-12, 4);
setTile(x-1, y+1, z-12, 4);
setTile(x-2, y+1, z-12, 4);
setTile(x-3, y+1, z-12, 4);
setTile(x-4, y+1, z-12, 4);
setTile(x-5, y+1, z-12, 4);
setTile(x+1, y+2, z, 5);
setTile(x+2, y+2, z, 5);
setTile(x+3, y+2, z, 5);
setTile(x+4, y+2, z, 5);
setTile(x+5, y+2, z, 5);
setTile(x+6, y+2, z, 5);
setTile(x-1, y+2, z, 5);
setTile(x-2, y+2, z, 5);
setTile(x-3, y+2, z, 5);
setTile(x-4, y+2, z, 5);
setTile(x-5, y+2, z, 5);
setTile(x-6, y+2, z, 5);
setTile(x-6, y+2, z-1, 5);
setTile(x-6, y+2, z-2, 5);
setTile(x-6, y+2, z-3, 5);
setTile(x-6, y+2, z-4, 5);
setTile(x-6, y+2, z-5, 5);
setTile(x-6, y+2, z-6, 5);
setTile(x-6, y+2, z-7, 5);
setTile(x-6, y+2, z-8, 5);
setTile(x-6, y+2, z-9, 5);
setTile(x-6, y+2, z-10, 5);
setTile(x-6, y+2, z-11, 5);
setTile(x-6, y+2, z-12, 5);
setTile(x+6, y+2, z-1, 5);
setTile(x+6, y+2, z-2, 5);
setTile(x+6, y+2, z-3, 5);
setTile(x+6, y+2, z-4, 5);
setTile(x+6, y+2, z-5, 5);
setTile(x+6, y+2, z-6, 5);
setTile(x+6, y+2, z-7, 5);
setTile(x+6, y+2, z-8, 5);
setTile(x+6, y+2, z-9, 5);
setTile(x+6, y+2, z-10, 5);
setTile(x+6, y+2, z-11, 5);
setTile(x+6, y+2, z-12, 5);
setTile(x+5, y+2, z-12, 5);
setTile(x+4, y+2, z-12, 5);
setTile(x+3, y+2, z-12, 5);
setTile(x+2, y+2, z-12, 5);
setTile(x+1, y+2, z-12, 5);
setTile(x, y+2, z-12, 5);
setTile(x-1, y+2, z-12, 5);
setTile(x-2, y+2, z-12, 5);
setTile(x-3, y+2, z-12, 5);
setTile(x-4, y+2, z-12, 5);
setTile(x-5, y+2, z-12, 5);
setTile(x+1, y+3, z, 5);
setTile(x+2, y+3, z, 5);
setTile(x+3, y+3, z, 5);
setTile(x+4, y+3, z, 5);
setTile(x+5, y+3, z, 5);
setTile(x+6, y+3, z, 89);
setTile(x-1, y+3, z, 5);
setTile(x-2, y+3, z, 5);
setTile(x-3, y+3, z, 5);
setTile(x-4, y+3, z, 5);
setTile(x-5, y+3, z, 5);
setTile(x-6, y+3, z, 89);
setTile(x-6, y+3, z-1, 5);
setTile(x-6, y+3, z-2, 5);
setTile(x-6, y+3, z-3, 5);
setTile(x-6, y+3, z-4, 5);
setTile(x-6, y+3, z-5, 5);
setTile(x-6, y+3, z-6, 5);
setTile(x-6, y+3, z-7, 5);
setTile(x-6, y+3, z-8, 5);
setTile(x-6, y+3, z-9, 5);
setTile(x-6, y+3, z-10, 5);
setTile(x-6, y+3, z-11, 5);
setTile(x-6, y+3, z-12, 89);
setTile(x+6, y+3, z-1, 5);
setTile(x+6, y+3, z-2, 5);
setTile(x+6, y+3, z-3, 5);
setTile(x+6, y+3, z-4, 5);
setTile(x+6, y+3, z-5, 5);
setTile(x+6, y+3, z-6, 5);
setTile(x+6, y+3, z-7, 5);
setTile(x+6, y+3, z-8, 5);
setTile(x+6, y+3, z-9, 5);
setTile(x+6, y+3, z-10, 5);
setTile(x+6, y+3, z-11, 5);
setTile(x+6, y+3, z-12, 89);
setTile(x+5, y+3, z-12, 5);
setTile(x+4, y+3, z-12, 5);
setTile(x+3, y+3, z-12, 5);
setTile(x+2, y+3, z-12, 5);
setTile(x+1, y+3, z-12, 5);
setTile(x, y+3, z-12, 5);
setTile(x-1, y+3, z-12, 5);
setTile(x-2, y+3, z-12, 5);
setTile(x-3, y+3, z-12, 5);
setTile(x-4, y+3, z-12, 5);
setTile(x-5, y+3, z-12, 5);
setTile(x, y, z, 4);
setTile(x, y, z-1, 4);
setTile(x, y, z-2, 4);
setTile(x, y, z-3, 4);
setTile(x, y, z-4, 4);
setTile(x, y, z-5, 4);
setTile(x, y, z-6, 89);
setTile(x, y, z-7, 4);
setTile(x, y, z-8, 4);
setTile(x, y, z-9, 4);
setTile(x, y, z-10, 4);
setTile(x, y, z-11, 4);
setTile(x+1, y, z-1, 4);
setTile(x+1, y, z-2, 4);
setTile(x+1, y, z-3, 4);
setTile(x+1, y, z-4, 4);
setTile(x+1, y, z-5, 4);
setTile(x+1, y, z-6, 4);
setTile(x+1, y, z-7, 4);
setTile(x+1, y, z-8, 4);
setTile(x+1, y, z-9, 4);
setTile(x+1, y, z-10, 4);
setTile(x+1, y, z-11, 4);
setTile(x+2, y, z-1, 4);
setTile(x+2, y, z-2, 4);
setTile(x+2, y, z-3, 4);
setTile(x+2, y, z-4, 4);
setTile(x+2, y, z-5, 4);
setTile(x+2, y, z-6, 4);
setTile(x+2, y, z-7, 4);
setTile(x+2, y, z-8, 4);
setTile(x+2, y, z-9, 4);
setTile(x+2, y, z-10, 4);
setTile(x+2, y, z-11, 4);
setTile(x+3, y, z-1, 4);
setTile(x+3, y, z-2, 4);
setTile(x+3, y, z-3, 4);
setTile(x+3, y, z-4, 4);
setTile(x+3, y, z-5, 4);
setTile(x+3, y, z-6, 4);
setTile(x+3, y, z-7, 4);
setTile(x+3, y, z-8, 4);
setTile(x+3, y, z-9, 4);
setTile(x+3, y, z-10, 4);
setTile(x+3, y, z-11, 4);
setTile(x+4, y, z-1, 4);
setTile(x+4, y, z-2, 4);
setTile(x+4, y, z-3, 4);
setTile(x+4, y, z-4, 4);
setTile(x+4, y, z-5, 4);
setTile(x+4, y, z-6, 4);
setTile(x+4, y, z-7, 4);
setTile(x+4, y, z-8, 4);
setTile(x+4, y, z-9, 4);
setTile(x+4, y, z-10, 4);
setTile(x+4, y, z-11, 4);
setTile(x+5, y, z-1, 4);
setTile(x+5, y, z-2, 4);
setTile(x+5, y, z-3, 4);
setTile(x+5, y, z-4, 4);
setTile(x+5, y, z-5, 4);
setTile(x+5, y, z-6, 4);
setTile(x+5, y, z-7, 4);
setTile(x+5, y, z-8, 4);
setTile(x+5, y, z-9, 4);
setTile(x+5, y, z-10, 4);
setTile(x+5, y, z-11, 4);
setTile(x-1, y, z-1, 4);
setTile(x-1, y, z-2, 4);
setTile(x-1, y, z-3, 4);
setTile(x-1, y, z-4, 4);
setTile(x-1, y, z-5, 4);
setTile(x-1, y, z-6, 4);
setTile(x-1, y, z-7, 4);
setTile(x-1, y, z-8, 4);
setTile(x-1, y, z-9, 4);
setTile(x-1, y, z-10, 4);
setTile(x-1, y, z-11, 4);
setTile(x-2, y, z-1, 4);
setTile(x-2, y, z-2, 4);
setTile(x-2, y, z-3, 4);
setTile(x-2, y, z-4, 4);
setTile(x-2, y, z-5, 4);
setTile(x-2, y, z-6, 4);
setTile(x-2, y, z-7, 4);
setTile(x-2, y, z-8, 4);
setTile(x-2, y, z-9, 4);
setTile(x-2, y, z-10, 4);
setTile(x-2, y, z-11, 4);
setTile(x-3, y, z-1, 4);
setTile(x-3, y, z-2, 4);
setTile(x-3, y, z-3, 4);
setTile(x-3, y, z-4, 4);
setTile(x-3, y, z-5, 4);
setTile(x-3, y, z-6, 4);
setTile(x-3, y, z-7, 4);
setTile(x-3, y, z-8, 4);
setTile(x-3, y, z-9, 4);
setTile(x-3, y, z-10, 4);
setTile(x-3, y, z-11, 4);
setTile(x-4, y, z-1, 4);
setTile(x-4, y, z-2, 4);
setTile(x-4, y, z-3, 4);
setTile(x-4, y, z-4, 4);
setTile(x-4, y, z-5, 4);
setTile(x-4, y, z-6, 4);
setTile(x-4, y, z-7, 4);
setTile(x-4, y, z-8, 4);
setTile(x-4, y, z-9, 4);
setTile(x-4, y, z-10, 4);
setTile(x-4, y, z-11, 4);
setTile(x-5, y, z-1, 4);
setTile(x-5, y, z-2, 4);
setTile(x-5, y, z-3, 4);
setTile(x-5, y, z-4, 4);
setTile(x-5, y, z-5, 4);
setTile(x-5, y, z-6, 4);
setTile(x-5, y, z-7, 4);
setTile(x-5, y, z-8, 4);
setTile(x-5, y, z-9, 4);
setTile(x-5, y, z-10, 4);
setTile(x-5, y, z-11, 4);
setTile(x, y+4, z-1, 4);
setTile(x, y+4, z-2, 4);
setTile(x, y+4, z-3, 4);
setTile(x, y+4, z-4, 4);
setTile(x, y+4, z-5, 4);
setTile(x, y+4, z-6, 89);
setTile(x, y+4, z-7, 4);
setTile(x, y+4, z-8, 4);
setTile(x, y+4, z-9, 4);
setTile(x, y+4, z-10, 4);
setTile(x, y+4, z-11, 4);
setTile(x+1, y+4, z-1, 4);
setTile(x+1, y+4, z-2, 4);
setTile(x+1, y+4, z-3, 4);
setTile(x+1, y+4, z-4, 4);
setTile(x+1, y+4, z-5, 4);
setTile(x+1, y+4, z-6, 4);
setTile(x+1, y+4, z-7, 4);
setTile(x+1, y+4, z-8, 4);
setTile(x+1, y+4, z-9, 4);
setTile(x+1, y+4, z-10, 4);
setTile(x+1, y+4, z-11, 4);
setTile(x+2, y+4, z-1, 4);
setTile(x+2, y+4, z-2, 4);
setTile(x+2, y+4, z-3, 4);
setTile(x+2, y+4, z-4, 4);
setTile(x+2, y+4, z-5, 4);
setTile(x+2, y+4, z-6, 4);
setTile(x+2, y+4, z-7, 4);
setTile(x+2, y+4, z-8, 4);
setTile(x+2, y+4, z-9, 4);
setTile(x+2, y+4, z-10, 4);
setTile(x+2, y+4, z-11, 4);
setTile(x+3, y+4, z-1, 4);
setTile(x+3, y+4, z-2, 4);
setTile(x+3, y+4, z-3, 4);
setTile(x+3, y+4, z-4, 4);
setTile(x+3, y+4, z-5, 4);
setTile(x+3, y+4, z-6, 4);
setTile(x+3, y+4, z-7, 4);
setTile(x+3, y+4, z-8, 4);
setTile(x+3, y+4, z-9, 4);
setTile(x+3, y+4, z-10, 4);
setTile(x+3, y+4, z-11, 4);
setTile(x+4, y+4, z-1, 4);
setTile(x+4, y+4, z-2, 4);
setTile(x+4, y+4, z-3, 4);
setTile(x+4, y+4, z-4, 4);
setTile(x+4, y+4, z-5, 4);
setTile(x+4, y+4, z-6, 4);
setTile(x+4, y+4, z-7, 4);
setTile(x+4, y+4, z-8, 4);
setTile(x+4, y+4, z-9, 4);
setTile(x+4, y+4, z-10, 4);
setTile(x+4, y+4, z-11, 4);
setTile(x+5, y+4, z-1, 89);
setTile(x+5, y+4, z-2, 4);
setTile(x+5, y+4, z-3, 4);
setTile(x+5, y+4, z-4, 4);
setTile(x+5, y+4, z-5, 4);
setTile(x+5, y+4, z-6, 4);
setTile(x+5, y+4, z-7, 4);
setTile(x+5, y+4, z-8, 4);
setTile(x+5, y+4, z-9, 4);
setTile(x+5, y+4, z-10, 4);
setTile(x+5, y+4, z-11, 89);
setTile(x-1, y+4, z-1, 4);
setTile(x-1, y+4, z-2, 4);
setTile(x-1, y+4, z-3, 4);
setTile(x-1, y+4, z-4, 4);
setTile(x-1, y+4, z-5, 4);
setTile(x-1, y+4, z-6, 4);
setTile(x-1, y+4, z-7, 4);
setTile(x-1, y+4, z-8, 4);
setTile(x-1, y+4, z-9, 4);
setTile(x-1, y+4, z-10, 4);
setTile(x-1, y+4, z-11, 4);
setTile(x-2, y+4, z-1, 4);
setTile(x-2, y+4, z-2, 4);
setTile(x-2, y+4, z-3, 4);
setTile(x-2, y+4, z-4, 4);
setTile(x-2, y+4, z-5, 4);
setTile(x-2, y+4, z-6, 4);
setTile(x-2, y+4, z-7, 4);
setTile(x-2, y+4, z-8, 4);
setTile(x-2, y+4, z-9, 4);
setTile(x-2, y+4, z-10, 4);
setTile(x-2, y+4, z-11, 4);
setTile(x-3, y+4, z-1, 4);
setTile(x-3, y+4, z-2, 4);
setTile(x-3, y+4, z-3, 4);
setTile(x-3, y+4, z-4, 4);
setTile(x-3, y+4, z-5, 4);
setTile(x-3, y+4, z-6, 4);
setTile(x-3, y+4, z-7, 4);
setTile(x-3, y+4, z-8, 4);
setTile(x-3, y+4, z-9, 4);
setTile(x-3, y+4, z-10, 4);
setTile(x-3, y+4, z-11, 4);
setTile(x-4, y+4, z-1, 4);
setTile(x-4, y+4, z-2, 4);
setTile(x-4, y+4, z-3, 4);
setTile(x-4, y+4, z-4, 4);
setTile(x-4, y+4, z-5, 4);
setTile(x-4, y+4, z-6, 4);
setTile(x-4, y+4, z-7, 4);
setTile(x-4, y+4, z-8, 4);
setTile(x-4, y+4, z-9, 4);
setTile(x-4, y+4, z-10, 4);
setTile(x-4, y+4, z-11, 4);
setTile(x-5, y+4, z-1, 89);
setTile(x-5, y+4, z-2, 4);
setTile(x-5, y+4, z-3, 4);
setTile(x-5, y+4, z-4, 4);
setTile(x-5, y+4, z-5, 4);
setTile(x-5, y+4, z-6, 4);
setTile(x-5, y+4, z-7, 4);
setTile(x-5, y+4, z-8, 4);
setTile(x-5, y+4, z-9, 4);
setTile(x-5, y+4, z-10, 4);
setTile(x-5, y+4, z-11, 89);
setTile(x, y+3, z, 5);
setTile(x+5, y+1, z-1, 57);
setTile(x+5, y+1, z-3, 41);
setTile(x+5, y+1, z-5, 42);
setTile(x+5, y+1, z-7, 133);
setTile(x+5, y+1, z-9, 173);
setTile(x+5, y+1, z-11, 49);
setTile(x+3, y+1, z-11, 17);
setTile(x+1, y+1, z-11, 73);
setTile(x-1, y+1, z-11, 87);
setTile(x-3, y+1, z-11, 20);
setTile(x-5, y+1, z-11, 1);
setTile(x-5, y+1, z-9, 13);
setTile(x-5, y+1, z-7, 24);
setTile(x-5, y+1, z-5, 30);
setTile(x-5, y+1, z-3, 35);
setTile(x-5, y+1, z-1, 45);
addItemInventory(351, 1);
}
if(itemId==271&&blockId==1)
{
addItemInventory(339, 1);
clientMessage(ChatColor.RED+ "<game> " +ChatColor.BLUE+ "Shop project has been added in your inventory");
}
if(itemId==351&&blockId==133&&money>74)
{
addItemInventory(388, 1);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought emerald (Id 388)");
money-=75;
}
if(itemId==351&&blockId==57&&money>99)
{
addItemInventory(264, 1);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought diamond (Id 264)");
money-=100;
}
if(itemId==351&&blockId==41&&money>74)
{
addItemInventory(266, 1);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought gold (id 266)");
money-=75;
}
if(itemId==351&&blockId==42&&money>74)
{
addItemInventory(265, 1);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought iron (Id 265)");
money-=75;
}
if(itemId==351&&blockId==173&&money>24)
{
addItemInventory(263, 1);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought coal (Id 263)");
money-=25;
}
if(itemId==351&&blockId==49&&money>99)
{
addItemInventory(49, 1);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought obsidian (Id 49)");
money-=100;
}
if(itemId==351&&blockId==17&&money>24)
{
addItemInventory(17, 32);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought wood (Id 17) - 32");
money-=25;
}
if(itemId==351&&blockId==73&&money>34)
{
addItemInventory(331, 1);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought redstone (Id 331)");
money-=35;
}
if(itemId==351&&blockId==87&&money>54)
{
addItemInventory(87, 32);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought netherrack (Id 87) - 32");
money-=55;
}
if(itemId==351&&blockId==20&&money>24)
{
addItemInventory(20, 16);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought glass (Id 20) - 16");
money-=25;
}
if(itemId==351&&blockId==1&&money>19)
{
addItemInventory(1, 32);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought stone (Id 1) - 32");
money-=20;
}
if(itemId==351&&blockId==13&&money>24)
{
addItemInventory(318, 16);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought flint (Id 318) - 16");
money-=25;
}
if(itemId==351&&blockId==24&&money>24)
{
addItemInventory(24, 32);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought sandstone (Id 24) - 32");
money-=25;
}
if(itemId==351&&blockId==30&&money>49)
{
addItemInventory(30, 16);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought cobweb (Id 30) - 16");
money-=50;
}
if(itemId==351&&blockId==35&&money>64)
{
addItemInventory(35, 16);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought wool (Id 35) - 16");
money-=65;
}
if(itemId==351&&blockId==45&&money>29)
{
addItemInventory(336, 32);
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GREEN+ "You have bought brick (Id 336) - 32");
money-=30;
}
if(itemId==351&&blockId==133&&money<74)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==57&&money<99)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==41&&money<74)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==42&&money<74)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==173&&money<24)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==49&&money<99)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==17&&money<24)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==73&&money<34)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==87&&money<54)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==20&&money<24)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==1&&money<19)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==13&&money<24)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==24&&money<24)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==30&&money<49)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==35&&money<64)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==351&&blockId==45&&money<29)
{
clientMessage(ChatColor.RED+ "<shop> You haven't got enough money");
}
if(itemId==14)
{
preventDefault();
clientMessage(ChatColor.RED+ "<game> Don't cheat!");
}
if(itemId==15)
{
preventDefault();
clientMessage(ChatColor.RED+ "<game> Don't cheat!");
}
}

function procCmd(cmd)
{
if(cmd=="wallet")
{
clientMessage(ChatColor.RED+ "<game> " +ChatColor.BLUE+ "You have " +money+ " money in your wallet");
}
if(cmd=="prices")
{
clientMessage(ChatColor.RED+ "<shop> " +ChatColor.GOLD+ "Prices of items");
clientMessage(ChatColor.BLUE+ "Diamond-100");
clientMessage(ChatColor.BLUE+ "Emerald-75");
clientMessage(ChatColor.BLUE+ "Gold-75");
clientMessage(ChatColor.BLUE+ "Iron-75");
clientMessage(ChatColor.BLUE+ "Coal-25");
clientMessage(ChatColor.BLUE+ "Obsidian-100");
clientMessage(ChatColor.BLUE+ "Wood-25");
clientMessage(ChatColor.BLUE+ "Redstone-35");
clientMessage(ChatColor.BLUE+ "Netherrack-55");
clientMessage(ChatColor.BLUE+ "Glass-25");
clientMessage(ChatColor.BLUE+ "Stone-20");
clientMessage(ChatColor.BLUE+ "Flint-25");
clientMessage(ChatColor.BLUE+ "Sandstone-25");
clientMessage(ChatColor.BLUE+ "Cobweb-50");
clientMessage(ChatColor.BLUE+ "Wool-65");
clientMessage(ChatColor.BLUE+ "Brick-30");
}
}

function deathHook(murderer, victim)
{
if(murderer==getPlayerEnt())
{
money+=20;
clientMessage(ChatColor.RED+ "<game> " +ChatColor.BLUE+ "+20 money");
}
}

function destroyBlock(x, y, z, side)
{
if(getTile()==14)
{
money+=20;
clientMessage(ChatColor.RED+ "<game> " +ChatColor.BLUE+ "+20 money");
}
if(getTile()==15)
{
money+=25;
clientMessage(ChatColor.RED+ "<game> " +ChatColor.BLUE+ "+25 money");
}
if(getTile()==56)
{
money+=50;
clientMessage(ChatColor.RED+ "<game> " +ChatColor.GOLD+ "+50 money");
}
if(getTile()==21)
{
money+=25;
clientMessage(ChatColor.RED+ "<game> " +ChatColor.BLUE+ "+25 money");
}
if(getTile()==73)
{
money+=30;
clientMessage(ChatColor.RED+ "<game> " +ChatColor.GREEN+ "+30 money");
}
if(getTile()==129)
{
money+=45;
clientMessage(ChatColor.RED+ "<game> " +ChatColor.GOLD+ "+45 money");
}
}