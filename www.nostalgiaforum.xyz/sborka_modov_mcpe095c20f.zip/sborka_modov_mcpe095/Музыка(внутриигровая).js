function leaveGame()
{if(mp!=null)
mp.reset();zs=dq=0;lj=new Array();}
function newLevel()
{print("TBPM MOD Background Music mod");var ctx=com.mojang.minecraftpe.MainActivity.currentMainActivity.get();ctx.runOnUiThread(new java.lang.Runnable({run:function(){try{var sv=new android.widget.ScrollView(ctx);var layout=new android.widget.LinearLayout(ctx);layout.setOrientation(1);for(var js=0;ModPE.readData("beijingyinyue"+js)!=""&&ModPE.readData("beijingyinyue"+js)!=null;js++)
{lj[js]=ModPE.readData("beijingyinyue"+js);zs++;}
var t=new android.widget.TextView(ctx);t.setText("Now you have"+zs+"amount of music，it will save by auto next time no need to fill in again");var e1=new android.widget.EditText(ctx);e1.setHint("Please fill in path，like:/sdcard/1.mp3");var b1=new android.widget.Button(ctx);b1.setText("Add");b1.setOnClickListener(new android.view.View.OnClickListener({onClick:function(v){if(e1.getText().toString()!="")
{try
{mp.setDataSource(e1.getText().toString());mp.prepare();lj[zs]=e1.getText().toString();ModPE.saveData("beijingyinyue"+zs,lj[zs]);e1.setText("");zs++;t.setText("Now you have"+zs+"amount of music，it will save by auto next time no need to fill in again");}catch(e)
{print("Err:"+e);}
finally{mp.reset();}}
else print("You haven't fill in path！");}}));var b2=new android.widget.Button(ctx);b2.setText("Reset");b2.setOnClickListener(new android.view.View.OnClickListener({onClick:function(v){for(var js=0;ModPE.readData("beijingyinyue"+js)!=""&&ModPE.readData("beijingyinyue"+js)!=null;js++)
{ModPE.removeData("beijingyinyue"+js);}
lj=new Array();dq=zs=0;t.setText("Now you have"+zs+"amount of music，it will save by auto next time no need to fill in again");}}));var svp=new android.view.ViewGroup.LayoutParams(-2,-2);layout.addView(t,svp);layout.addView(e1,svp);layout.addView(b1,svp);layout.addView(b2,svp);sv.addView(layout);var dialog=new android.app.AlertDialog.Builder(ctx).setView(sv).setTitle("Background music").setNegativeButton("Play",new android.content.DialogInterface.OnClickListener()
{onClick:function(dialog,which)
{if(zs>0)
{mp.setDataSource(lj[dq]);mp.prepare();mp.start();var temp=dq+1;print("Background music system :Start playing"+temp+"song,Path:"+lj[dq]);mp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener()
{onCompletion:function(mper)
{print("Background music system:All song played");if(dq<zs-1)
dq++;else
dq=0;mp.reset();mp.setDataSource(lj[dq]);mp.prepare();mp.start();print("Background music system :start playing"+(dq+1)+"song,path"+lj[dq]);}});}
else{print("You haven't add any song！");print("If u want to add more song exit and add");}}}).setPositiveButton("Cancel",null).create();dialog.setCanceledOnTouchOutside(false);dialog.show();}catch(err){print("Err code: "+err);}}}));}
var mp=new android.media.MediaPlayer();var zs=0;var lj=new Array();var dq=0;