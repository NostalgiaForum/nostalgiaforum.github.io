var playerXP = 0;
var shearEnchant = 0;
var axeEnchant = 0;
var pickEnchant = 0;
var shovelEnchant = 0;

function attackHook (attacker, victim)
{
if (getCarriedItem() == 268 || getCarriedItem() == 272 || getCarriedItem() == 267 || getCarriedItem() == 276 || getCarriedItem() == 283)
{
playerXP = playerXP + 1;
}
}

function useItem (x, y, z, itemId, blockId, side)
{
if (blockId == 63 || blockId == 68)
{
clientMessage ("У вас "+playerXP+" опыта.");
}
if (blockId == 57)
{
if (playerXP < 50)
{
preventDefault();
clientMessage ("У вас "+playerXP+" опыта. Вам надо 50 для зачарования");
}
if (playerXP > 50)
{
if (itemId == 359)
{
preventDefault();
playerXP = playerXP - 50;
clientMessage ("Shears enchanted with Silk Touch/Efficiency/Unbreaking. You have "+playerXP+" XP left.");
shearEnchant = 1;
}
if (itemId == 271 || itemId == 275 || itemId == 258 || itemId == 279 || itemId == 286)
{
preventDefault();
playerXP = playerXP - 50;
clientMessage ("Axe enchanted with Silk Touch/Efficiency/Unbreaking. You have "+playerXP+" XP left.");
axeEnchant = 1;
}
if (itemId == 269 || itemId == 273 || itemId == 256 || itemId == 277 || itemId == 284)
{
preventDefault();
playerXP = playerXP - 50;
clientMessage ("Shovel enchanted with Silk Touch/Efficiency/Unbreaking. You have "+playerXP+" XP left.");
shovelEnchant = 1;
}
if (itemId == 270 || itemId == 274 || itemId == 257 || itemId == 278 || itemId == 285)
{
preventDefault();
playerXP = playerXP - 50;
clientMessage ("Кирка зачарована на Эффективность. У вас осталось"+playerXP+" опыта.");
pickEnchant = 1;
}
else
{
preventDefault();
clientMessage ("Этот предмет не зачаровывается.");
}
}
}
if (itemId == 359 && shearEnchant == 1)
{
if (blockId == 92)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (354, 1);
}
if (blockId == 30)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (30, 1);
}
}
if (axeEnchant == 1)
{
if (itemId == 271 || itemId == 275 || itemId == 258 || itemId == 279 || itemId == 286)
{
if (blockId == 47)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (47, 1);
}
if (blockId == 103)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (103, 1);
}
}
}
if (shovelEnchant == 1)
{
if (itemId == 269 || itemId == 273 || itemId == 256 || itemId == 277 || itemId == 284)
{
if (blockId == 2)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (2, 1);
}
if (blockId == 13)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (13, 1);
}
if (blockId == 60)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (60, 1);
}
if (blockId == 78)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (78, 1);
}
if (blockId == 80)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (80, 1);
}
if (blockId == 82)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (82, 1);
}
}
}
if (pickEnchant == 1)
{
if (itemId == 270 || itemId == 274 || itemId == 257 || itemId == 278 || itemId == 285)
{
if (blockId == 1)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (1, 1);
}
if (blockId == 16)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (16, 1);
}
if (blockId == 20)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (20, 1);
}
if (blockId == 21)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (21, 1);
}
if (blockId == 56)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (56, 1);
}
if (blockId == 62)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (62, 1);
}
if (blockId == 74)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (74, 1);
}
if (blockId == 79)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (79, 1);
}
if (blockId == 89)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (89, 1);
}
if (blockId == 102)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (102, 1);
}
if (blockId == 246)
{
preventDefault();
setTile (x, y, z, 0);
addItemInventory (246, 1);
}
}
}
}

function procCmd(cmd)
{
var Data = cmd.split(" ");
if (Data[0]=="nowXP")
{
clientMessage ("У вас "+playerXP+" опыта.");
}
}

