//(ENGLISH)
/*Oficial group in vk.com/minecraft_pe and vk.com/javascript_modpe*/
/*Script made by Mr_X, KillerBLS, Maks Pasichnik*/
/*License Apache for script (https://github.com/KillerBLS/ModPE-Scripts-KillerBLS/blob/master/LICENSE)*/
/*Script v1.0.0*/
//(RUSSIAN)
/*����������� ������ � vk.com/minecraft_pe � vk.com/javascript_modpe*/
/*������ ������� Mr_X, KillerBLS, Maks Pasichnik*/
/*�������� Apache ��� �������(https://github.com/KillerBLS/ModPE-Scripts-KillerBLS/blob/master/LICENSE)*/
/*������ v1.0.0*/

ModPE.setItem(460,"potion_bottle_drinkable",0,"Potion Bottle");
ModPE.setItem(461,"experience_bottle",0,"Experience Bottle");
ModPE.setItem(462,"fireball",0,"XP");
Item.setCategory(461,3)
Item.setCategory(187,3)
Player.addItemCreativeInv(461,1,0);
Player.addItemCreativeInv(187,1,0);
Item.addShapedRecipe(187, 1, 0, ["   ", "ghg", "hhh"], ["g", 264, 0,"h", 49,0])
Item.addShapedRecipe(460, 1, 0, ["ggg", "g g", "ggg"], ["g", 20, 0])
Item.addShapedRecipe(461, 1, 0, [" g ", " n ", "   "], ["g", 462, 0,"n",460,0])
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var Ydiff=0;
var Xdiff=0;
var x=0;
var Zdiff=0;
var part = ParticleType.crit;
var s = " ";
var c=0;
var a=0;
var u=1;
var bar = 0;
var barvisibl=0;
var lvl=0;
var GUIBar;
var arrow;
var swordEwood = 0;
var swordEstone = 0;
var swordEiron = 0;
var swordEgold = 0;
var swordEdiamond = 0;
var bowEnchant = 0;

var axeEnchant1 = 0;
var axeEnchant2 = 0;
var axeEnchant3 = 0;
var axeEnchant4 = 0;
var axeEnchant5 = 0;

var shovelEnchant1 = 0;
var shovelEnchant2 = 0;
var shovelEnchant3 = 0;
var shovelEnchant4 = 0;
var shovelEnchant5 = 0;

var bootsEnchant1 = 0;
var bootsEnchant2 = 0;
var bootsEnchant3 = 0;
var bootsEnchant4 = 0;
var bootsEnchant5 = 0;

var legginsEnchant1 = 0;
var legginsEnchant2 = 0;
var legginsEnchant3 = 0;
var legginsEnchant4 = 0;
var legginsEnchant5 = 0;

var chetsplateEnchant1 = 0;
var chetsplateEnchant2 = 0;
var chetsplateEnchant3 = 0;
var chetsplateEnchant4 = 0;
var chetsplateEnchant5 = 0;

var helmetEnchant1 = 0;
var helmetEnchant2 = 0;
var helmetEnchant3 = 0;
var helmetEnchant4 = 0;
var helmetEnchant5 = 0;

var pickEnchant1 = 0;
var pickEnchant2 = 0;
var pickEnchant3 = 0;
var pickEnchant4 = 0;
var pickEnchant5 = 0;

var attack = 0;
var count = 0;
var y = 0;
var x = 0;
var z = 0;

function useItem(x, y, z, itemId, blockId, side) {
var fws = Math.floor ((Math.random() * 2) + 1);
if(itemId==461)
{
c=1;
a=1;
Level.playSound(x,y,z,"random.glass",20,20);
Player.addItemInventory(461,-1,0);
}
if(bar>=7)
{
barvisibl=1;
bar=1;
lvl++;
}
if(fws==1&&lvl==10||lvl==11||lvl==12||lvl==13||lvl==14||lvl==15||lvl==16||lvl==17||lvl==18||lvl==19)
{
if (itemId == 267 && blockId == 187)
{
preventDefault();
swordEiron = 1;
lvl-=10
clientMessage(ChatColor.GREEN + "Iron sword is enchanted(1).");
}
if(itemId == 276 &&  blockId == 187)
{
preventDefault();
swordEdiamond = 1;
lvl-=10
clientMessage(ChatColor.GREEN + "Diamomd sword is enchanted(1).");
}
if(itemId == 268 &&  blockId == 187)
{
preventDefault();
swordEwood = 1;
lvl-=10
clientMessage(ChatColor.GREEN + "Wooden sword is enchanted(1).");
}
if(itemId == 283 &&  blockId == 187)
{
preventDefault();
swordEgold = 1;
lvl-=10
clientMessage(ChatColor.GREEN + "Golden sword is enchanted(1).");
}
if(itemId == 272 &&  blockId == 187)
{
preventDefault();
swordEstone = 1;
attack = 1;
lvl-=10
clientMessage(ChatColor.GREEN + "Stone sword is enchanted(1).");
}
if (itemId == 271 && blockId == 187)
{
preventDefault();
axeEnchant1 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 275 && blockId == 187)
{
preventDefault();
axeEnchant2 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 258 && blockId == 187)
{
preventDefault();
axeEnchant3 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 279 && blockId == 187)
{
preventDefault();
axeEnchant4 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 286 && blockId == 187)
{
preventDefault();
axeEnchant5 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 269 && blockId == 187)
{
preventDefault();
shovelEnchant1 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 273 && blockId == 187)
{
preventDefault();
shovelEnchant2 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 256 && blockId == 187)
{
preventDefault();
shovelEnchant3 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 277 && blockId == 187)
{
preventDefault();
shovelEnchant4 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 284 && blockId == 187)
{
preventDefault();
shovelEnchant5 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 301 && blockId == 187)
{
preventDefault();
BootsEnchant1 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 305 && blockId == 187)
{
preventDefault();
BootsEnchant2 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 309 && blockId == 187)
{
preventDefault();
BootsEnchant3 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 313 && blockId == 187)
{
preventDefault();
BootsEnchant4 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 317 && blockId == 187)
{
preventDefault();
BootsEnchant5 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 304 && blockId == 187)
{
preventDefault();
legginsEnchant1= 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 308 && blockId == 187)
{
preventDefault();
legginsEnchant2 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 312 && blockId == 187)
{
preventDefault();
legginsEnchant3 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 316 && blockId == 187)
{
preventDefault();
legginsEnchant4 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 300 && blockId == 187)
{
preventDefault();
legginsEnchant5 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 307 && blockId == 187)
{
preventDefault();
chetsplateEnchant1 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 311 && blockId == 187)
{
preventDefault();
chetsplateEnchant2 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 315 && blockId == 187)
{
preventDefault();
chetsplateEnchant3 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 303 && blockId == 187)
{
preventDefault();
chetsplateEnchant4 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 299 && blockId == 187)
{
preventDefault();
chetsplateEnchant5 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 310 && blockId == 187)
{
preventDefault();
helmetEnchant1 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 298 && blockId == 187)
{
preventDefault();
helmetEnchant2 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 314 && blockId == 187)
{
preventDefault();
helmetEnchant3 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 302 && blockId == 187)
{
preventDefault();
helmetEnchant4 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 306 && blockId == 187)
{
preventDefault();
helmetEnchant5 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 278 && blockId == 187)
{
preventDefault();
pickEnchant1 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 285 && blockId == 187)
{
preventDefault();
pickEnchant2 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 257 && blockId == 187)
{
preventDefault();
pickEnchant3 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 270 && blockId == 187)
{
preventDefault();
pickEnchant4 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 274 && blockId == 187)
{
preventDefault();
pickEnchant5 = 1;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if(itemId == 261 &&  blockId == 187)
{
preventDefault();
clientMessage(ChatColor.RED + "Not lvl>20");
}
}
if(fws==2&&lvl==10||lvl==11||lvl==12||lvl==13||lvl==14||lvl==15||lvl==16||lvl==17||lvl==18||lvl==19)
{
if (itemId == 267 && blockId == 187)
{
preventDefault();
swordEiron = 2;
lvl-=10
clientMessage(ChatColor.GREEN + "Iron sword is enchanted (3).");
}
if(itemId == 276 &&  blockId == 187)
{
preventDefault();
swordEdiamond = 2;
lvl-=10
clientMessage(ChatColor.GREEN + "Diamomd sword is enchanted (3).");
}
if(itemId == 268 &&  blockId == 187)
{
preventDefault();
swordEwood = 2;
lvl-=10
clientMessage(ChatColor.GREEN + "Wooden sword is enchanted (3).");
}
if(itemId == 283 &&  blockId == 187)
{
preventDefault();
swordEgold = 2;
lvl-=10
clientMessage(ChatColor.GREEN + "Golden sword is enchanted (3).");
}
if(itemId == 272 &&  blockId == 187)
{
preventDefault();
swordEstone = 2;
lvl-=10
attack = 1;
clientMessage(ChatColor.GREEN + "Stone sword is enchanted (3).");
}
if (itemId == 271 && blockId == 187)
{
preventDefault();
axeEnchant1 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 275 && blockId == 187)
{
preventDefault();
axeEnchant2 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 258 && blockId == 187)
{
preventDefault();
axeEnchant3 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 279 && blockId == 187)
{
preventDefault();
axeEnchant4 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 286 && blockId == 187)
{
preventDefault();
axeEnchant5 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 269 && blockId == 187)
{
preventDefault();
shovelEnchant1 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 273 && blockId == 187)
{
preventDefault();
shovelEnchant2 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 256 && blockId == 187)
{
preventDefault();
shovelEnchant3 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 277 && blockId == 187)
{
preventDefault();
shovelEnchant4 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 284 && blockId == 187)
{
preventDefault();
shovelEnchant5 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 301 && blockId == 187)
{
preventDefault();
BootsEnchant1 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 305 && blockId == 187)
{
preventDefault();
BootsEnchant2 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 309 && blockId == 187)
{
preventDefault();
BootsEnchant3 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 313 && blockId == 187)
{
preventDefault();
BootsEnchant4 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 317 && blockId == 187)
{
preventDefault();
BootsEnchant5 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 304 && blockId == 187)
{
preventDefault();
legginsEnchant1= 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 308 && blockId == 187)
{
preventDefault();
legginsEnchant2 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 312 && blockId == 187)
{
preventDefault();
legginsEnchant3 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 316 && blockId == 187)
{
preventDefault();
legginsEnchant4 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 300 && blockId == 187)
{
preventDefault();
legginsEnchant5 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 307 && blockId == 187)
{
preventDefault();
chetsplateEnchant1 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 311 && blockId == 187)
{
preventDefault();
chetsplateEnchant2 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 315 && blockId == 187)
{
preventDefault();
chetsplateEnchant3 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 303 && blockId == 187)
{
preventDefault();
chetsplateEnchant4 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 299 && blockId == 187)
{
preventDefault();
chetsplateEnchant5 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 310 && blockId == 187)
{
preventDefault();
helmetEnchant1 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 298 && blockId == 187)
{
preventDefault();
helmetEnchant2 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 314 && blockId == 187)
{
preventDefault();
helmetEnchant3 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 302 && blockId == 187)
{
preventDefault();
helmetEnchant4 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 306 && blockId == 187)
{
preventDefault();
helmetEnchant5 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 278 && blockId == 187)
{
preventDefault();
pickEnchant1 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 285 && blockId == 187)
{
preventDefault();
pickEnchant2 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 257 && blockId == 187)
{
preventDefault();
pickEnchant3 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 270 && blockId == 187)
{
preventDefault();
pickEnchant4 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 274 && blockId == 187)
{
preventDefault();
pickEnchant5 = 2;
lvl-=10
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if(itemId == 261 &&  blockId == 187)
{
preventDefault();
clientMessage(ChatColor.RED + "Not lvl>20");
}
}
var kws = Math.floor ((Math.random() * 3) + 1);
if(kws==1&&lvl==20|| lvl==21|| lvl==22|| lvl==23|| lvl==24|| lvl==25|| lvl==26|| lvl==27|| lvl==28|| lvl==29)
{
if (itemId == 267 && blockId == 187)
{
preventDefault();
swordEiron = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Iron sword is enchanted(1).");
}
if(itemId == 276 &&  blockId == 187)
{
preventDefault();
swordEdiamond = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Diamomd sword is enchanted(1).");
}
if(itemId == 268 &&  blockId == 187)
{
preventDefault();
swordEwood = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Wooden sword is enchanted(1).");
}
if(itemId == 283 &&  blockId == 187)
{
preventDefault();
swordEgold = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Golden sword is enchanted(1).");
}
if(itemId == 272 &&  blockId == 187)
{
preventDefault();
swordEstone = 1;
attack = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Stone sword is enchanted(1).");
}
if (itemId == 271 && blockId == 187)
{
preventDefault();
axeEnchant1 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 275 && blockId == 187)
{
preventDefault();
axeEnchant2 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 258 && blockId == 187)
{
preventDefault();
axeEnchant3 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 279 && blockId == 187)
{
preventDefault();
axeEnchant4 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 286 && blockId == 187)
{
preventDefault();
axeEnchant5 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 269 && blockId == 187)
{
preventDefault();
shovelEnchant1 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 273 && blockId == 187)
{
preventDefault();
shovelEnchant2 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 256 && blockId == 187)
{
preventDefault();
shovelEnchant3 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 277 && blockId == 187)
{
preventDefault();
shovelEnchant4 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 284 && blockId == 187)
{
preventDefault();
shovelEnchant5 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 301 && blockId == 187)
{
preventDefault();
BootsEnchant1 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 305 && blockId == 187)
{
preventDefault();
BootsEnchant2 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 309 && blockId == 187)
{
preventDefault();
BootsEnchant3 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 313 && blockId == 187)
{
preventDefault();
BootsEnchant4 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 317 && blockId == 187)
{
preventDefault();
BootsEnchant5 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 304 && blockId == 187)
{
preventDefault();
legginsEnchant1= 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 308 && blockId == 187)
{
preventDefault();
legginsEnchant2 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 312 && blockId == 187)
{
preventDefault();
legginsEnchant3 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 316 && blockId == 187)
{
preventDefault();
legginsEnchant4 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 300 && blockId == 187)
{
preventDefault();
legginsEnchant5 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 307 && blockId == 187)
{
preventDefault();
chetsplateEnchant1 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 311 && blockId == 187)
{
preventDefault();
chetsplateEnchant2 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 315 && blockId == 187)
{
preventDefault();
chetsplateEnchant3 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 303 && blockId == 187)
{
preventDefault();
chetsplateEnchant4 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 299 && blockId == 187)
{
preventDefault();
chetsplateEnchant5 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 310 && blockId == 187)
{
preventDefault();
helmetEnchant1 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 298 && blockId == 187)
{
preventDefault();
helmetEnchant2 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 314 && blockId == 187)
{
preventDefault();
helmetEnchant3 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 302 && blockId == 187)
{
preventDefault();
helmetEnchant4 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 306 && blockId == 187)
{
preventDefault();
helmetEnchant5 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 278 && blockId == 187)
{
preventDefault();
pickEnchant1 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 285 && blockId == 187)
{
preventDefault();
pickEnchant2 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 257 && blockId == 187)
{
preventDefault();
pickEnchant3 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 270 && blockId == 187)
{
preventDefault();
pickEnchant4 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 274 && blockId == 187)
{
preventDefault();
pickEnchant5 = 1;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if(itemId == 261 &&  blockId == 187)
{
preventDefault();
bowEnchant = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Bow is enchanted (3).");
}
}
if(kws==2&&lvl==20|| lvl==21|| lvl==22|| lvl==23|| lvl==24|| lvl==25|| lvl==26|| lvl==27|| lvl==28|| lvl==29)
{
if (itemId == 267 && blockId == 187)
{
preventDefault();
swordEiron = 2;
lvl-=20
clientMessage(ChatColor.GREEN + "Iron sword is enchanted (3).");
}
if(itemId == 276 &&  blockId == 187)
{
preventDefault();
swordEdiamond = 2;
lvl-=20
clientMessage(ChatColor.GREEN + "Diamomd sword is enchanted (3).");
}
if(itemId == 268 &&  blockId == 187)
{
preventDefault();
swordEwood = 2;
lvl-=20
clientMessage(ChatColor.GREEN + "Wooden sword is enchanted (3).");
}
if(itemId == 283 &&  blockId == 187)
{
preventDefault();
swordEgold = 2;
lvl-=20
clientMessage(ChatColor.GREEN + "Golden sword is enchanted (3).");
}
if(itemId == 272 &&  blockId == 187)
{
preventDefault();
swordEstone = 2;
lvl-=20
attack = 1;
clientMessage(ChatColor.GREEN + "Stone sword is enchanted (3).");
}
if (itemId == 271 && blockId == 187)
{
preventDefault();
axeEnchant1 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 275 && blockId == 187)
{
preventDefault();
axeEnchant2 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 258 && blockId == 187)
{
preventDefault();
axeEnchant3 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 279 && blockId == 187)
{
preventDefault();
axeEnchant4 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 286 && blockId == 187)
{
preventDefault();
axeEnchant5 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 269 && blockId == 187)
{
preventDefault();
shovelEnchant1 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 273 && blockId == 187)
{
preventDefault();
shovelEnchant2 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 256 && blockId == 187)
{
preventDefault();
shovelEnchant3 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 277 && blockId == 187)
{
preventDefault();
shovelEnchant4 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 284 && blockId == 187)
{
preventDefault();
shovelEnchant5 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 301 && blockId == 187)
{
preventDefault();
BootsEnchant1 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 305 && blockId == 187)
{
preventDefault();
BootsEnchant2 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 309 && blockId == 187)
{
preventDefault();
BootsEnchant3 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 313 && blockId == 187)
{
preventDefault();
BootsEnchant4 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 317 && blockId == 187)
{
preventDefault();
BootsEnchant5 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 304 && blockId == 187)
{
preventDefault();
legginsEnchant1= 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 308 && blockId == 187)
{
preventDefault();
legginsEnchant2 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 312 && blockId == 187)
{
preventDefault();
legginsEnchant3 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 316 && blockId == 187)
{
preventDefault();
legginsEnchant4 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 300 && blockId == 187)
{
preventDefault();
legginsEnchant5 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 307 && blockId == 187)
{
preventDefault();
chetsplateEnchant1 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 311 && blockId == 187)
{
preventDefault();
chetsplateEnchant2 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 315 && blockId == 187)
{
preventDefault();
chetsplateEnchant3 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 303 && blockId == 187)
{
preventDefault();
chetsplateEnchant4 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 299 && blockId == 187)
{
preventDefault();
chetsplateEnchant5 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 310 && blockId == 187)
{
preventDefault();
helmetEnchant1 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 298 && blockId == 187)
{
preventDefault();
helmetEnchant2 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 314 && blockId == 187)
{
preventDefault();
helmetEnchant3 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 302 && blockId == 187)
{
preventDefault();
helmetEnchant4 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 306 && blockId == 187)
{
preventDefault();
helmetEnchant5 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 278 && blockId == 187)
{
preventDefault();
pickEnchant1 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 285 && blockId == 187)
{
preventDefault();
pickEnchant2 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 257 && blockId == 187)
{
preventDefault();
pickEnchant3 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 270 && blockId == 187)
{
preventDefault();
pickEnchant4 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 274 && blockId == 187)
{
preventDefault();
pickEnchant5 = 2;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if(itemId == 261 &&  blockId == 187)
{
preventDefault();
bowEnchant = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Bow is enchanted (3).");
}
}
if(kws==3&&lvl==20|| lvl==21|| lvl==22|| lvl==23|| lvl==24|| lvl==25|| lvl==26|| lvl==27|| lvl==28|| lvl==29)
{
if (itemId == 267 && blockId == 187)
{
preventDefault();
swordEiron = 3;
lvl-=20
clientMessage(ChatColor.GREEN + "Iron sword is enchanted (5).");
}
if(itemId == 276 &&  blockId == 187)
{
preventDefault();
swordEdiamond = 3;
lvl-=20
clientMessage(ChatColor.GREEN + "Diamomd sword is enchanted (5).");
}
if(itemId == 268 &&  blockId == 187)
{
preventDefault();
swordEwood = 3;
lvl-=20
clientMessage(ChatColor.GREEN + "Wooden sword is enchanted (5).");
}
if(itemId == 283 &&  blockId == 187)
{
preventDefault();
swordEgold = 3;
lvl-=20
clientMessage(ChatColor.GREEN + "Golden sword is enchanted (5).");
}
if(itemId == 272 &&  blockId == 187)
{
preventDefault();
swordEstone = 3;
attack = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Stone sword is enchanted (5).");
}
if (itemId == 271 && blockId == 187)
{
preventDefault();
axeEnchant1 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 275 && blockId == 187)
{
preventDefault();
axeEnchant2 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 258 && blockId == 187)
{
preventDefault();
axeEnchant3 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 279 && blockId == 187)
{
preventDefault();
axeEnchant4 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 286 && blockId == 187)
{
preventDefault();
axeEnchant5 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 269 && blockId == 187)
{
preventDefault();
shovelEnchant1 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 273 && blockId == 187)
{
preventDefault();
shovelEnchant2 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 256 && blockId == 187)
{
preventDefault();
shovelEnchant3 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 277 && blockId == 187)
{
preventDefault();
shovelEnchant4 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 284 && blockId == 187)
{
preventDefault();
shovelEnchant5 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 301 && blockId == 187)
{
preventDefault();
BootsEnchant1 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 305 && blockId == 187)
{
preventDefault();
BootsEnchant2 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 309 && blockId == 187)
{
preventDefault();
BootsEnchant3 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 313 && blockId == 187)
{
preventDefault();
BootsEnchant4 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 317 && blockId == 187)
{
preventDefault();
BootsEnchant5 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 304 && blockId == 187)
{
preventDefault();
legginsEnchant1= 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 308 && blockId == 187)
{
preventDefault();
legginsEnchant2 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 312 && blockId == 187)
{
preventDefault();
legginsEnchant3 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 316 && blockId == 187)
{
preventDefault();
legginsEnchant4 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 300 && blockId == 187)
{
preventDefault();
legginsEnchant5 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 307 && blockId == 187)
{
preventDefault();
chetsplateEnchant1 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 311 && blockId == 187)
{
preventDefault();
chetsplateEnchant2 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 315 && blockId == 187)
{
preventDefault();
chetsplateEnchant3 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 303 && blockId == 187)
{
preventDefault();
chetsplateEnchant4 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 299 && blockId == 187)
{
preventDefault();
chetsplateEnchant5 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 310 && blockId == 187)
{
preventDefault();
helmetEnchant1 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 298 && blockId == 187)
{
preventDefault();
helmetEnchant2 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 314 && blockId == 187)
{
preventDefault();
helmetEnchant3 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 302 && blockId == 187)
{
preventDefault();
helmetEnchant4 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 306 && blockId == 187)
{
preventDefault();
helmetEnchant5 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 278 && blockId == 187)
{
preventDefault();
pickEnchant1 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if (itemId == 285 && blockId == 187)
{
preventDefault();
pickEnchant2 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if (itemId == 257 && blockId == 187)
{
preventDefault();
pickEnchant3 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if (itemId == 270 && blockId == 187)
{
preventDefault();
pickEnchant4 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if (itemId == 274 && blockId == 187)
{
preventDefault();
pickEnchant5 = 3;
lvl-=20
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if(itemId == 261 &&  blockId == 187)
{
preventDefault();
bowEnchant = 1;
lvl-=20
clientMessage(ChatColor.GREEN + "Bow is enchanted (3).");
}
}
var zws = Math.floor ((Math.random() * 3) + 1);
if(lvl>=30&&zws==1)
{
if (itemId == 267 && blockId == 187)
{
preventDefault();
swordEiron = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Iron sword is enchanted(1).");
}
if(itemId == 276 &&  blockId == 187)
{
preventDefault();
swordEdiamond = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Diamomd sword is enchanted(1).");
}
if(itemId == 268 &&  blockId == 187)
{
preventDefault();
swordEwood = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Wooden sword is enchanted(1).");
}
if(itemId == 283 &&  blockId == 187)
{
preventDefault();
swordEgold = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Golden sword is enchanted(1).");
}
if(itemId == 272 &&  blockId == 187)
{
preventDefault();
swordEstone = 1;
attack = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Stone sword is enchanted(1).");
}
if (itemId == 271 && blockId == 187)
{
preventDefault();
axeEnchant1 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 275 && blockId == 187)
{
preventDefault();
axeEnchant2 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 258 && blockId == 187)
{
preventDefault();
axeEnchant3 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 279 && blockId == 187)
{
preventDefault();
axeEnchant4 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 286 && blockId == 187)
{
preventDefault();
axeEnchant5 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 269 && blockId == 187)
{
preventDefault();
shovelEnchant1 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 273 && blockId == 187)
{
preventDefault();
shovelEnchant2 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 256 && blockId == 187)
{
preventDefault();
shovelEnchant3 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 277 && blockId == 187)
{
preventDefault();
shovelEnchant4 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 284 && blockId == 187)
{
preventDefault();
shovelEnchant5 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (1).");
}
if (itemId == 301 && blockId == 187)
{
preventDefault();
BootsEnchant1 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 305 && blockId == 187)
{
preventDefault();
BootsEnchant2 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 309 && blockId == 187)
{
preventDefault();
BootsEnchant3 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 313 && blockId == 187)
{
preventDefault();
BootsEnchant4 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 317 && blockId == 187)
{
preventDefault();
BootsEnchant5 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (1).");
}
if (itemId == 304 && blockId == 187)
{
preventDefault();
legginsEnchant1= 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 308 && blockId == 187)
{
preventDefault();
legginsEnchant2 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 312 && blockId == 187)
{
preventDefault();
legginsEnchant3 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 316 && blockId == 187)
{
preventDefault();
legginsEnchant4 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 300 && blockId == 187)
{
preventDefault();
legginsEnchant5 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (1).");
}
if (itemId == 307 && blockId == 187)
{
preventDefault();
chetsplateEnchant1 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 311 && blockId == 187)
{
preventDefault();
chetsplateEnchant2 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 315 && blockId == 187)
{
preventDefault();
chetsplateEnchant3 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 303 && blockId == 187)
{
preventDefault();
chetsplateEnchant4 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 299 && blockId == 187)
{
preventDefault();
chetsplateEnchant5 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (1).");
}
if (itemId == 310 && blockId == 187)
{
preventDefault();
helmetEnchant1 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 298 && blockId == 187)
{
preventDefault();
helmetEnchant2 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 314 && blockId == 187)
{
preventDefault();
helmetEnchant3 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 302 && blockId == 187)
{
preventDefault();
helmetEnchant4 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 306 && blockId == 187)
{
preventDefault();
helmetEnchant5 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (1).");
}
if (itemId == 278 && blockId == 187)
{
preventDefault();
pickEnchant1 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 285 && blockId == 187)
{
preventDefault();
pickEnchant2 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 257 && blockId == 187)
{
preventDefault();
pickEnchant3 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 270 && blockId == 187)
{
preventDefault();
pickEnchant4 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if (itemId == 274 && blockId == 187)
{
preventDefault();
pickEnchant5 = 1;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (1).");
}
if(itemId == 261 &&  blockId == 187)
{
preventDefault();
bowEnchant = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Bow is enchanted (3).");
}
}
if(lvl>=30&&zws==2)
{
if (itemId == 267 && blockId == 187)
{
preventDefault();
swordEiron = 2;
lvl-=30
clientMessage(ChatColor.GREEN + "Iron sword is enchanted (3).");
}
if(itemId == 276 &&  blockId == 187)
{
preventDefault();
swordEdiamond = 2;
lvl-=30
clientMessage(ChatColor.GREEN + "Diamomd sword is enchanted (3).");
}
if(itemId == 268 &&  blockId == 187)
{
preventDefault();
swordEwood = 2;
lvl-=30
clientMessage(ChatColor.GREEN + "Wooden sword is enchanted (3).");
}
if(itemId == 283 &&  blockId == 187)
{
preventDefault();
swordEgold = 2;
lvl-=30
clientMessage(ChatColor.GREEN + "Golden sword is enchanted (3).");
}
if(itemId == 272 &&  blockId == 187)
{
preventDefault();
swordEstone = 2;
lvl-=30
attack = 1;
clientMessage(ChatColor.GREEN + "Stone sword is enchanted (3).");
}
if (itemId == 271 && blockId == 187)
{
preventDefault();
axeEnchant1 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 275 && blockId == 187)
{
preventDefault();
axeEnchant2 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 258 && blockId == 187)
{
preventDefault();
axeEnchant3 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 279 && blockId == 187)
{
preventDefault();
axeEnchant4 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 286 && blockId == 187)
{
preventDefault();
axeEnchant5 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 269 && blockId == 187)
{
preventDefault();
shovelEnchant1 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 273 && blockId == 187)
{
preventDefault();
shovelEnchant2 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 256 && blockId == 187)
{
preventDefault();
shovelEnchant3 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 277 && blockId == 187)
{
preventDefault();
shovelEnchant4 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 284 && blockId == 187)
{
preventDefault();
shovelEnchant5 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (3).");
}
if (itemId == 301 && blockId == 187)
{
preventDefault();
BootsEnchant1 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 305 && blockId == 187)
{
preventDefault();
BootsEnchant2 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 309 && blockId == 187)
{
preventDefault();
BootsEnchant3 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 313 && blockId == 187)
{
preventDefault();
BootsEnchant4 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 317 && blockId == 187)
{
preventDefault();
BootsEnchant5 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (3).");
}
if (itemId == 304 && blockId == 187)
{
preventDefault();
legginsEnchant1= 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 308 && blockId == 187)
{
preventDefault();
legginsEnchant2 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 312 && blockId == 187)
{
preventDefault();
legginsEnchant3 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 316 && blockId == 187)
{
preventDefault();
legginsEnchant4 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 300 && blockId == 187)
{
preventDefault();
legginsEnchant5 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (3).");
}
if (itemId == 307 && blockId == 187)
{
preventDefault();
chetsplateEnchant1 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 311 && blockId == 187)
{
preventDefault();
chetsplateEnchant2 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 315 && blockId == 187)
{
preventDefault();
chetsplateEnchant3 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 303 && blockId == 187)
{
preventDefault();
chetsplateEnchant4 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 299 && blockId == 187)
{
preventDefault();
chetsplateEnchant5 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (3).");
}
if (itemId == 310 && blockId == 187)
{
preventDefault();
helmetEnchant1 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 298 && blockId == 187)
{
preventDefault();
helmetEnchant2 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 314 && blockId == 187)
{
preventDefault();
helmetEnchant3 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 302 && blockId == 187)
{
preventDefault();
helmetEnchant4 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 306 && blockId == 187)
{
preventDefault();
helmetEnchant5 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (3).");
}
if (itemId == 278 && blockId == 187)
{
preventDefault();
pickEnchant1 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 285 && blockId == 187)
{
preventDefault();
pickEnchant2 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 257 && blockId == 187)
{
preventDefault();
pickEnchant3 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 270 && blockId == 187)
{
preventDefault();
pickEnchant4 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if (itemId == 274 && blockId == 187)
{
preventDefault();
pickEnchant5 = 2;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (3).");
}
if(itemId == 261 &&  blockId == 187)
{
preventDefault();
bowEnchant = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Bow is enchanted (3).");
}
}
if(lvl>=30&&zws==3)
{
if (itemId == 267 && blockId == 187)
{
preventDefault();
swordEiron = 3;
lvl-=30
clientMessage(ChatColor.GREEN + "Iron sword is enchanted (5).");
}
if(itemId == 276 &&  blockId == 187)
{
preventDefault();
swordEdiamond = 3;
lvl-=30
clientMessage(ChatColor.GREEN + "Diamomd sword is enchanted (5).");
}
if(itemId == 268 &&  blockId == 187)
{
preventDefault();
swordEwood = 3;
lvl-=30
clientMessage(ChatColor.GREEN + "Wooden sword is enchanted (5).");
}
if(itemId == 283 &&  blockId == 187)
{
preventDefault();
swordEgold = 3;
lvl-=30
clientMessage(ChatColor.GREEN + "Golden sword is enchanted (5).");
}
if(itemId == 272 &&  blockId == 187)
{
preventDefault();
swordEstone = 3;
attack = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Stone sword is enchanted (5).");
}
if (itemId == 271 && blockId == 187)
{
preventDefault();
axeEnchant1 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 275 && blockId == 187)
{
preventDefault();
axeEnchant2 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 258 && blockId == 187)
{
preventDefault();
axeEnchant3 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 279 && blockId == 187)
{
preventDefault();
axeEnchant4 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 286 && blockId == 187)
{
preventDefault();
axeEnchant5 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Axe enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 269 && blockId == 187)
{
preventDefault();
shovelEnchant1 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 273 && blockId == 187)
{
preventDefault();
shovelEnchant2 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 256 && blockId == 187)
{
preventDefault();
shovelEnchant3 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 277 && blockId == 187)
{
preventDefault();
shovelEnchant4 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 284 && blockId == 187)
{
preventDefault();
shovelEnchant5 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Shovel enchanted with Silk Touch/Efficiency/Unbreaking (5).");
}
if (itemId == 301 && blockId == 187)
{
preventDefault();
BootsEnchant1 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 305 && blockId == 187)
{
preventDefault();
BootsEnchant2 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 309 && blockId == 187)
{
preventDefault();
BootsEnchant3 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 313 && blockId == 187)
{
preventDefault();
BootsEnchant4 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 317 && blockId == 187)
{
preventDefault();
BootsEnchant5 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Boots enchanted with Fire resistance/Protection (5).");
}
if (itemId == 304 && blockId == 187)
{
preventDefault();
legginsEnchant1= 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 308 && blockId == 187)
{
preventDefault();
legginsEnchant2 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 312 && blockId == 187)
{
preventDefault();
legginsEnchant3 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 316 && blockId == 187)
{
preventDefault();
legginsEnchant4 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 300 && blockId == 187)
{
preventDefault();
legginsEnchant5 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Leggins enchanted with Fire resistance/Protection (5).");
}
if (itemId == 307 && blockId == 187)
{
preventDefault();
chetsplateEnchant1 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 311 && blockId == 187)
{
preventDefault();
chetsplateEnchant2 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 315 && blockId == 187)
{
preventDefault();
chetsplateEnchant3 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 303 && blockId == 187)
{
preventDefault();
chetsplateEnchant4 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 299 && blockId == 187)
{
preventDefault();
chetsplateEnchant5 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Chetsplate enchanted with Fire resistance/Protection (5).");
}
if (itemId == 310 && blockId == 187)
{
preventDefault();
helmetEnchant1 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 298 && blockId == 187)
{
preventDefault();
helmetEnchant2 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 314 && blockId == 187)
{
preventDefault();
helmetEnchant3 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 302 && blockId == 187)
{
preventDefault();
helmetEnchant4 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 306 && blockId == 187)
{
preventDefault();
helmetEnchant5 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Helmet enchanted with Protection (5).");
}
if (itemId == 278 && blockId == 187)
{
preventDefault();
pickEnchant1 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if (itemId == 285 && blockId == 187)
{
preventDefault();
pickEnchant2 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if (itemId == 257 && blockId == 187)
{
preventDefault();
pickEnchant3 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if (itemId == 270 && blockId == 187)
{
preventDefault();
pickEnchant4 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if (itemId == 274 && blockId == 187)
{
preventDefault();
pickEnchant5 = 3;
lvl-=30
clientMessage (ChatColor.GREEN + "Pick enchanted with Silk touch/Efficiency (5).");
}
if(itemId == 261 &&  blockId == 187)
{
preventDefault();
bowEnchant = 1;
lvl-=30
clientMessage(ChatColor.GREEN + "Bow is enchanted (3).");
}
}
}

function selectLevelHook() 
{ 
Block.defineBlock(187,"Enchanting table", 
[["enchanting_table_bottom", 0], ["enchanting_table_top", 0],
["enchanting_table_side", 0], ["enchanting_table_side", 0],
["enchanting_table_side", 0], ["enchanting_table_side", 0]]);
Block.setShape(187, 0, 0, 0, 1, 5/7, 1);
}

var bar7 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/games/com.mojang/Resource/XP_bar/XP_bar7.png");
var bar6 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/games/com.mojang/Resource/XP_bar/XP_bar6.png");
var bar5 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/games/com.mojang/Resource/XP_bar/XP_bar5.png");
var bar4 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/games/com.mojang/Resource/XP_bar/XP_bar4.png");
var bar3 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/games/com.mojang/Resource/XP_bar/XP_bar3.png");
var bar2 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/games/com.mojang/Resource/XP_bar/XP_bar2.png");
var bar1 = new android.graphics.BitmapFactory.decodeFile("mnt/sdcard/games/com.mojang/Resource/XP_bar/XP_bar1.png");
var bar7img = new android.graphics.drawable.BitmapDrawable(bar7);
var bar6img = new android.graphics.drawable.BitmapDrawable(bar6);
var bar5img = new android.graphics.drawable.BitmapDrawable(bar5);
var bar4img = new android.graphics.drawable.BitmapDrawable(bar4);
var bar3img = new android.graphics.drawable.BitmapDrawable(bar3);
var bar2img = new android.graphics.drawable.BitmapDrawable(bar2);
var bar1img = new android.graphics.drawable.BitmapDrawable(bar1);

print("Thanks you for downloading Real PC")
print("Script by KillerBLS, Mr_X, Maks Pasichnik")
print("Group in vk.com/javascript_modpe")

function newLevel()
{
c=1;
}

var j=1
function modTick(){
if(j==1&&x==1){
Xpos=getPlayerX();
Zpos=getPlayerZ();
j = j + 1;
}else if(j==3){
j=1;
Xdiff=getPlayerX()-Xpos;
Zdiff=getPlayerZ()-Zpos;
setVelX(getPlayerEnt(),Xdiff);
setVelZ(getPlayerEnt(),Zdiff);
Xdiff=0;
Zdiff=0;
}if(j!=1){j = j + 1;}
ModPE.showTipMessage(s + s + s + s + s + s + s + s + s + s + ChatColor.GREEN + "\n\n" + lvl.toString());if(a==1){Level.addParticle(part.toString(),getPlayerX()+0.3,getPlayerY()-0.5+Ydiff,getPlayerZ(),0,0,0,2);Level.addParticle(part.toString(),getPlayerX(),getPlayerY()-0.5+Ydiff,getPlayerZ()-0.47,0,0,0,2);Level.addParticle(part.toString(),getPlayerX(),getPlayerY()-0.5+Ydiff,getPlayerZ()+0.5,0,0,0,2);Level.addParticle(part.toString(),getPlayerX()-0.2,getPlayerY()-0.5+Ydiff,getPlayerZ(),0,0,0,2);
a=0;}if(barvisibl==1){barvisibl = 0;ctx.runOnUiThread(new java.lang.Runnable(){run: function(){try{GUIBar = new android.widget.PopupWindow();var layoutBar = new android.widget.LinearLayout(ctx);layoutBar.setOrientation(android.widget.LinearLayout.VERTICAL);GUIBar.setContentView(layoutBar);
GUIBar.setWidth(450);
GUIBar.setHeight(15);
var btnBar = new android.widget.Button(ctx);layoutBar.addView(btnBar);if(bar==1){btnBar.setBackgroundDrawable(bar1img); }else if(bar==2){btnBar.setBackgroundDrawable(bar2img);}else if(bar==3){btnBar.setBackgroundDrawable(bar3img);}else if(bar==4){btnBar.setBackgroundDrawable(bar4img);}else if(bar==5){btnBar.setBackgroundDrawable(bar5img);}else if(bar==6){btnBar.setBackgroundDrawable(bar6img);}else if(bar==7){btnBar.setBackgroundDrawable(bar7img);}btnBar.setText("\n");GUIBar.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.CENTER | android.view.Gravity.BOTTOM, 0, 65);}catch(e){print("Check the Instructions, you've made something wrong!");}}})}if(c==1){barvisibl = 1;bar++;c=0;}
if(getCarriedItem()==271&&axeEnchant1==1)
{
Block.setDestroyTime(17, 1);
Block.setDestroyTime(47, 1);
Block.setDestroyTime(103, 1);
Block.setDestroyTime(17.1, 1);
Block.setDestroyTime(17.2, 1);
Block.setDestroyTime(5, 1);
}
if(getCarriedItem()==275&&axeEnchant2==1)
{
Block.setDestroyTime(17, 1);
Block.setDestroyTime(47, 1);
Block.setDestroyTime(103, 1);
Block.setDestroyTime(17.1, 1);
Block.setDestroyTime(17.2, 1);
Block.setDestroyTime(5, 1);
}
if(getCarriedItem()==286&&axeEnchant3==1)
{
Block.setDestroyTime(17, 1);
Block.setDestroyTime(47, 1);
Block.setDestroyTime(103, 1);
Block.setDestroyTime(17.1, 1);
Block.setDestroyTime(17.2, 1);
Block.setDestroyTime(5, 1);
}
if(getCarriedItem()==258&&axeEnchant4==1)
{
Block.setDestroyTime(17, 1);
Block.setDestroyTime(47, 1);
Block.setDestroyTime(103, 1);
Block.setDestroyTime(17.1, 1);
Block.setDestroyTime(17.2, 1);
Block.setDestroyTime(5, 1);
}
if(getCarriedItem()==279&&axeEnchant5==1)
{
Block.setDestroyTime(17, 1);
Block.setDestroyTime(47, 1);
Block.setDestroyTime(103, 1);
Block.setDestroyTime(17.1, 1);
Block.setDestroyTime(17.2, 1);
Block.setDestroyTime(5, 1);
}
if(getCarriedItem()==271&&axeEnchant1==2)
{
Block.setDestroyTime(17, 0.8);
Block.setDestroyTime(47, 0.8);
Block.setDestroyTime(103, 0.8);
Block.setDestroyTime(17.1, 0.8);
Block.setDestroyTime(17.2, 0.8);
Block.setDestroyTime(5, 0.8);
}
if(getCarriedItem()==275&&axeEnchant2==2)
{
Block.setDestroyTime(17, 0.8);
Block.setDestroyTime(47, 0.8);
Block.setDestroyTime(103, 0.8);
Block.setDestroyTime(17.1, 0.8);
Block.setDestroyTime(17.2, 0.8);
Block.setDestroyTime(5, 0.8);
}
if(getCarriedItem()==286&&axeEnchant3==2)
{
Block.setDestroyTime(17, 0.8);
Block.setDestroyTime(47, 0.8);
Block.setDestroyTime(103, 0.8);
Block.setDestroyTime(17.1, 0.8);
Block.setDestroyTime(17.2, 0.8);
Block.setDestroyTime(5, 0.8);
}
if(getCarriedItem()==258&&axeEnchant4==2)
{
Block.setDestroyTime(17, 0.8);
Block.setDestroyTime(47, 0.8);
Block.setDestroyTime(103, 0.8);
Block.setDestroyTime(17.1, 0.8);
Block.setDestroyTime(17.2, 0.8);
Block.setDestroyTime(5, 0.8);
}
if(getCarriedItem()==279&&axeEnchant5==2)
{
Block.setDestroyTime(17, 0.8);
Block.setDestroyTime(47, 0.8);
Block.setDestroyTime(103, 0.8);
Block.setDestroyTime(17.1, 0.8);
Block.setDestroyTime(17.2, 0.8);
Block.setDestroyTime(5, 0.8);
}
if(getCarriedItem()==271&&axeEnchant1==3)
{
Block.setDestroyTime(17, 0.6);
Block.setDestroyTime(47, 0.6);
Block.setDestroyTime(103, 0.6);
Block.setDestroyTime(17.1, 0.6);
Block.setDestroyTime(17.2, 0.6);
Block.setDestroyTime(5, 0.6);
}
if(getCarriedItem()==275&&axeEnchant2==3)
{
Block.setDestroyTime(17, 0.6);
Block.setDestroyTime(47, 0.6);
Block.setDestroyTime(103, 0.6);
Block.setDestroyTime(17.1, 0.6);
Block.setDestroyTime(17.2, 0.6);
Block.setDestroyTime(5, 0.6);
}
if(getCarriedItem()==286&&axeEnchant3==3)
{
Block.setDestroyTime(17, 0.6);
Block.setDestroyTime(47, 0.6);
Block.setDestroyTime(103, 0.6);
Block.setDestroyTime(17.1, 0.6);
Block.setDestroyTime(17.2, 0.6);
Block.setDestroyTime(5, 0.6);
}
if(getCarriedItem()==258&&axeEnchant4==3)
{
Block.setDestroyTime(17, 0.6);
Block.setDestroyTime(47, 0.6);
Block.setDestroyTime(103, 0.6);
Block.setDestroyTime(17.1, 0.6);
Block.setDestroyTime(17.2, 0.6);
Block.setDestroyTime(5, 0.6);
}
if(getCarriedItem()==279&&axeEnchant5==3)
{
Block.setDestroyTime(17, 0.6);
Block.setDestroyTime(47, 0.6);
Block.setDestroyTime(103, 0.6);
Block.setDestroyTime(17.1, 0.6);
Block.setDestroyTime(17.2, 0.6);
Block.setDestroyTime(5, 0.6);
}
//2
if(getCarriedItem()==269&&shovelEnchant1==1)
{
Block.setDestroyTime(2, 1);
Block.setDestroyTime(13, 1);
Block.setDestroyTime(60, 1);
Block.setDestroyTime(78, 1);
Block.setDestroyTime(80, 1);
Block.setDestroyTime(82, 1);
Block.setDestroyTime(12, 1);
Block.setDestroyTime(3, 1);
}
if(getCarriedItem()==273&&shovelEnchant2==1)
{
Block.setDestroyTime(2, 1);
Block.setDestroyTime(13, 1);
Block.setDestroyTime(60, 1);
Block.setDestroyTime(78, 1);
Block.setDestroyTime(80, 1);
Block.setDestroyTime(82, 1);
Block.setDestroyTime(12, 1);
Block.setDestroyTime(3, 1);
}
if(getCarriedItem()==284&&shovelEnchant3==1)
{
Block.setDestroyTime(2, 1);
Block.setDestroyTime(13, 1);
Block.setDestroyTime(60, 1);
Block.setDestroyTime(78, 1);
Block.setDestroyTime(80, 1);
Block.setDestroyTime(82, 1);
Block.setDestroyTime(12, 1);
Block.setDestroyTime(3, 1);
}
if(getCarriedItem()==256&&shovelEnchant4==1)
{
Block.setDestroyTime(2, 1);
Block.setDestroyTime(13, 1);
Block.setDestroyTime(60, 1);
Block.setDestroyTime(78, 1);
Block.setDestroyTime(80, 1);
Block.setDestroyTime(82, 1);
Block.setDestroyTime(12, 1);
Block.setDestroyTime(3, 1);
}
if(getCarriedItem()==277&&shovelEnchant5==1)
{
Block.setDestroyTime(2, 1);
Block.setDestroyTime(13, 1);
Block.setDestroyTime(60, 1);
Block.setDestroyTime(78, 1);
Block.setDestroyTime(80, 1);
Block.setDestroyTime(82, 1);
Block.setDestroyTime(12, 1);
Block.setDestroyTime(3, 1);
}
if(getCarriedItem()==269&&shovelEnchant1==2)
{
Block.setDestroyTime(2, 0.8);
Block.setDestroyTime(13, 0.8);
Block.setDestroyTime(60, 0.8);
Block.setDestroyTime(78, 0.8);
Block.setDestroyTime(80, 0.8);
Block.setDestroyTime(82, 0.8);
Block.setDestroyTime(12, 0.8);
Block.setDestroyTime(3, 0.8);
}
if(getCarriedItem()==273&&shovelEnchant2==2)
{
Block.setDestroyTime(2, 0.8);
Block.setDestroyTime(13, 0.8);
Block.setDestroyTime(60, 0.8);
Block.setDestroyTime(78, 0.8);
Block.setDestroyTime(80, 0.8);
Block.setDestroyTime(82, 0.8);
Block.setDestroyTime(12, 0.8);
Block.setDestroyTime(3, 0.8);
}
if(getCarriedItem()==284&&shovelEnchant3==2)
{
Block.setDestroyTime(2, 0.8);
Block.setDestroyTime(13, 0.8);
Block.setDestroyTime(60, 0.8);
Block.setDestroyTime(78, 0.8);
Block.setDestroyTime(80, 0.8);
Block.setDestroyTime(82, 0.8);
Block.setDestroyTime(12, 0.8);
Block.setDestroyTime(3, 0.8);
}
if(getCarriedItem()==256&&shovelEnchant4==2)
{
Block.setDestroyTime(2, 0.8);
Block.setDestroyTime(13, 0.8);
Block.setDestroyTime(60, 0.8);
Block.setDestroyTime(78, 0.8);
Block.setDestroyTime(80, 0.8);
Block.setDestroyTime(82, 0.8);
Block.setDestroyTime(12, 0.8);
Block.setDestroyTime(3, 0.8);
}
if(getCarriedItem()==277&&shovelEnchant5==2)
{
Block.setDestroyTime(2, 0.8);
Block.setDestroyTime(13, 0.8);
Block.setDestroyTime(60, 0.8);
Block.setDestroyTime(78, 0.8);
Block.setDestroyTime(80, 0.8);
Block.setDestroyTime(82, 0.8);
Block.setDestroyTime(12, 0.8);
Block.setDestroyTime(3, 0.8);
}
if(getCarriedItem()==269&&shovelEnchant1==3)
{
Block.setDestroyTime(2, 0.6);
Block.setDestroyTime(13, 0.6);
Block.setDestroyTime(60, 0.6);
Block.setDestroyTime(78, 0.6);
Block.setDestroyTime(80, 0.6);
Block.setDestroyTime(82, 0.6);
Block.setDestroyTime(12, 0.6);
Block.setDestroyTime(3, 0.6);
}
if(getCarriedItem()==273&&shovelEnchant2==3)
{
Block.setDestroyTime(2, 0.6);
Block.setDestroyTime(13, 0.6);
Block.setDestroyTime(60, 0.6);
Block.setDestroyTime(78, 0.6);
Block.setDestroyTime(80, 0.6);
Block.setDestroyTime(82, 0.6);
Block.setDestroyTime(12, 0.6);
Block.setDestroyTime(3, 0.6);
}
if(getCarriedItem()==284&&shovelEnchant3==3)
{
Block.setDestroyTime(2, 0.6);
Block.setDestroyTime(13, 0.6);
Block.setDestroyTime(60, 0.6);
Block.setDestroyTime(78, 0.6);
Block.setDestroyTime(80, 0.6);
Block.setDestroyTime(82, 0.6);
Block.setDestroyTime(12, 0.6);
Block.setDestroyTime(3, 0.6);
}
if(getCarriedItem()==256&&shovelEnchant4==3)
{
Block.setDestroyTime(2, 0.6);
Block.setDestroyTime(13, 0.6);
Block.setDestroyTime(60, 0.6);
Block.setDestroyTime(78, 0.6);
Block.setDestroyTime(80, 0.6);
Block.setDestroyTime(82, 0.6);
Block.setDestroyTime(12, 0.6);
Block.setDestroyTime(3, 0.6);
}
if(getCarriedItem()==277&&shovelEnchant5==3)
{
Block.setDestroyTime(2, 0.6);
Block.setDestroyTime(13, 0.6);
Block.setDestroyTime(60, 0.6);
Block.setDestroyTime(78, 0.6);
Block.setDestroyTime(80, 0.6);
Block.setDestroyTime(82, 0.6);
Block.setDestroyTime(12, 0.6);
Block.setDestroyTime(3, 0.6);
}
//3
if(getCarriedItem()==270&&pickEnchant1==1)
{
Block.setDestroyTime(1, 1);
Block.setDestroyTime(16, 1);
Block.setDestroyTime(20, 1);
Block.setDestroyTime(21, 1);
Block.setDestroyTime(56, 1);
Block.setDestroyTime(62, 1);
Block.setDestroyTime(74, 1);
Block.setDestroyTime(79, 1);
Block.setDestroyTime(89, 1);
Block.setDestroyTime(102, 1);
Block.setDestroyTime(246, 1);
Block.setDestroyTime(14, 1);
Block.setDestroyTime(15, 1);
Block.setDestroyTime(4, 1);
}
if(getCarriedItem()==274&&pickEnchant2==1)
{
Block.setDestroyTime(1, 1);
Block.setDestroyTime(16, 1);
Block.setDestroyTime(20, 1);
Block.setDestroyTime(21, 1);
Block.setDestroyTime(56, 1);
Block.setDestroyTime(62, 1);
Block.setDestroyTime(74, 1);
Block.setDestroyTime(79, 1);
Block.setDestroyTime(89, 1);
Block.setDestroyTime(102, 1);
Block.setDestroyTime(246, 1);
Block.setDestroyTime(14, 1);
Block.setDestroyTime(15, 1);
Block.setDestroyTime(4, 1);
}
if(getCarriedItem()==285&&pickEnchant3==1)
{
Block.setDestroyTime(1, 1);
Block.setDestroyTime(16, 1);
Block.setDestroyTime(20, 1);
Block.setDestroyTime(21, 1);
Block.setDestroyTime(56, 1);
Block.setDestroyTime(62, 1);
Block.setDestroyTime(74, 1);
Block.setDestroyTime(79, 1);
Block.setDestroyTime(89, 1);
Block.setDestroyTime(102, 1);
Block.setDestroyTime(246, 1);
Block.setDestroyTime(14, 1);
Block.setDestroyTime(15, 1);
Block.setDestroyTime(4, 1);
}
if(getCarriedItem()==257&&pickEnchant4==1)
{
Block.setDestroyTime(1, 1);
Block.setDestroyTime(16, 1);
Block.setDestroyTime(20, 1);
Block.setDestroyTime(21, 1);
Block.setDestroyTime(56, 1);
Block.setDestroyTime(62, 1);
Block.setDestroyTime(74, 1);
Block.setDestroyTime(79, 1);
Block.setDestroyTime(89, 1);
Block.setDestroyTime(102, 1);
Block.setDestroyTime(246, 1);
Block.setDestroyTime(14, 1);
Block.setDestroyTime(15, 1);
Block.setDestroyTime(4, 1);
}
if(getCarriedItem()==278&&pickEnchant5==1)
{
Block.setDestroyTime(1, 1);
Block.setDestroyTime(16, 1);
Block.setDestroyTime(20, 1);
Block.setDestroyTime(21, 1);
Block.setDestroyTime(56, 1);
Block.setDestroyTime(62, 1);
Block.setDestroyTime(74, 1);
Block.setDestroyTime(79, 1);
Block.setDestroyTime(89, 1);
Block.setDestroyTime(102, 1);
Block.setDestroyTime(246, 1);
Block.setDestroyTime(14, 1);
Block.setDestroyTime(15, 1);
Block.setDestroyTime(4, 1);
}
if(getCarriedItem()==270&&pickEnchant1==2)
{
Block.setDestroyTime(1, 0.8);
Block.setDestroyTime(16, 0.8);
Block.setDestroyTime(20, 0.8);
Block.setDestroyTime(21, 0.8);
Block.setDestroyTime(56, 0.8);
Block.setDestroyTime(62, 0.8);
Block.setDestroyTime(74, 0.8);
Block.setDestroyTime(79, 0.8);
Block.setDestroyTime(89, 0.8);
Block.setDestroyTime(102, 0.8);
Block.setDestroyTime(246, 0.8);
Block.setDestroyTime(14, 0.8);
Block.setDestroyTime(15, 0.8);
Block.setDestroyTime(4, 0.8);
}
if(getCarriedItem()==274&&pickEnchant2==2)
{
Block.setDestroyTime(1, 0.8);
Block.setDestroyTime(16, 0.8);
Block.setDestroyTime(20, 0.8);
Block.setDestroyTime(21, 0.8);
Block.setDestroyTime(56, 0.8);
Block.setDestroyTime(62, 0.8);
Block.setDestroyTime(74, 0.8);
Block.setDestroyTime(79, 0.8);
Block.setDestroyTime(89, 0.8);
Block.setDestroyTime(102, 0.8);
Block.setDestroyTime(246, 0.8);
Block.setDestroyTime(14, 0.8);
Block.setDestroyTime(15, 0.8);
Block.setDestroyTime(4, 0.8);
}
if(getCarriedItem()==285&&pickEnchant3==2)
{
Block.setDestroyTime(1, 0.8);
Block.setDestroyTime(16, 0.8);
Block.setDestroyTime(20, 0.8);
Block.setDestroyTime(21, 0.8);
Block.setDestroyTime(56, 0.8);
Block.setDestroyTime(62, 0.8);
Block.setDestroyTime(74, 0.8);
Block.setDestroyTime(79, 0.8);
Block.setDestroyTime(89, 0.8);
Block.setDestroyTime(102, 0.8);
Block.setDestroyTime(246, 0.8);
Block.setDestroyTime(14, 0.8);
Block.setDestroyTime(15, 0.8);
Block.setDestroyTime(4, 0.8);
}
if(getCarriedItem()==257&&pickEnchant4==2)
{
Block.setDestroyTime(1, 0.8);
Block.setDestroyTime(16, 0.8);
Block.setDestroyTime(20, 0.8);
Block.setDestroyTime(21, 0.8);
Block.setDestroyTime(56, 0.8);
Block.setDestroyTime(62, 0.8);
Block.setDestroyTime(74, 0.8);
Block.setDestroyTime(79, 0.8);
Block.setDestroyTime(89, 0.8);
Block.setDestroyTime(102, 0.8);
Block.setDestroyTime(246, 0.8);
Block.setDestroyTime(14, 0.8);
Block.setDestroyTime(15, 0.8);
Block.setDestroyTime(4, 0.8);
}
if(getCarriedItem()==278&&pickEnchant5==2)
{
Block.setDestroyTime(1, 0.8);
Block.setDestroyTime(16, 0.8);
Block.setDestroyTime(20, 0.8);
Block.setDestroyTime(21, 0.8);
Block.setDestroyTime(56, 0.8);
Block.setDestroyTime(62, 0.8);
Block.setDestroyTime(74, 0.8);
Block.setDestroyTime(79, 0.8);
Block.setDestroyTime(89, 0.8);
Block.setDestroyTime(102, 0.8);
Block.setDestroyTime(246, 0.8);
Block.setDestroyTime(14, 0.8);
Block.setDestroyTime(15, 0.8);
Block.setDestroyTime(4, 0.8);
}
if(getCarriedItem()==270&&pickEnchant1==3)
{
Block.setDestroyTime(1, 0.6);
Block.setDestroyTime(16, 0.6);
Block.setDestroyTime(20, 0.6);
Block.setDestroyTime(21, 0.6);
Block.setDestroyTime(56, 0.6);
Block.setDestroyTime(62, 0.6);
Block.setDestroyTime(74, 0.6);
Block.setDestroyTime(79, 0.6);
Block.setDestroyTime(89, 0.6);
Block.setDestroyTime(102, 0.6);
Block.setDestroyTime(246, 0.6);
Block.setDestroyTime(14, 0.6);
Block.setDestroyTime(15, 0.6);
Block.setDestroyTime(4, 0.6);
}
if(getCarriedItem()==274&&pickEnchant2==3)
{
Block.setDestroyTime(1, 0.6);
Block.setDestroyTime(16, 0.6);
Block.setDestroyTime(20, 0.6);
Block.setDestroyTime(21, 0.6);
Block.setDestroyTime(56, 0.6);
Block.setDestroyTime(62, 0.6);
Block.setDestroyTime(74, 0.6);
Block.setDestroyTime(79, 0.6);
Block.setDestroyTime(89, 0.6);
Block.setDestroyTime(102, 0.6);
Block.setDestroyTime(246, 0.6);
Block.setDestroyTime(14, 0.6);
Block.setDestroyTime(15, 0.6);
Block.setDestroyTime(4, 0.6);
}
if(getCarriedItem()==285&&pickEnchant3==3)
{
Block.setDestroyTime(1, 0.6);
Block.setDestroyTime(16, 0.6);
Block.setDestroyTime(20, 0.6);
Block.setDestroyTime(21, 0.6);
Block.setDestroyTime(56, 0.6);
Block.setDestroyTime(62, 0.6);
Block.setDestroyTime(74, 0.6);
Block.setDestroyTime(79, 0.6);
Block.setDestroyTime(89, 0.6);
Block.setDestroyTime(102, 0.6);
Block.setDestroyTime(246, 0.6);
Block.setDestroyTime(14, 0.6);
Block.setDestroyTime(15, 0.6);
Block.setDestroyTime(4, 0.6);
}
if(getCarriedItem()==257&&pickEnchant4==3)
{
Block.setDestroyTime(1, 0.6);
Block.setDestroyTime(16, 0.6);
Block.setDestroyTime(20, 0.6);
Block.setDestroyTime(21, 0.6);
Block.setDestroyTime(56, 0.6);
Block.setDestroyTime(62, 0.6);
Block.setDestroyTime(74, 0.6);
Block.setDestroyTime(79, 0.6);
Block.setDestroyTime(89, 0.6);
Block.setDestroyTime(102, 0.6);
Block.setDestroyTime(246, 0.6);
Block.setDestroyTime(14, 0.6);
Block.setDestroyTime(15, 0.6);
Block.setDestroyTime(4, 0.6);
}
if(getCarriedItem()==278&&pickEnchant5==3)
{
Block.setDestroyTime(1, 0.6);
Block.setDestroyTime(16, 0.6);
Block.setDestroyTime(20, 0.6);
Block.setDestroyTime(21, 0.6);
Block.setDestroyTime(56, 0.6);
Block.setDestroyTime(62, 0.6);
Block.setDestroyTime(74, 0.6);
Block.setDestroyTime(79, 0.6);
Block.setDestroyTime(89, 0.6);
Block.setDestroyTime(102, 0.6);
Block.setDestroyTime(246, 0.6);
Block.setDestroyTime(14, 0.6);
Block.setDestroyTime(15, 0.6);
Block.setDestroyTime(4, 0.6);
}
//4
x = getPlayerX(); 
y = getPlayerY(); 
z = getPlayerZ(); 
{
if (bootsEnchant1 == 3)
{
if(Player.getArmorSlot(3)==301)
{
Player.setHealth(300)
x=1
}
}
if (bootsEnchant2 == 3)
{
if(Player.getArmorSlot(3)==305)
{
Player.setHealth(300)
x=1
}
}
if (bootsEnchant3 == 3)
{
if(Player.getArmorSlot(3)==309)
{
Player.setHealth(300)
x=1
}
}
if (bootsEnchant4 == 3)
{
if(Player.getArmorSlot(3)==313)
{
Player.setHealth(300)
x=1
}
}
if (bootsEnchant5 == 3)
{
if(Player.getArmorSlot(3)==317)
{
Player.setHealth(300)
x=1
}
}
if (helmetEnchant1 == 3)
{
if(Player.getArmorSlot(0)==310)
{
Player.setHealth(300)
x=1
}
}
if (helmetEnchant2 == 3)
{
if(Player.getArmorSlot(0)==298)
{
Player.setHealth(300)
x=1
}
}
if (helmetEnchant3 == 3)
{
if(Player.getArmorSlot(0)==314)
{
Player.setHealth(300)
x=1
}
}
if (helmetEnchant4 == 3)
{
if(Player.getArmorSlot(0)==302)
{
Player.setHealth(300)
x=1
}
}
if (helmetEnchant5 == 3)
{
if(Player.getArmorSlot(0)==306)
{
Player.setHealth(300)
x=1
}
}
if (legginsEnchant1 == 3)
{
if(Player.getArmorSlot(2)==304)
{
Player.setHealth(300)
x=1
}
}
if (legginsEnchant2 == 3)
{
if(Player.getArmorSlot(2)==308)
{
Player.setHealth(300)
x=1
}
}
if (legginsEnchant3 == 3)
{
if(Player.getArmorSlot(2)==312)
{
Player.setHealth(300)
x=1
}
}
if (legginsEnchant4 == 3)
{
if(Player.getArmorSlot(2)==316)
{
Player.setHealth(300)
x=1
}
}
if (legginsEnchant5 == 3)
{
if(Player.getArmorSlot(2)==300)
{
Player.setHealth(300)
x=1
}
}
if (chetsplateEnchant1 == 3)
{
if(Player.getArmorSlot(1)==307)
{
Player.setHealth(300)
x=1
}
}
if (chetsplateEnchant2 == 3)
{
if(Player.getArmorSlot(1)==311)
{
Player.setHealth(300)
x=1
}
}
if (chetsplateEnchant3 == 3)
{
if(Player.getArmorSlot(1)==315)
{
Player.setHealth(300)
x=1
}
}
if (chetsplateEnchant4 == 3)
{
if(Player.getArmorSlot(1)==303)
{
Player.setHealth(300)
x=1
}
}
if (chetsplateEnchant5 == 3)
{
if(Player.getArmorSlot(1)==299)
{
Player.setHealth(300)
x=1
}
}

if (bootsEnchant1 == 2)
{
if(Player.getArmorSlot(3)==301)
{
Player.setHealth(300)
}
}
if (bootsEnchant2 == 2)
{
if(Player.getArmorSlot(3)==305)
{
Player.setHealth(300)
}
}
if (bootsEnchant3 == 2)
{
if(Player.getArmorSlot(3)==309)
{
Player.setHealth(300)
}
}
if (bootsEnchant4 == 2)
{
if(Player.getArmorSlot(3)==313)
{
Player.setHealth(300)
}
}
if (bootsEnchant5 == 2)
{
if(Player.getArmorSlot(3)==317)
{
Player.setHealth(300)
}
}
if (helmetEnchant1 == 2)
{
if(Player.getArmorSlot(0)==310)
{
Player.setHealth(300)
}
}
if (helmetEnchant2 == 2)
{
if(Player.getArmorSlot(0)==298)
{
Player.setHealth(300)
}
}
if (helmetEnchant3 == 2)
{
if(Player.getArmorSlot(0)==314)
{
Player.setHealth(300)
}
}
if (helmetEnchant4 == 2)
{
if(Player.getArmorSlot(0)==302)
{
Player.setHealth(300)
}
}
if (helmetEnchant5 == 2)
{
if(Player.getArmorSlot(0)==306)
{
Player.setHealth(300)
}
}
if (legginsEnchant1 == 2)
{
if(Player.getArmorSlot(2)==304)
{
Player.setHealth(300)
}
}
if (legginsEnchant2 == 2)
{
if(Player.getArmorSlot(2)==308)
{
Player.setHealth(300)
}
}
if (legginsEnchant3 == 2)
{
if(Player.getArmorSlot(2)==312)
{
Player.setHealth(300)
}
}
if (legginsEnchant4 == 2)
{
if(Player.getArmorSlot(2)==316)
{
Player.setHealth(300)
}
}
if (legginsEnchant5 == 2)
{
if(Player.getArmorSlot(2)==300)
{
Player.setHealth(300)
}
}
if (chetsplateEnchant1 == 2)
{
if(Player.getArmorSlot(1)==307)
{
Player.setHealth(300)
}
}
if (chetsplateEnchant2 == 2)
{
if(Player.getArmorSlot(1)==311)
{
Player.setHealth(300)
}
}
if (chetsplateEnchant3 == 2)
{
if(Player.getArmorSlot(1)==315)
{
Player.setHealth(300)
}
}
if (chetsplateEnchant4 == 2)
{
if(Player.getArmorSlot(1)==303)
{
Player.setHealth(300)
}
}
if (chetsplateEnchant5 == 2)
{
if(Player.getArmorSlot(1)==299)
{
Player.setHealth(300)
}
}

if (bootsEnchant1 == 1)
{
if(Player.getArmorSlot(3)==301)
{
x=1
}
}
if (bootsEnchant2 == 1)
{
if(Player.getArmorSlot(3)==305)
{
x=1
}
}
if (bootsEnchant3 == 1)
{
if(Player.getArmorSlot(3)==309)
{
x=1
}
}
if (bootsEnchant4 == 1)
{
if(Player.getArmorSlot(3)==313)
{
x=1
}
}
if (bootsEnchant5 == 1)
{
if(Player.getArmorSlot(3)==317)
{
x=1
}
}
if (helmetEnchant1 == 1)
{
if(Player.getArmorSlot(0)==310)
{
x=1
}
}
if (helmetEnchant2 == 1)
{
if(Player.getArmorSlot(0)==298)
{
x=1
}
}
if (helmetEnchant3 == 1)
{
if(Player.getArmorSlot(0)==314)
{
x=1
}
}
if (helmetEnchant4 == 1)
{
if(Player.getArmorSlot(0)==302)
{
x=1
}
}
if (helmetEnchant5 == 1)
{
if(Player.getArmorSlot(0)==306)
{
x=1
}
}
if (legginsEnchant1 == 1)
{
if(Player.getArmorSlot(2)==304)
{
x=1
}
}
if (legginsEnchant2 == 1)
{
if(Player.getArmorSlot(2)==308)
{
x=1
}
}
if (legginsEnchant3 == 1)
{
if(Player.getArmorSlot(2)==312)
{
x=1
}
}
if (legginsEnchant4 == 1)
{
if(Player.getArmorSlot(2)==316)
{
x=1
}
}
if (legginsEnchant5 == 1)
{
if(Player.getArmorSlot(2)==300)
{
x=1
}
}
if (chetsplateEnchant1 == 1)
{
if(Player.getArmorSlot(1)==307)
{
x=1
}
}
if (chetsplateEnchant2 == 1)
{
if(Player.getArmorSlot(1)==311)
{
x=1
}
}
if (chetsplateEnchant3 == 1)
{
if(Player.getArmorSlot(1)==315)
{
x=1
}
}
if (chetsplateEnchant4 == 1)
{
if(Player.getArmorSlot(1)==303)
{
x=1
}
}
if (chetsplateEnchant5 == 1)
{
if(Player.getArmorSlot(1)==299)
{
x=1
}
}
}
if(bowEnchant==1)
{
if(getTile(Entity.getX(arrow), Entity.getY(arrow)-1,Entity.getZ(arrow))!=0||getTile(Entity.getX(arrow), Entity.getY(arrow)+1,Entity.getZ(arrow))!=0||getTile(Entity.getX(arrow)+1, Entity.getY(arrow),Entity.getZ(arrow))!=0||getTile(Entity.getX(arrow)-1, Entity.getY(arrow),Entity.getZ(arrow))!=0||getTile(Entity.getX(arrow), Entity.getY(arrow),Entity.getZ(arrow)+1)!=0||getTile(Entity.getX(arrow), Entity.getY(arrow),Entity.getZ(arrow)-1)!=0)
{
Entity.remove(arrow);
}
}
}

function procCmd(cmd){
if(cmd == "xp 10")
{
lvl=lvl+10
clientMessage(ChatColor.GREEN + "XP given")
}
if(cmd == "xp 20")
{
lvl=lvl+20
clientMessage(ChatColor.GREEN + "XP given")
}
if(cmd == "xp 30")
{
lvl=lvl+30
clientMessage(ChatColor.GREEN + "XP given")
}
if(cmd == "xp 100")
{
lvl=lvl+100
clientMessage(ChatColor.GREEN + "XP given")
}
if(cmd == "xp 500")
{
lvl=lvl+500
clientMessage(ChatColor.GREEN + "XP given")
}
if(cmd == "help")
{
clientMessage(ChatColor.RED + "Comands:")
clientMessage(ChatColor.BLUE + "1)/xp 10")
clientMessage(ChatColor.BLUE + "1)/xp 20")
clientMessage(ChatColor.BLUE + "1)/xp 30")
clientMessage(ChatColor.BLUE + "1)/xp 100")
clientMessage(ChatColor.BLUE + "1)/xp 500")
}
}

function deathHook(attacker, victim)
{
if(Entity.getEntityTypeId(attacker)==10||11||12||13||14||15||32||33||34||35||36||37||38||39)
{
c=1;
}
if(bar>=7)
{
barvisibl=1;
bar=1;
lvl++;
}
if(Entity.getEntityTypeId(victim)==36||37||38||39)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 462, 1,0)
}
}

var onFire = 0;
var fire=0;

function entityAddedHook(entity)
{
if(Entity.getEntityTypeId(entity)==80)
{
arrow=entity;
onFire=1;
}
}

function entityRemovedHook(entity)
{
var underArrow=getTile(Entity.getX(entity), Entity.getY(entity), Entity.getZ(entity));
var arrowCoords=getTile(Entity.getX(entity),Entity.getY(entity),Entity.getZ(entity));
var arrowX=Entity.getX(entity);
var arrowY=Entity.getY(entity);
var arrowZ=Entity.getZ(entity);
if(Entity.getEntityTypeId(entity)==80)
{
if(bowEnchant==1)
{
setTile (Entity.getX(entity), Entity.getY(entity),Entity.getZ(entity), 51);
onFire=0;
}
}
}

function attackHook(attacker,victim)
{
if(onFire==1&&bowEnchant==1)
{ 
Entity.setFireTicks(victim, 60);
onFire=1;
}
var ourItem = getCarriedItem();
if(swordEwood == 1 && ourItem==268)
{
Entity.setFireTicks(victim,10);
}
var ourItem = getCarriedItem();
if(swordEstone == 1 && ourItem==272)
{
Entity.setFireTicks(victim,10)
}
var ourItem = getCarriedItem();
if(swordEiron == 1 && ourItem==283)
{
Entity.setFireTicks(victim,10)
}
var ourItem = getCarriedItem();
if(swordEgold == 1 && ourItem==267)
{
Entity.setFireTicks(victim,10)
}
var ourItem = getCarriedItem();
if(swordEdiamond == 1 && ourItem==276)
{
Entity.setFireTicks(victim,10)
}
var ourItem = getCarriedItem();
if(swordEwood == 2 && ourItem==268)
{
Entity.setFireTicks(victim,10)
if(getCarriedItem() == 268 && getYaw() < 0)
  {
		var temp = getYaw()+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 268  && getYaw() > 0 && getYaw() < 360)
	{
		var temp = getYaw()+90;
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 268 && getYaw() >= 360)
	{
		var temp = getYaw()+90;
		for(i=0; temp>=360; i++)
		{
			temp -= 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
}
if(swordEstone == 2 && ourItem==272)
{
Entity.setFireTicks(victim,10)
if(getCarriedItem() == 272 && getYaw() < 0)
  {
		var temp = getYaw()+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 272  && getYaw() > 0 && getYaw() < 360)
	{
		var temp = getYaw()+90;
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 272 && getYaw() >= 360)
	{
		var temp = getYaw()+90;
		for(i=0; temp>=360; i++)
		{
			temp -= 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
}
var ourItem = getCarriedItem();
if(swordEgold == 2 && ourItem==283)
{
Entity.setFireTicks(victim,10)
if(getCarriedItem() == 283 && getYaw() < 0)
  {
		var temp = getYaw()+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 283  && getYaw() > 0 && getYaw() < 360)
	{
		var temp = getYaw()+90;
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 283 && getYaw() >= 360)
	{
		var temp = getYaw()+90;
		for(i=0; temp>=360; i++)
		{
			temp -= 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
}
var ourItem = getCarriedItem();
if(swordEiron == 2 && ourItem==267)
{
Entity.setFireTicks(victim,10)
if(getCarriedItem() == 267 && getYaw() < 0)
  {
		var temp = getYaw()+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 267  && getYaw() > 0 && getYaw() < 360)
	{
		var temp = getYaw()+90;
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 267 && getYaw() >= 360)
	{
		var temp = getYaw()+90;
		for(i=0; temp>=360; i++)
		{
			temp -= 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
}
var ourItem = getCarriedItem();
if(swordEdiamond == 2 && ourItem==276)
{
Entity.setFireTicks(victim,10)
if(getCarriedItem() == 276 && getYaw() < 0)
  {
		var temp = getYaw()+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 276  && getYaw() > 0 && getYaw() < 360)
	{
		var temp = getYaw()+90;
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
	else if(getCarriedItem() == 276 && getYaw() >= 360)
	{
		var temp = getYaw()+90;
		for(i=0; temp>=360; i++)
		{
			temp -= 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*10);
		setVelY(victim, 1);
		setVelZ(victim, z*10);
	}
}
var ourItem = getCarriedItem();
if(swordEwood == 3 && ourItem==268)
{
Entity.setHealth(victim, 0)
}
var ourItem = getCarriedItem();
if(swordEstone == 3 && ourItem==272)
{
Entity.setHealth(victim, 0)
}
var ourItem = getCarriedItem();
if(swordEiron == 3 && ourItem==283)
{
Entity.setHealth(victim, 0)
}
var ourItem = getCarriedItem();
if(swordEgold == 3 && ourItem==267)
{
Entity.setHealth(victim, 0)
}
var ourItem = getCarriedItem();
if(swordEdiamond == 3 && ourItem==276)
{
Entity.setHealth(victim, 0)
}
}

function leaveGame()
{var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); ctx.runOnUiThread(new java.lang.Runnable({ run: function(){ if(GUIBar != false){ GUIBar.dismiss();GUIBar = false;}}})); }