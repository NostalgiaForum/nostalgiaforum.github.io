ModPE.setFoodItem (502, 92, 7, 1, "fish_cod_raw");  
ModPE.setItem (504, "fishing_rod_uncast", 6, "Fishing");

ModPE.addCraftRecipe (504, 1, 1, [280, 1, 280, 1, 280, 1, 287, 1, 287, 1]);

function useItem (x, y, z, itemId, blockId)
{
if (itemId==504&&blockId==79)
{
addItemInventory (502, 1)
}
}