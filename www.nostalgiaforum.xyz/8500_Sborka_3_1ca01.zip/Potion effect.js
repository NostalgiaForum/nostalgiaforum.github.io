
var f=468

function attackHook(attacker, victim){
if( Level.getGameMode() == 0){
if (getCarriedItem()==f){
toolUse(3999,468)
Entity.setHealth(victim, 3);{
if(getCarriedItem()==f)
Entity.setFireTicks(victim,8);{
	if(getCarriedItem() ==  f && getYaw(Player.getEntity) < 0)
	{
 var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
	}
	else if(getCarriedItem() == f && getYaw(Player.getEntity) > 0 && getYaw(Player.getEntity) < 360)
	{
		var temp = getYaw(Player.getEntity)+90;
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
	}
	else if(getCarriedItem() == f && getYaw(Player.getEntity) >= 360)
	{
		var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp>=360; i++)
		{
			temp -= 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
	}
if(getCarriedItem() == f && getYaw(Player.getEntity) < 0)
	{
		var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
}
}
}
}
}
else if( Level.getGameMode() !== 0){
if (getCarriedItem()==f){
Entity.setHealth(victim, 3);{
if(getCarriedItem()==f)
Entity.setFireTicks(victim,8);{
	if(getCarriedItem() ==  f && getYaw(Player.getEntity) < 0)
	{
 var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
	}
	else if(getCarriedItem() == f && getYaw(Player.getEntity) > 0 && getYaw(Player.getEntity) < 360)
	{
		var temp = getYaw(Player.getEntity)+90;
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
	}
	else if(getCarriedItem() == f && getYaw(Player.getEntity) >= 360)
	{
		var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp>=360; i++)
		{
			temp -= 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
	}
if(getCarriedItem() == f && getYaw(Player.getEntity) < 0)
	{
		var temp = getYaw(Player.getEntity)+90;
		for(i=0; temp<0; i++)
		{
			temp += 360;
		}
		x = Math.cos(temp*0.0174532925);
		z = Math.sin(temp*0.0174532925);
		 setVelX(victim, x*4);
		setVelY(victim, 1.3);
		setVelZ(victim, z*4);
	}
}
}
}
}
}

function toolUse(maxDamage,id)
{
var pcid=Player.getCarriedItemData();
if(pcid!==maxDamage)
{
Entity.setCarriedItem(getPlayerEnt(),id,1,pcid+1);
}
else if(pcid==maxDamage) 
{
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
addItemInventory(id,-1);
}
}

var tPX
var tPY
var tPZ
var cannonVelX=0
var cannonVelY=0
var cannonVelZ=0
var itemList = new Array ()
var itemX = new Array ()
var itemY = new Array ()
var itemZ = new Array ()
var itemVX = new Array ()
var itemVY = new Array ()
var itemVZ = new Array ()
var itemThrown = false
var iT2 = false
var count = 0
var cntdwn = 100






function newLevel()
{
  cntdwn = 10
}
function modTick ()
{
  if (cntdwn > 0)
  {
    cntdwn--
    return "";
  }
  count = 0
  //clientMessage (parseInt(itemX.length))
  if (itemX.length > 0)
  {   
  for (var i = 0; i < itemX.length; i++)
  {
    Entity.remove (itemList[i])
    iT2 = true
    Level.dropItem(itemX[i],itemY[i],itemZ[i],0,51,0,0)
    itemX[i] = itemX[i] + itemVX[i]
    itemY[i] = itemY[i] + itemVY[i]
    itemZ[i] = itemZ[i] + itemVZ[i]
    if (Level.getTile (itemX[i],itemY[i],itemZ[i]) !== 0)
    {
    Level.explode (itemX[i],itemY[i],itemZ[i],10)
     
      x = itemX[i]
      y = itemY[i]
      z = itemZ[i]
      x -= 2
      y -= 2
      z -= 2
      for (X = x; X <= x+4; X++)
      {
      for (Y = y; Y <= y+4; Y++)
      {
      for (Z = z; Z <= z+4; Z++)
      {
        if (Math.random() > 0.8 && Level.getTile (X,Y,Z) == 0)
          Level.setTile (X,Y,Z,0)
      }
      }
      }
      Entity.remove (itemList[i])
      itemList.splice (i,1)
      i--
      itemX.splice (i,1)
      itemY.splice (i,1)
      itemZ.splice (i,1)
      itemVX.splice (i,1)
      itemVY.splice (i,1)
      itemVZ.splice (i,1)
      
    }
  }
  }
}
function useItem (x,y,z,i,b,s)
{
  if (i !== 508)
    return "";
   addItemInventory(508,-1);
  	cannonPlayerYaw = Entity.getYaw(Player.getEntity());
	cannonPlayerPitch = Entity.getPitch(Player.getEntity());
	cannonVelY = Math.sin((cannonPlayerPitch - 180) / 180 * Math.PI);
	cannonVelX = Math.sin(cannonPlayerYaw / 180 * Math.PI) * Math.cos((cannonPlayerPitch - 180) / 180 * Math.PI);
	cannonVelZ = -1 * Math.cos(cannonPlayerYaw / 180 * Math.PI) * Math.cos((cannonPlayerPitch - 180) / 180 * Math.PI);
	tPX = Player.getX()
	tPY = Player.getY()
	tPZ = Player.getZ()
  itemX.push (tPX)
  itemY.push (tPY)
  itemZ.push (tPZ)
  itemVX.push (cannonVelX)
  itemVY.push (cannonVelY)
  itemVZ.push (cannonVelZ)
  itemThrown = true
  }  
function entityAddedHook(ent)
{
  if (itemThrown)
  {
    itemList.push (ent)
    itemThrown = false
    //clientMessage ("add")
  }
  if (iT2)
  {
    iT2 = false
    itemList[count] = ent
    count++
  }
}

