
var gamemod = Level.getGameMode();


//8dlsls
function deathHook (attacker, victim) 
{
if (Entity.getEntityTypeId(victim) == 35) //паук
{
preventDefault();
var spideggr= Math.floor((Math.random()*20)+1);//задаём числа от 1 до 10
 if( spideggr ==1|| spideggr ==2|| spideggr ==3|| spideggr ==4|| spideggr ==5 )//
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 375, 1, 0);
}
else if( spideggr==7)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 2, 375, 1, 0);
}
}
}


function useItem(x,y,z,itemId,blockId,side)
{
if(itemId== 509){
Player.setHealth(100);
addItemInventory(509, -1);
addItemInventory(506,+1);
}
else if(itemId== 417){
Player.setHealth(-100);
addItemInventory(417, -1);
addItemInventory(506,+1);
}
}


function attackHook(attacker, victim)
{
if( Level.getGameMode() == 0){
if (getCarriedItem()==378)
{
toolUse(5000,378)
setVelY(victim,1);
Entity.setHealth(victim, 1);
}
}
if( Level.getGameMode() !== 0){
if (getCarriedItem()==378)
{
setVelY(victim,1);
Entity.setHealth(victim, 1);
}
}
}

function toolUse(maxDamage,id)
{
var pcid=Player.getCarriedItemData();
if(pcid!==maxDamage)
{
Entity.setCarriedItem(getPlayerEnt(),id,1,pcid+1);
}
else if(pcid==maxDamage) 
{
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
addItemInventory(id,-1);
}
}
