var workTime = 6


function deathHook (attacker, victim) 
{
if (Entity.getEntityTypeId(victim) == 38) //паук
{
preventDefault();
var ender= Math.floor((Math.random()*20)+1);//задаём числа от 1 до 10
 if( ender ==1)//
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 368, 1, 0);
}
}
}



function attackHook(attacker, victim)
{
if( Level.getGameMode() == 0){
if (getCarriedItem()==490)
{
preventDefault();  
Entity.setHealth(victim, 5);
Entity.setFireTicks(victim,8);
setVelY(victim,3.3);
toolUse(1003,490)
}
}
else if( Level.getGameMode() !== 0){
if (getCarriedItem()==490)
{
preventDefault();  
Entity.setHealth(victim, 5);
Entity.setFireTicks(victim,8);
setVelY(victim,3.3);
}
}
}


function toolUse(maxDamage,id)
{
var pcid=Player.getCarriedItemData();
if(pcid!==maxDamage)
{
Entity.setCarriedItem(getPlayerEnt(),id,1,pcid+1);
}
else if(pcid==maxDamage) 
{
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
addItemInventory(id,-1);
}
}

var tPX
var tPY
var tPZ
var cannonVelX=0
var cannonVelY=0
var cannonVelZ=0
var itemList = new Array ()
var itemX = new Array ()
var itemY = new Array ()
var itemZ = new Array ()
var itemVX = new Array ()
var itemVY = new Array ()
var itemVZ = new Array ()
var itemThrown = false
var iT2 = false
var count = 0
var cntdwn = 100






function newLevel()
{
  cntdwn = 10
}
function modTick ()
{
  if (cntdwn > 0)
  {
    cntdwn--
    return "";
  }
  count = 0
  //clientMessage (parseInt(itemX.length))
  if (itemX.length > 0)
  {   
  for (var i = 0; i < itemX.length; i++)
  {
    Entity.remove (itemList[i])
    iT2 = true
    Level.dropItem(itemX[i],itemY[i],itemZ[i],0,51,0,0)
    itemX[i] = itemX[i] + itemVX[i]
    itemY[i] = itemY[i] + itemVY[i]
    itemZ[i] = itemZ[i] + itemVZ[i]
    if (Level.getTile (itemX[i],itemY[i],itemZ[i]) !== 0)
    {
    Level.explode (itemX[i],itemY[i],itemZ[i],15)
     
      x = itemX[i]
      y = itemY[i]
      z = itemZ[i]
      x -= 2
      y -= 2
      z -= 2
      for (X = x; X <= x+4; X++)
      {
      for (Y = y; Y <= y+4; Y++)
      {
      for (Z = z; Z <= z+4; Z++)
      {
        if (Math.random() > 0.8 && Level.getTile (X,Y,Z) == 0)
          Level.setTile (X,Y,Z,0)
      }
      }
      }
      Entity.remove (itemList[i])
      itemList.splice (i,1)
      i--
      itemX.splice (i,1)
      itemY.splice (i,1)
      itemZ.splice (i,1)
      itemVX.splice (i,1)
      itemVY.splice (i,1)
      itemVZ.splice (i,1)
      
    }
  }
  }
}
function useItem (x,y,z,i,b,s)
{
  if (i !== 416)
    return "";
   addItemInventory(416,-1);
  	cannonPlayerYaw = Entity.getYaw(Player.getEntity());
	cannonPlayerPitch = Entity.getPitch(Player.getEntity());
	cannonVelY = Math.sin((cannonPlayerPitch - 180) / 180 * Math.PI);
	cannonVelX = Math.sin(cannonPlayerYaw / 180 * Math.PI) * Math.cos((cannonPlayerPitch - 180) / 180 * Math.PI);
	cannonVelZ = -1 * Math.cos(cannonPlayerYaw / 180 * Math.PI) * Math.cos((cannonPlayerPitch - 180) / 180 * Math.PI);
	tPX = Player.getX()
	tPY = Player.getY()
	tPZ = Player.getZ()
  itemX.push (tPX)
  itemY.push (tPY)
  itemZ.push (tPZ)
  itemVX.push (cannonVelX)
  itemVY.push (cannonVelY)
  itemVZ.push (cannonVelZ)
  itemThrown = true
  }  
function entityAddedHook(ent)
{
  if (itemThrown)
  {
    itemList.push (ent)
    itemThrown = false
    //clientMessage ("add")
  }
  if (iT2)
  {
    iT2 = false
    itemList[count] = ent
    count++
  }
}




