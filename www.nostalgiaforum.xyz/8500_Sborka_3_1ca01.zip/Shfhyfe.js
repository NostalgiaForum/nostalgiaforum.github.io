
var emcost;
var Applegolden = 1;
var Goldencarrot = 1;
var Melonspeaked = 1; var Active = 1;
var as = 325;
var Rottenflesh = 1;
var Spidereye = 1;
var Spiderfermentedeye = 1;
var Potatopoisonous = 1;
var Powder = 1;
var Firedust = 1;
var Flint = 1;



function deathHook (attacker, victim) 
{
if (Entity.getEntityTypeId(victim) == 36) //паук
{
preventDefault();
var spem= Math.floor((Math.random()*30)+1);//задаём числа от 1 до 10
 if( spem ==1|| spem ==2|| spem ==3|| spem ==4|| spem ==5 )//
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 371, 1, 0);
}
else if( spem ==7)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 2, 371, 1, 0);
}
else if( spem=29)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 369, 1, 0);
}
}
}

function useItem(x,y,z,itemId,blockId,side)
{
if(itemId==370)
{
addItemInventory(370,-1);
setTile(x,y+1,z,117)
setTile(x,y,z,49)
}
if(itemId==423)
{
addItemInventory(423,-1);
setTile(x,y+1,z,194)
}
if(itemId== as &&blockId== 194)
{
setTile(x,y,z,195)
setTile(x,y+1,z,0)
addItemInventory(325,-1,8)
addItemInventory(325,+1)
}
if(itemId==506&&blockId== 195)
{
setTile(x,y+1,z,0)
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.splash",2);
addItemInventory(506,-1);
addItemInventory(422,+1);
}
if(Active==1){
if(itemId== 422&&blockId== 117){
Active=2
addItemInventory(422,-1);
print("Brewing Stand Active ! ");
}
}
if(Active==2&&Applegolden ==1){
if(itemId== 322&&blockId== 117){
Applegolden =2
addItemInventory (322,-1);
print("Ingridient Loaded..");
}
}
if( Applegolden ==2&&Goldencarrot==1){
if(itemId== 396&&blockId==117){
Goldencarrot=2
addItemInventory(396,-1);
print("Ingridient Loaded..");
}
}
if(Goldencarrot==2&&Melonspeaked==1){
if(itemId==382&&blockId== 117){
Melonspeaked=2
addItemInventory(382,-1);
print("Ingridient Loaded..");
}
}
if( Applegolden ==2&&Goldencarrot==2&&Melonspeaked==2&&Active==2){
Active=1;
Applegolden=1;
Goldencarrot=1;
Melonspeaked=1;
Level.dropItem(x,y+1,z,1,509,1,0);
print("Potion instant of treatment Create !");
}
if(Active==2&&Rottenflesh==1){
if(itemId== 367&&blockId== 117){
Rottenflesh=2
addItemInventory (367,-1);
print("Ingridient Loaded..");
}
}
if(Rottenflesh==2&&Spidereye==1){
if(itemId== 375&&blockId== 117){
Spidereye=2
addItemInventory (375,-1);
print("Ingridient Loaded..");
}
}
if(Spidereye==2&&Potatopoisonous==1){
if(itemId==394&&blockId== 117){
Potatopoisonous=2
addItemInventory (394,-1);
print("Ingridient Loaded..");
}
}
if(Potatopoisonous==2&&Spiderfermentedeye==1){
if(itemId== 376&&blockId== 117){
Spiderfermentedeye=2
addItemInventory(376,-1);
print("Ingridient Loaded..");
}
}
if(Potatopoisonous==2&&Spiderfermentedeye==2&&Spidereye==2&&Rottenflesh==2&&Active==2){
Active=1;
Rottenflesh=1;
Spidereye=1;
Potatopoisonous=1;
Spiderfermentedeye=1;
Level.dropItem(x,y+1,z,1,417,1,0);
print(" Potion instant damage Create ! ");
}
}

function attackHook(attacker, victim)
{
if (getCarriedItem()==417)
{
Entity.setHealth(victim, 1);
addItemInventory(417, -1);
addItemInventory(506,+1);
}
else if (getCarriedItem()==509)
{
Entity.setHealth(victim, 100);
addItemInventory(509, -1);
addItemInventory(506,+1);
}
else if(getCarriedItem()==416)
{
Entity.setHealth(victim, 1);
Level.explode( Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 3);
addItemInventory(416, -1);
addItemInventory(506,+1);
}
}
