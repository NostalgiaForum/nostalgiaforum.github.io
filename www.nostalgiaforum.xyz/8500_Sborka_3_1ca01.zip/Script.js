function newLevel()
{
clientMessage(ChatColor.BLUE + "Script by Sas&Dark");
}

var armor305 = false;
var armor304 = false;
var armor303 = false;
var armor302 = false;
var Xpos=0;
var Ypos=0;
var Zpos=0;
var i=1;
var u=1;
var Xdiff=0;
var Ydiff=0;
var Zdiff=0;
var Applegolden = 1;
var Goldencarrot = 1;
var Melonspeaked = 1;
var Active = 1;
var ci = "cauldron_inner"
var c = "cauldron_side"
var as = 325;
var Rottenflesh = 1;
var Spidereye = 1;
var Spiderfermentedeye = 1;
var Potatopoisonous = 1;




function toolUse(maxDamage,id)
{
var pcid=Player.getCarriedItemData();
if(pcid!==maxDamage)
{
Entity.setCarriedItem(getPlayerEnt(),id,1,pcid+1);
}
else if(pcid==maxDamage) 
{
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
Entity.setCarriedItem(getPlayerEnt(),0,0,0);
addItemInventory(id,-1);
}
}


function attackHook(attacker, victim)
{
if( Level.getGameMode() == 0){
if( getCarriedItem()==418)
{
Entity.setHealth(victim, 3);
setVelY(victim,1);
Level.explode( Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1);
toolUse(1340,418)
}
}
else if( Level.getGameMode() !== 0){
if( getCarriedItem()==418)
{
Entity.setHealth(victim, 3);
setVelY(victim,1);
Level.explode( Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1);
}
}
}
ModPE.setItem(377,"blaze_powder",0,"Blase Powder");
ModPE.setFoodItem(394,"potato_poisonous",0,-16,"Potato poisonous");
ModPE.setFoodItem(375,"spider_eye",0,-4,"Spider Eye");
ModPE.setFoodItem(367,"rotten_flesh", 0, -16, "Rotten Flesh");
ModPE.setFoodItem(322,"apple_golden",0,20,"Golden Apple");
ModPE.setItem(371,"gold_nugget",0,"Golden Nugget");
ModPE.setFoodItem(396,"carrot_golden",0,14,"Golden Carrot");
ModPE.setFoodItem(382,"melon_speckled",0, 17,"Speckled Melon");
ModPE.setFoodItem(376,"spider_eye_fermented",0,4,"Fermented Spider Eye");
ModPE.setFoodItem (350,"fish_cooked",0,5,"Fish Cookied");
ModPE.setItem (346,"fishing_rod_uncast",0,"Fishing rod");
ModPE.setFoodItem (349,"fish_raw", 0, 3,"Fish Raf");
ModPE.setItem(378,"magma_cream",0,"Emerald Sword");
ModPE.setItem(368,"ender_pearl",0,"Ender Pearl");
ModPE.setItem(418, "gold_horse_armor", 0, " Explosive Sword");
ModPE.setItem (369,"blaze_rod",0,"Blaze Rod");
ModPE.setItem (509,"potion_bottle_splash", 0, "Potion instant of treatment" );
ModPE.setItem(417, "record_chirp", 0, "Potion instant damage");
ModPE.setItem(506,"potion_bottle_drinkable", 0,"Potion bottle");
ModPE.setItem(422,"fireworks_charge",0,"Bottle with water");
ModPE.setItem(370,"brewing_stand",0,"Brewing Stand");
ModPE.setItem (490, "record_strad", 0, "Catapult Sword");
ModPE.setItem (468,"skull_creeper", 0,"Scipetr Power");
ModPE.setItem(423,"cauldron",0,"Cauldron");
ModPE.setItem(508, "record_blocks",0, "Medium dinamite");
ModPE.setItem (492, "record_mellohi", 1, "Trinitroluol ");
ModPE.setItem(511, "record_13", 0, "Smal dinamite ");
ModPE.setItem(510, "record_11", 0,"Detonator");
ModPE.setItem(416,"record_cat", 0, "Big dinamite");
Block.defineBlock(194,"Cauldron",[[ci,0],["cauldron_top",0],[c,0],[c,0],[c,0],[c,0]],20,5,7);
Block.defineBlock(195,"Cauldron with water",[[ci,0],["wool",11],[c,0],[c,0],[c,0],[c,0]],20,5,7);
Block.defineBlock(117,"Brewing Stand",["brewing_stand",0],true,5,1);
Block.setDestroyTime(194,4);
Block.setDestroyTime(195,4);
Block.setDestroyTime(117,3);
Block.setRenderLayer(117,1);
Item.setMaxDamage(346, 500);
Item.setMaxDamage(378, 5000);
Item.setMaxDamage(418, 1340);
Item.setMaxDamage(490,1003);
Item.setMaxDamage(468,3999);

ModPE.langEdit("item.helmetChain.name","Emerald Helmet");
ModPE.langEdit("item.chestplateChain.name"," Emerald Chestplate");
ModPE.langEdit("item.legginsChain.name"," Emerald Leggins");
ModPE.langEdit("item.bootsChain.name"," Emerald Boots");



Player.addItemCreativeInv(378,1,0)
Player.addItemCreativeInv(417,1,0)
Player.addItemCreativeInv(416,1,0)
Player.addItemCreativeInv(509,1,0)
Player.addItemCreativeInv(490,1,0)
Player.addItemCreativeInv(418,1,0)
Player.addItemCreativeInv(346,1,0)
Player.addItemCreativeInv(506,1,0)
Player.addItemCreativeInv(370,1,0)
Player.addItemCreativeInv(322,1,0)
Player.addItemCreativeInv(396,1,0)
Player.addItemCreativeInv(382,1,0)
Player.addItemCreativeInv(423,1,0)
Player.addItemCreativeInv(368,1,0)
Player.addItemCreativeInv(350,1,0)
Player.addItemCreativeInv(349,1,0)
Player.addItemCreativeInv(369,1,0)
Player.addItemCreativeInv(367,1,0)
Player.addItemCreativeInv(375,1,0)
Player.addItemCreativeInv(376,1,0)
Player.addItemCreativeInv(377,1,0)
Player.addItemCreativeInv(394,1,0)
Player.addItemCreativeInv(371,1,0)
Player.addItemCreativeInv(422,1,0)
Player.addItemCreativeInv(492,1,0)
Player.addItemCreativeInv(510,1,0)
Player.addItemCreativeInv(511,1,0)
Player.addItemCreativeInv(508,1,0)
Player.addItemCreativeInv(468,1,0)

Item.addShapedRecipe(468,1,0,["geg","aia","aia"],["g",368,0,"e",325,10,"i",369,0]);
Item.addShapedRecipe(492,1,1,["ccc","cpc","ccc"],["c",337,8,"p",289,0]);
Item.addShapedRecipe(510,1,1,["ppp","ppp","nnn"],["p",289,0,"n",287,0]);
Item.addShapedRecipe(511,1,0,["bzb","btb","bbb"],["b",339,0,"z",510,1,"t",492,1,]);
Item.addShapedRecipe(508,1,0,["bzb","btb","btb"],["b",339,0,"z",510,1,"t",492,1,]);
Item.addShapedRecipe(416,1,0,["bzb","ttt","bbb"],["b",339,0,"z",510,1,"t",492,1,]);
Item.addShapedRecipe(377,4,0,["ccc","cpc","ccc"],["p",369,0]);
Item.addShapedRecipe(423,1,0,["bab","bab","bbb"],["b",265,0,]);
Item.addShapedRecipe(506,8,0,["aaa","tat","ata"],["t",20,0,]);
Item.addShapedRecipe(490,1,0,["ryr","aea","ysy"],["r",331,0,"a",264,0,"e",388,0,"s",369,0]);
Item.addShapedRecipe(418,1,0,["asa","tst","aia"],["t",46,0,"s",369,0,"i",265,0,]);
Item.addShapedRecipe(266,1,0,["ana","ana","ana"],["n",371,0]);
Item.addShapedRecipe(302,1,-30000,["eee","eae","aaa"],["e",388,0]);
Item.addShapedRecipe(303,1,-30000,["eae","eee","eee"],["e",388,0]);
Item.addShapedRecipe(304,1,-30000,["eee","eae","eae"],["e",388,0]);
Item.addShapedRecipe(305,1,-30000,["aaa","eae","eae"],["e",388,0]);
Item.addShapedRecipe(346,1,0,["saa","nsa","nas"],["s",280,0,"n",287,0]);
Item.addShapedRecipe(382,1,0,["ccc","cpc","ccc"],["c",371,0,"p",360,0]);
Item.addShapedRecipe(396,1,0,["ccc","cpc","ccc"],["c",371,0,"p",391,0]);
Item.addShapedRecipe(322,1,0,["ccc","cpc","ccc"],["c",266,0,"p",260,0]);
Item.addShapedRecipe(376,1,0,["asa","aca","ama"],["s",375,0,"c",353,0,"m",40,0]);
Item.addShapedRecipe(378,1,0,["aea","eee","asa"],["e",388,0,"s",280,0]);
Item.addShapedRecipe(371,3,0,["ccc","cpc","ccc"],["p",266,0]);
Item.addShapedRecipe(370, 1 , 0 , ["ppp","aia","ccc"],["i", 369,0,"c",4,0,"p",265,0]);
Item.addFurnaceRecipe(349,350);





function destroyBlock(x,y,z,side)
{
var block=Level.getTile(x,y,z)
{
if(block==117)
{
preventDefault();
Level.destroyBlock(x,y,z);
Level.destroyBlock(x,y-1,z);
Level.dropItem(x,y,z,0,370,1);
}
if(block==194)
{
preventDefault();
Level.destroyBlock(x,y,z);
Level.dropItem(x,y,z,0,423,1);
}
if(block==195)
{
preventDefault();
setTile (x,y,z,8)
Level.destroyBlock(x,y,z);
Level.dropItem(x,y,z,0,423,1);
}
}
}

//gdhdh
function deathHook (attacker, victim) 
{
if (Entity.getEntityTypeId(victim) == 32) 
{
preventDefault();
var DropItem= Math.floor((Math.random()*40)+1);
 if( DropItem ==1|| DropItem ==2|| DropItem ==3|| DropItem ==4|| DropItem ==5|| DropItem ==12|| DropItem ==16)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 367, 1, 0);
}
else if( DropItem ==17)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 367, 2, 0);
}
else if( DropItem ==40)
{
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 1, 394, 1, 0);
}
}
}



//hddhjdjd
function useItem(x,y,z, itemId, blockId, side)
{
if( Level.getGameMode() == 0){
if( itemId ==346&&blockId==3|| itemId ==346&&blockId==12 )
{
toolUse(500,346)
preventDefault();
randomfish6= Math.floor((Math.random()*300)+1);
	if( randomfish6 == 23|| randomfish6 == 24|| randomfish6 == 25|| randomfish6 == 27|| randomfish6 == 12|| randomfish6 == 26|| randomfish6 == 1|| randomfish6 == 2|| randomfish6 == 3|| randomfish6 == 4|| randomfish6 == 33|| randomfish6 == 34|| randomfish6 == 35|| randomfish6 == 37|| randomfish6 == 29|| randomfish6 == 36|| randomfish6 == 31|| randomfish6 ==199|| randomfish6 ==123|| randomfish6 == 94 ) 
{
	 Level.dropItem(x,y+1,z,1,349,1,0);
	} 
else if( randomfish6 == 15|| randomfish6 == 16|| randomfish6 == 14|| randomfish6 == 17|| randomfish6 == 87|| randomfish6 == 112|| randomfish6 == 126|| randomfish6 == 111|| randomfish6 == 52|| randomfish6 == 83|| randomfish6 == 84 ) 
{
	 Level.dropItem(x,y+1,z,1,349,2,0);
	}  
else if( randomfish6 == 32) 
{
	 Level.dropItem(x,y+1,z,1,31,1,1);
	 	}  
else if( Level.getGameMode() !== 0){
if( itemId ==346&&blockId==3|| itemId ==346&&blockId==12 )
{
preventDefault();
randomfish6= Math.floor((Math.random()*300)+1);
	if( randomfish6 == 23|| randomfish6 == 24|| randomfish6 == 25|| randomfish6 == 27|| randomfish6 == 12|| randomfish6 == 26|| randomfish6 == 1|| randomfish6 == 2|| randomfish6 == 3|| randomfish6 == 4|| randomfish6 == 33|| randomfish6 == 34|| randomfish6 == 35|| randomfish6 == 37|| randomfish6 == 29|| randomfish6 == 36|| randomfish6 == 31|| randomfish6 ==199|| randomfish6 ==123|| randomfish6 == 94 ) 
{
	 Level.dropItem(x,y+1,z,1,349,1,0);
	} 
else if( randomfish6 == 15|| randomfish6 == 16|| randomfish6 == 14|| randomfish6 == 17|| randomfish6 == 87|| randomfish6 == 112|| randomfish6 == 126|| randomfish6 == 111|| randomfish6 == 52|| randomfish6 == 83|| randomfish6 == 84 ) 
{
	 Level.dropItem(x,y+1,z,1,349,2,0);
	}  
else if(randomfish6 == 99)
{
Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2);
addItemInventory(346,-1);
}
else if( randomfish6 == 32) 
{
	 Level.dropItem(x,y+1,z,1,31,1,1);
	 	}  
}
}
}
}
}


function checkArmor() 
{ 
if(Player.getArmorSlot(3) == 305) 
{ 
armor305 = true; 
}  
if(Player.getArmorSlot(3)!== 305) 
{ 
armor305 = false; 
} 
if(Player.getArmorSlot(2) == 304) 
{ 
armor304 = true; 
}  
if(Player.getArmorSlot(2)!==304) 
{ 
armor304 = false; 
}  
if(Player.getArmorSlot(1) == 303) 
{ 
armor303 = true; 
}  
if(Player.getArmorSlot(1)!== 303) 
{ 
armor303 = false; 
}  
if(Player.getArmorSlot(1) == 302) 
{ 
armor302 = true; 
}  
if(Player.getArmorSlot(1)!== 302) 
{ 
armor302 = false; 
}  
}






function modTick()
{
checkArmor();
  if (armor303 == true)
   {
    Player.setHealth(20);
    }
if(armor304==true)
  {
        if(i==1)
      {
          Xpos=getPlayerX();
        Zpos=getPlayerZ();
        i = i + 1;
      }
      else if(i==3)
      {
        i=1;
        Xdiff=getPlayerX()-Xpos;
        Zdiff=getPlayerZ()-Zpos;
        setVelX(getPlayerEnt(),Xdiff);
        setVelZ(getPlayerEnt(),Zdiff);
        Xdiff=0;
        Zdiff=0;
      }
  if(i!=1)
  {
  i = i + 1;
  }
}
if(armor305 == true)
 {
  if(u==1)
   {
    Ypos=getPlayerY();
     u = u + 1;
   }
   else if(u==3)
    {
     u=1;
     Ydiff=getPlayerY()-Ypos;
     setVelY(getPlayerEnt(),Ydiff);
     Ydiff=0;
    }
   if(u!=1)
    {
    u = u +1;
    }
}
}


